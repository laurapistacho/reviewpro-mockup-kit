# Kiro Mockup Designer — ReviewPro

Build interactive ReviewPro admin mockups with AI. The kit is plain HTML, one CSS and one JS
file, no build step. Class and token names follow the production library (`@reviewpro/ui-components`)
and theme, so a mockup reads like the React a developer will write. It is the ReviewPro version of the
Daylight team's Kiro Mockup Designer kit: same workflow, same Tweak mode, ReviewPro components.

## Setup (one-time, ~2 min)

Open this folder **on its own** in Kiro (File → Open Folder). If Kiro asks whether you trust the
folder, choose **Trust**: hooks don't run otherwise. The skill activates automatically.

On macOS nothing else is needed. Windows needs `python` on PATH.

> The folder contains a hidden `.kiro/` folder with the skill, hooks and steering.
> In Finder press **Cmd + Shift + .** to see it. Don't copy only the visible files.

## Creating mockups

In Kiro chat, describe what you need:

- *"A settings page to manage alerts, with a create dialog"*
- *"Recreate this Figma screen"* (drag in a screenshot or paste values from the inspect panel)
- *"The review tracking inbox with a reply drawer"*

Kiro will:
1. Pick the closest of 10 page patterns and scaffold a self-contained folder in `mockups/`
2. Adapt the pattern into interactive HTML. Open `index.html` in any browser to preview it
3. Run the mockup checker (classes, icons, assets, dead controls, copy) and fix what it finds

You can also scaffold and check a folder yourself:

```bash
sh .kiro/scripts/new-mockup.sh my-feature 01 06:edit.html     # Windows: python .kiro/scripts/new-mockup.py …
sh .kiro/scripts/check-mockup.sh mockups/my-feature           # Windows: python .kiro/scripts/check-mockup.py …
```

## Patterns

| # | Starter | Use for |
|---|---------|---------|
| 00 | Blank page | Anything new: app shell + one tile |
| 01 | Settings list | Manage users, alerts, templates: toolbar, filters, selection, bulk bar, pagination, drawer, delete dialog |
| 02 | Settings hub | Overview of settings: tiles with link cards |
| 03 | Dashboard | KPI tiles, an SVG chart, department scores, a table |
| 04 | Results table | Sortable breakdown with volume bars, total row, show more |
| 05 | Tabs in a tile | Hotel / restaurants lists with an edit drawer |
| 06 | Edit form | Profile or configuration: one tile per section, validation |
| 07 | Tracking inbox | Reviews list → detail drawer with a reply |
| 08 | Dialog form | Create in a dialog, delete confirmation |
| 09 | Wizard | Stepper, one panel per step, Back / Next |

Open `index.html` (this folder) to browse them and the component showcase.

## Design system

- **Browse it:** `design-system/examples/index.html` shows every component and variant.
- **Names = `@reviewpro/ui-components`:** `class="rp-main-button rp-main-button-size-small"` is
  `<MainButton size="small">`. No modifier class = the default prop of the component.
  `kit-` classes are kit-only page layout.
- **Handoff:** `design-system/HANDOFF.md` lists every class with its component and prop; each
  component doc (`design-system/components/rp-*.md`) starts with the same table.
- **Source of truth:** `design-system/rp-map.json` maps every class to code. The checker, the docs
  and HANDOFF.md are built from it.
- **App shell:** the new navigation from `compositions/Navigation` (blue top bar, icon rail, section panel).
- **Icons:** all 573 production icons (`rp-icon rp-icon-{name}`), generated from the React icon files.

## Visual fine-tuning: Tweak mode

Open a mockup from this computer and click **Edit** in the bottom left corner (or add `#edit` to the
URL, or press **Alt+Shift+E**). A small Figma-like editor appears:

- **Select like in Figma:** a click selects the outer layer, each click inside goes one level deeper,
  double-click edits text (on an icon it opens the icon picker), ⌘-click picks the deepest layer.
  **Esc** = parent, **Enter** = children, **Tab** = siblings.
- **Props:** the React props of the selected component (color, size, danger, variant…), switched by
  the kit's modifier classes. **Component menu** (click the name in the inspector header): swap a
  button ↔ link ↔ chip ↔ switch ↔ checkbox, or a text field ↔ select ↔ search ↔ text area ↔ date picker.
- **Tokens:** spacing, gap, font size, radius take any value; a value that is a token is written as the
  token (16 → `var(--spacing-2)`). Colors from the ReviewPro palette.
- **+ Components:** insert or replace with DS components; drag them onto the page.
- **Comments:** click any element in Comment mode (C) to pin a note for Kiro, then say "apply my comments".
- **Save & history:** every save writes into the HTML file (Chrome or Edge: pick the kit folder once),
  keeps versions in `.tweak-history/`, and writes `tweak-changes.md` so Kiro can carry the change to the
  other pages ("apply my tweaks").

Tweak mode lives in one place (`design-system/foundation/tweak/`) and is not copied into mockups, so
mockup folders and Figma Make uploads stay small.

## Figma Code Prototype

1. Open the mockup in a browser first and check it works
2. In Figma → Code Prototype (Make) → import the mockup folder
3. The prototype starts from `index.html`

## Website and download

`index.html` (this folder) is also the kit website: Install, What Is This, Design System, Pattern Pages and
Examples, like the Daylight kit site. `python3 .kiro/scripts/build-site.py` checks the kit, then writes
`download/kiro-mockup-designer.zip` (what people download) and `public/` (the website with the zip inside).
Publish `public/` on any static host, or preview it with `python3 .kiro/scripts/build-site.py --serve`
(http://localhost:8000). Both folders are build output and stay out of git.

## Updating the kit

This copy has no auto-update (the Daylight kit pulls itself from GitLab at every session; that hook
was removed so it cannot overwrite the ReviewPro files). Your mockups in `mockups/` are local work.
When the kit changes, copy `templates/shared.css`, `templates/shared.js` and `templates/rp-icons.css`
into the mockups that should get the change.

## Contributing (maintainers)

Read the `contributing` steering file first. In short:

1. **Names:** a class is the React name in kebab case (`rp-table-pagination`), props as
   `rp-{component}-{value}`; default props get no class; `kit-` for page layout.
2. **Register it:** add it to `design-system/rp-map.json`, `tweak/components.js` (so designers can
   switch it), `tweak/library.js` (the + panel) and the component doc, then run
   `python3 .kiro/scripts/build-docs.py`.
3. **Show it:** add it to the showcase (`design-system/examples/index.html`).
4. **Sync:** copy changed runtime files (`shared.css`, `shared.js`, `rp-icons.css`) to `templates/`.
5. **Check:** `python3 .kiro/scripts/check-mockup.py --all` must report 0 errors.

Maintainer tools:

| Command | Does |
|---|---|
| `python3 .kiro/scripts/build-icons.py --src ../frontend-workspace/libs/ui-components/src/icons` | Regenerates the icon classes, glyphs and icon reference from the production icons |
| `python3 .kiro/scripts/build-docs.py` | Regenerates HANDOFF.md and the component doc tables from rp-map.json |
| `python3 .kiro/scripts/visual-diff.py --ref HEAD` | Layout of every page vs a git ref, element by element (needs Chrome) |
| `python3 .kiro/scripts/build-site.py` | Builds the download zip and the website (`public/`); `--serve` previews it |

## Project structure

```
kiro-mockup-designer/
├── .kiro/
│   ├── skills/reviewpro-html-mockup/  ← AI skill (mockup build protocol)
│   ├── hooks/                          ← keep a page version before Kiro edits it, refresh the landing page
│   ├── scripts/                        ← new / check mockup, icon + docs builders, visual diff
│   └── steering/                       ← project rules, mockup workflow, contributing
├── design-system/
│   ├── foundation/                     ← shared.css, rp-icons.css, shared.js, tweak/ (editor), rules, decision tree, icons
│   ├── components/                     ← one doc per component family (rp-*.md)
│   ├── examples/                       ← showcase (index.html) + one starter page per pattern (00–09)
│   ├── brand/                          ← ReviewPro Reputation logo, establishment logo
│   ├── rp-map.json                     ← every class → @reviewpro/ui-components
│   └── HANDOFF.md                      ← class → React prop table (generated)
├── templates/                          ← files copied into each mockup (identical to foundation/, checked)
├── mockups/
│   ├── example-*/                      ← reference examples (in git)
│   └── [your-mockups]/                 ← your work (local only, not in git)
└── README.md
```
