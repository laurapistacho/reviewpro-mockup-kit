---
inclusion: auto
name: "mockup-workflow"
description: >
  How to build and organize mockups in this project. Loaded when the user asks
  to create, edit, or organize mockups.
---
# Mockup Workflow

The full protocol is the `reviewpro-html-mockup` skill (`.kiro/skills/reviewpro-html-mockup/SKILL.md`).
Activate it before writing any mockup HTML. This file only covers housekeeping.

## Quick reference
```bash
sh .kiro/scripts/new-mockup.sh <name> <pattern> [<pattern>:<file.html> ...]   # create (Windows: python .kiro/scripts/new-mockup.py)
sh .kiro/scripts/check-mockup.sh mockups/<name>                               # verify (Windows: python .kiro/scripts/check-mockup.py)
```
- One folder per mockup in `mockups/`, kebab-case name, `index.html` is the entry point.
- Mockup folders are local work and not tracked in git, except `mockups/example-*/`.
- Editing an existing mockup: work in its folder, keep its sibling assets, re-run the checker.
- Never edit `templates/` or `design-system/` while building a mockup.
- `shared.css`, `shared.js` and `rp-icons.css` inside a mockup are copies: never edit them there;
  page-level layout CSS goes in the page. After a kit update, copy the new versions from `templates/`
  into the mockups that should get it.
