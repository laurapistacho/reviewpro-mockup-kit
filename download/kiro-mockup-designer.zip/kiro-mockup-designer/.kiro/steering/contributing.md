---
inclusion: manual
name: "contributing"
description: >
  How the kit maintainers change the design system: names, the map, docs, showcase, icons, checks.
---
# Contributing to the kit (maintainers)

## Where things come from
| What | Source |
|------|--------|
| Component names and props | `frontend-workspace/libs/ui-components/src/<Component>/<Component>.tsx` |
| Tokens | `frontend-workspace/libs/js-browser/src/themes/ui-app.ts` + Figma UI App variables |
| Sizes and spacing that must match Figma | `ai-tools-design-laura/mockup-kit` (pixel diffs against the Tables page) |
| Navigation | `libs/ui-components/src/compositions/Navigation` (story + TopBar.mdx + SideBar.mdx) |
| Icons | `libs/ui-components/src/icons/*.tsx` |

## Naming
- A class is the React name in kebab case: `MainButton` → `rp-main-button`, `TablePagination` → `rp-table-pagination`.
- A prop value is `rp-{component}-{value}` (`rp-chip-confirmation`) or `rp-{component}-{prop}-{value}`
  when the value alone is ambiguous (`rp-main-button-size-small`). A boolean prop is `rp-{component}-{prop}` (`rp-main-button-danger`).
- No class = the default value of the prop in code. Check the default in the component source before
  deciding which value is the base style (GhostButton is `size="small"` by default, Drawer is `anchor="left"`).
- Parts of a component (TileTitle, DialogActions) are `rp-{component}-{part}`. Kit-only page layout is `kit-{name}`.

## Changing the design system
1. **CSS**: edit `design-system/foundation/shared.css`. Use tokens only.
2. **Map**: add every new class to `design-system/rp-map.json` (root, prop, part, state or kit).
3. **Docs**: update the component doc in `design-system/components/`, then run
   `python3 .kiro/scripts/build-docs.py` (writes `HANDOFF.md` and the MAP block of each doc).
4. **Showcase**: add the variant to `design-system/examples/index.html` (one section per component).
5. **Tweak**: add the props to `foundation/tweak/components.js` and a snippet to `foundation/tweak/library.js`.
6. **Behavior**: new interactions go in `foundation/shared.js` as event delegation on DS markup, never as
   page-level handlers. Document them in the skill (§ What shared.js already does).
7. **Templates**: copy `shared.css`, `shared.js`, `rp-icons.css` and the brand files to `templates/`.
8. **Check**: `python3 .kiro/scripts/check-mockup.py --all` must report 0 errors. It fails on classes
   missing from the map, a component without a showcase example, stale docs and templates that differ.
9. **Publish**: `python3 .kiro/scripts/build-site.py`, then publish `public/` (the website and the download).

## Icons
The Figma icon library (Pictograms and Icons, `sG8E7rdnYt59mgmYDMr7PY`, page Icons) is the source of truth.
Its SVGs live in `design-system/foundation/icons-figma/` (`manifest.json` maps each Figma component to a kit
class); the React icons of `@reviewpro/ui-components` fill the gaps and give the import shown in the reference.
`python3 .kiro/scripts/build-icons.py --src <frontend-workspace>/libs/ui-components/src/icons`
regenerates `rp-icons.css`, the glyph variables in `shared.css`, `icons-full-reference.md` and the Tweak
icon picker. Use a checkout of today's master for `--src` (`git archive origin/master` works without
touching a local branch). To refresh the Figma drawings, export the components as SVG with the Figma MCP
(`download_figma_images`) into `icons-figma/` under the file names in `manifest.json`, then run the script.
`--no-figma` builds from the React icons only. Add common guesses to `ALIASES` in the script.

## Maintainer tools
| Command | Checks |
|---|---|
| `python3 .kiro/scripts/check-mockup.py --all` | Starters, showcase, example mockups and kit consistency |
| `python3 .kiro/scripts/build-docs.py --check` | rp-map.json ↔ shared.css ↔ HANDOFF.md and component docs |
| `python3 .kiro/scripts/visual-diff.py --ref HEAD` | Layout of every page vs a git ref, element by element (needs Chrome) |
| `python3 .kiro/scripts/build-site.py` | Builds `download/kiro-mockup-designer.zip` and the website in `public/` (refuses when the check fails) |
