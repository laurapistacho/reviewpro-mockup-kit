---
inclusion: always
---
# ReviewPro HTML Mockup Kit — Project Rules

## What this is
A self-contained toolkit for building interactive HTML mockups that look and behave like the
ReviewPro admin app (UI App). No build tools, no frameworks: HTML, CSS and JS that open in a browser.

## Directory structure
| Path | Purpose |
|------|---------|
| `mockups/` | Your work: one folder per mockup |
| `templates/` | Files copied into each mockup folder |
| `design-system/` | CSS, JS, icons, component docs, 17 starters (00–16), the showcase, brand assets |
| `.kiro/skills/reviewpro-html-mockup/` | The protocol: how Kiro builds mockups |

## Rules
1. **The files in `design-system/` are the source of truth.** Learn from them, but do not edit them
   while building mockups. Changes come from the kit maintainers (the `contributing` steering file).
2. **Never edit files in `templates/`.** They are copies of the design system runtime files.
3. **Mockups go in `mockups/`**, always, one subfolder per project.
4. **Every mockup folder holds its assets** (`shared.css`, `rp-icons.css`, `shared.js`, logos), so it is
   portable and imports into Figma Make.
5. **No external dependencies**: no npm, no CDN libraries (Google Fonts for Noto Sans is the exception).
6. **Tweak changes and comments come first.** When the designer says they changed, fixed, tweaked or
   commented a mockup (in any words), look for `tweak-changes.md` in that mockup folder (or any
   `mockups/*/tweak-changes.md`) and re-read the edited page before anything else. Apply the file as
   the skill describes (§ Tweak changes); delete each comment's lines once it is done, and the file when it is empty.
7. **Name the version**: after you change a mockup page, give the newest `…__kiro.html` in
   `.tweak-history/<page>/names.json` a short name of what you did (skill § Version history).
8. **Product names come from the code**: a new class needs a React counterpart in
   `@reviewpro/ui-components` (or is a `kit-` layout helper). See `design-system/rp-map.json`.
9. **QA screenshots: the top bar is always blue.** Screenshots from the QA environment have a green
   top bar; green only marks QA. Build the blue production bar (plain `rp-top-bar`) and never use
   `rp-top-bar-qa` unless the designer asks to show QA. Copy everything else the screenshot shows,
   including the exact rail icons (`design-system/foundation/rules.md` § Copying a screenshot).
10. **Two versions, never mixed.** `reviewpro-html-mockup` builds exactly what the Figma UI App library
   and the product show (Figma wins on looks, the product on behaviour and copy: `design-system/figma/README.md`).
   Modernising, rebranding, dark mode or "an ideal version" is the `reviewpro-ui-modernise` skill: it writes
   `<page>-v2.html` with `make-v2.py` and keeps every V2 change in `theme-v2.css`, `motion-v2.js` or the `-v2`
   page. Never put V2 styles or motion in `shared.css` / `shared.js`, or edit the current page beyond the
   version-switch link (fidelity fixes to the current page are a `reviewpro-html-mockup` change, made in both).
11. **Figma frames are read, not guessed.** For a Figma link, get the frame with the Figma MCP and build from
   `python3 .kiro/scripts/figma-outline.py`. After changing `shared.css`, run `python3 .kiro/scripts/figma-check.py`.
12. **Accessibility is checked, not assumed.** Run `python3 .kiro/scripts/a11y-check.py mockups/<slug>` after
   `check-mockup.py`. Errors (names, keyboard, structure) are fixed in every mockup; `library` warnings on current pages
   are the product's own issues and stay. Modernised (V2) pages are a Design concept and must have no errors in Light
   and Dark.
