#!/bin/sh
# macOS / Linux wrapper for generate-index.py, used by the PostFileSave and
# PostFileCreate hooks. Finds a working Python 3 and exits quietly if there is
# none, so designers without Python never see errors or install dialogs.

case "$(uname -s)" in
  Darwin|Linux) ;;
  *) exit 0 ;;  # Windows uses the *-windows.json hooks
esac

cd "$(dirname "$0")/../.." || exit 0

for py in python3 python; do
  path=$(command -v "$py" 2>/dev/null) || continue
  # /usr/bin/python3 on a Mac without Command Line Tools is an installer stub.
  if [ "$(uname -s)" = "Darwin" ] && [ "$path" = "/usr/bin/python3" ]; then
    xcode-select -p >/dev/null 2>&1 || continue
  fi
  "$path" -c 'import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)' 2>/dev/null || continue
  exec "$path" .kiro/scripts/generate-index.py
done

echo "Python 3 not found — skipped index.html regeneration"
exit 0
