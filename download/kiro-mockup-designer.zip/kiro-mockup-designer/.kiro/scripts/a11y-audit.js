/*
 * In-page accessibility audit for kit mockups, injected by .kiro/scripts/a11y-check.py (Chrome DevTools Protocol).
 * WCAG 2.2 level AA, the level EN 301 549 v4.1.1 references. The Python side drives the keyboard (real Tab, Enter, Escape,
 * arrow presses) and calls the functions below; this file only reads the page (it adds data-a11y-probe attributes to the
 * elements a keyboard flow tests, in a page the checker loaded for itself).
 *
 *   __rpA11y.audit()        structure, names, ARIA, text contrast, non-text contrast, target size, colour-only charts
 *   __rpA11y.baseline()     remembers how every focusable looks before the Tab walk
 *   __rpA11y.step()         the element the last Tab focused: is focus visible, its contrast, is it hidden by sticky parts
 *   __rpA11y.probe(css, n)  marks up to n visible elements for a keyboard flow; flowState(id) reads the result
 *   __rpA11y.motion()       animations running now (reduced motion and endless animations)
 *   __rpA11y.reflow()       sideways scrolling and clipped text at the current viewport
 */
(function () {
  'use strict';
  if (window.__rpA11y) return;
  var doc = document, A = window.__rpA11y = {};
  var KIT_CHROME = '#kitVersionSwitch, #dlEditButton, #dl-tweak-host, [data-dl-probe], [data-dl-preview], #dlToastStack';
  var FOCUSABLE = 'a[href], button, input:not([type="hidden"]), select, textarea, summary, iframe, [tabindex], [contenteditable="true"]';

  /* ── colour ── */
  var ctx = doc.createElement('canvas').getContext('2d');
  function parse(s) {
    if (!s || s === 'none') return null;
    if (s === 'transparent') return { r: 0, g: 0, b: 0, a: 0 };
    var m = /^rgba?\(([^)]+)\)$/.exec(s);
    if (m) { var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; }
    m = /^color\(srgb ([^)]+)\)$/.exec(s);
    if (m) { var q = m[1].split(/[\s\/]+/).filter(Boolean).map(parseFloat); return { r: q[0] * 255, g: q[1] * 255, b: q[2] * 255, a: q.length > 3 ? q[3] : 1 }; }
    try {
      ctx.fillStyle = '#000'; ctx.fillStyle = s;
      var v = ctx.fillStyle;
      if (v[0] === '#') return { r: parseInt(v.slice(1, 3), 16), g: parseInt(v.slice(3, 5), 16), b: parseInt(v.slice(5, 7), 16), a: 1 };
      return parse(v);
    } catch (e) { return null; }
  }
  function over(t, b) {
    var a = t.a + b.a * (1 - t.a);
    if (!a) return { r: 0, g: 0, b: 0, a: 0 };
    return { r: (t.r * t.a + b.r * b.a * (1 - t.a)) / a, g: (t.g * t.a + b.g * b.a * (1 - t.a)) / a, b: (t.b * t.a + b.b * b.a * (1 - t.a)) / a, a: a };
  }
  function lum(c) {
    function f(v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function ratio(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function hex(c) { return '#' + [c.r, c.g, c.b].map(function (v) { return Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'); }).join('').toUpperCase(); }
  function r2(x) { return Math.round(x * 100) / 100; }
  /* the colour behind an element: its own background (unless skipSelf) and its ancestors', composited, white canvas last */
  function bgUnder(el, skipSelf) {
    var layers = [], unknown = null, n = skipSelf ? el.parentElement : el;
    while (n && n.nodeType === 1) {
      var cs = getComputedStyle(n);
      if (cs.backgroundImage && cs.backgroundImage !== 'none' && !n.matches('.rp-icon, input')) unknown = unknown || n;
      var c = parse(cs.backgroundColor);
      if (c && c.a > 0) { layers.push(c); if (c.a >= 0.999) break; }
      n = n.parentElement;
    }
    var base = { r: 255, g: 255, b: 255, a: 1 };
    for (var i = layers.length - 1; i >= 0; i--) base = over(layers[i], base);
    return { c: base, unknown: unknown };
  }
  function opacityOf(el) { var o = 1, n = el; while (n && n.nodeType === 1) { o *= parseFloat(getComputedStyle(n).opacity) || 0; n = n.parentElement; } return o; }

  /* ── elements ── */
  function kit(el) { return !!(el.closest && el.closest(KIT_CHROME)); }
  function shown(el) {
    if (!el || !el.isConnected) return false;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility !== 'visible') return false;
    var rects = el.getClientRects();
    if (!rects.length) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
      var s = getComputedStyle(n);
      if (parseFloat(s.opacity) === 0) return false;
      if (s.clipPath && /inset\(\s*50%/.test(s.clipPath)) return false;
      if (s.clip && s.clip !== 'auto' && /rect\(\s*0(px)?[ ,]+0(px)?[ ,]+0(px)?[ ,]+0(px)?\s*\)/.test(s.clip)) return false;
      if (n !== el && (s.overflow === 'hidden' || s.overflowX === 'hidden' || s.overflowY === 'hidden')) {
        var pr = n.getBoundingClientRect();
        if (pr.width < 2 || pr.height < 2) return false;
      }
    }
    return true;
  }
  function inert(el) { return !!el.closest('[inert]'); }
  function disabled(el) {
    if (el.closest(':disabled, [aria-disabled="true"], fieldset[disabled], [class*="-disabled"]')) return true;
    var lab = el.closest('label, .rp-form-control-label');   /* the label of a disabled checkbox, radio or switch */
    return !!(lab && lab.querySelector('input:disabled, [aria-disabled="true"]'));
  }
  function focusable(el) {
    if (!el.matches(FOCUSABLE) || el.matches(':disabled') || inert(el)) return false;
    if (el.getAttribute('tabindex') === '-1') return false;
    if (el.matches('a') && !el.hasAttribute('href') && !el.hasAttribute('tabindex')) return false;
    return shown(el);
  }
  function label(el) {
    var t = (el.getAttribute('aria-label') || '').trim();
    if (t) return t;
    var lb = el.getAttribute('aria-labelledby');
    if (lb) { t = lb.split(/\s+/).map(function (id) { var x = doc.getElementById(id); return x ? x.textContent : ''; }).join(' ').trim(); if (t) return t; }
    if (el.matches('input, select, textarea')) {
      if (el.id) { var l = doc.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l && l.textContent.trim()) return l.textContent.trim(); }
      var wrap = el.closest('label'); if (wrap && wrap.textContent.trim()) return wrap.textContent.trim();
      if (el.matches('input[type="submit"], input[type="button"], input[type="reset"]') && el.value) return el.value;
    }
    if (el.matches('img, input[type="image"]')) return (el.getAttribute('alt') || '').trim();
    var txt = '';
    (function walk(n) {
      for (var c = n.firstChild; c; c = c.nextSibling) {
        if (c.nodeType === 3) txt += c.nodeValue;
        else if (c.nodeType === 1 && c.getAttribute('aria-hidden') !== 'true' && getComputedStyle(c).display !== 'none') {
          if (c.matches('img')) txt += ' ' + (c.getAttribute('alt') || '');
          else if (c.getAttribute('aria-label')) txt += ' ' + c.getAttribute('aria-label');
          else walk(c);
        }
      }
    })(el);
    txt = txt.replace(/\s+/g, ' ').trim();
    return txt || (el.getAttribute('title') || '').trim();
  }
  function describe(el) {
    if (!el || el.nodeType !== 1) return String(el);
    var s = el.tagName.toLowerCase();
    if (el.id) return s + '#' + el.id;
    var cls = (typeof el.className === 'string' ? el.className : (el.getAttribute('class') || '')).split(/\s+/).filter(function (c) { return c && !/^(open|on)$/.test(c); }).slice(0, 2);
    if (cls.length) s += '.' + cls.join('.');
    var nm = label(el);
    if (nm) s += ' "' + nm.slice(0, 40) + '"';
    return s;
  }
  function where(el) {
    var parts = [], n = el;
    for (var i = 0; n && n.nodeType === 1 && i < 4; i++, n = n.parentElement) {
      if (n.id) { parts.unshift('#' + n.id); break; }
      var c = (typeof n.className === 'string' ? n.className : '').split(/\s+/).filter(function (x) { return /^(rp|kit|v2)-/.test(x); })[0];
      parts.unshift(n.tagName.toLowerCase() + (c ? '.' + c : ''));
    }
    return parts.join(' > ');
  }
  function role(el) { return el.getAttribute('role') || ''; }
  function isV2() { return doc.documentElement.getAttribute('data-rp-version') === 'v2'; }

  /* ── audit ── */
  A.audit = function () {
    var out = [];
    function add(sc, kind, msg, el, extra) { out.push({ sc: sc, kind: kind, msg: msg, el: el ? describe(el) : '', where: el ? where(el) : '', extra: extra || null }); }
    var html = doc.documentElement;
    if (!(html.getAttribute('lang') || '').trim()) add('3.1.1', 'structure', 'the page has no lang attribute', html);
    if (!doc.title.trim()) add('2.4.2', 'structure', 'the page has no <title>', html);
    var all = [].slice.call(doc.querySelectorAll('body *')).filter(function (e) { return !kit(e); });
    var main = doc.querySelector('main, [role="main"]');
    var shell = !!doc.querySelector('.rp-top-bar');
    var h1 = all.filter(function (e) { return e.matches('h1, [role="heading"][aria-level="1"]') && shown(e); });
    if (!h1.length && shell) add('1.3.1', 'best-practice', 'no visible h1: the page title should be the h1 (a visually hidden h1 is fine on pages without a title)');
    if (h1.length > 1) add('1.3.1', 'structure', h1.length + ' visible h1 headings: keep one page title', h1[1]);
    var last = 0;
    all.filter(function (e) { return /^H[1-6]$/.test(e.tagName) && shown(e); }).forEach(function (h) {
      var lv = +h.tagName[1];
      if (last && lv > last + 1) add('1.3.1', 'structure', 'heading level jumps from h' + last + ' to h' + lv, h);
      last = lv;
    });
    if (shell && !main) add('1.3.1', 'structure', 'no main landmark (<main>)');
    if (shell && !doc.querySelector('nav, [role="navigation"]')) add('1.3.1', 'structure', 'no navigation landmark (<nav>)');
    var skip = doc.querySelector('a[href^="#"].v2-skip-link, a[href^="#"][data-rp-skip-link]');
    A._skip = skip && skip.getAttribute('href');
    if (shell && skip) {
      var target = doc.getElementById(skip.getAttribute('href').slice(1));
      if (!target) add('2.4.1', 'structure', 'the skip link points at ' + skip.getAttribute('href') + ', which does not exist', skip);
    }
    if (shell && !skip && isV2()) add('2.4.1', 'structure', 'no "Skip to main content" link before the top bar (make-v2.py adds it)');
    /* ids */
    var ids = {};
    [].forEach.call(doc.querySelectorAll('[id]'), function (e) { if (!kit(e)) ids[e.id] = (ids[e.id] || 0) + 1; });
    Object.keys(ids).forEach(function (id) { if (ids[id] > 1) add('4.1.2', 'aria', 'id "' + id + '" is used ' + ids[id] + ' times (labels and ARIA references break)', doc.getElementById(id)); });
    all.forEach(function (e) {
      ['aria-labelledby', 'aria-describedby', 'aria-controls'].forEach(function (a) {
        var v = e.getAttribute(a);
        if (v) v.split(/\s+/).forEach(function (id) { if (id && !doc.getElementById(id) && !(a === 'aria-controls' && /^rp-runtime-/.test(id))) add('4.1.2', 'aria', a + ' points at "' + id + '", which does not exist', e); });
      });
    });
    /* names, roles */
    all.forEach(function (e) {
      if (!shown(e) && !(e.matches('input.rp-checkbox, input.rp-radio') && shown(e.parentElement))) return;
      var r = role(e);
      var interactive = e.matches('button, a[href], input:not([type="hidden"]), select, textarea, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="option"], [role="switch"], [role="checkbox"], [role="radio"], [role="combobox"]');
      if (interactive && !label(e) && !e.matches('input[type="hidden"]')) add(e.matches('a') ? '2.4.4' : '4.1.2', 'name', 'interactive element without an accessible name', e);
      if (e.matches('img') && !e.hasAttribute('alt')) add('1.1.1', 'name', 'image without alt (alt="" when it is decorative)', e);
      if ((r === 'img' || (e.matches('svg') && r === 'img')) && !label(e)) add('1.1.1', 'name', 'role="img" without aria-label', e);
      if (e.matches('iframe') && !(e.getAttribute('title') || '').trim()) add('4.1.2', 'name', 'iframe without a title', e);
      if (r === 'tab' && !e.closest('[role="tablist"]')) add('1.3.1', 'aria', 'role="tab" outside a role="tablist"', e);
      if (r === 'option' && !e.closest('[role="listbox"]')) add('1.3.1', 'aria', 'role="option" outside a role="listbox"', e);
      if (r === 'menuitem' && !e.closest('[role="menu"], [role="menubar"]')) add('1.3.1', 'aria', 'role="menuitem" outside a role="menu"', e);
      if (+e.getAttribute('tabindex') > 0) add('2.4.3', 'keyboard', 'positive tabindex changes the tab order', e);
      if (e.getAttribute('aria-hidden') === 'true') {
        var f = [].filter.call(e.querySelectorAll(FOCUSABLE), focusable);
        if (focusable(e)) f.unshift(e);
        if (f.length) add('4.1.2', 'aria', 'aria-hidden="true" hides ' + f.length + ' focusable element(s) from screen readers', f[0]);
      }
      if (e.matches('.rp-field-label-required')) {
        var field = e.closest('.rp-text-field, .rp-select, .rp-search, .rp-text-area, .rp-date-picker');
        var ctl = field && field.querySelector('input, textarea, .rp-select-trigger');
        if (ctl && !ctl.required && ctl.getAttribute('aria-required') !== 'true' && !/required/i.test(label(ctl))) add('3.3.2', 'name', 'required field: the control does not say it is required (required, aria-required or "required" in its name)', ctl);
      }
    });
    /* text contrast */
    var seen = new Set(), tw = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null), node;
    while ((node = tw.nextNode())) {
      if (!node.nodeValue.trim()) continue;
      var el = node.parentElement;
      if (!el || seen.has(el) || kit(el) || el.closest('script, style, noscript, title')) continue;
      seen.add(el);
      if (!shown(el) || disabled(el)) continue;
      if (el.closest('svg') && !el.matches('text, tspan')) continue;
      var cs = getComputedStyle(el);
      var fg = parse(el.matches('text, tspan') ? cs.fill : cs.color);
      if (!fg) continue;
      fg = { r: fg.r, g: fg.g, b: fg.b, a: fg.a * opacityOf(el) };
      var bg = bgUnder(el.closest('svg') || el, false);
      var fgc = over(fg, bg.c);
      var size = parseFloat(cs.fontSize), weight = parseInt(cs.fontWeight, 10) || 400;
      var large = size >= 24 || (size >= 18.66 && weight >= 700);
      var need = large ? 3 : 4.5, rt = ratio(fgc, bg.c);
      if (rt + 0.005 < need) add('1.4.3', 'contrast', 'text ' + hex(fgc) + ' on ' + hex(bg.c) + ' is ' + r2(rt) + ':1 (needs ' + need + ':1)', el,
        { fg: hex(fgc), bg: hex(bg.c), ratio: r2(rt), need: need, text: node.nodeValue.trim().slice(0, 40), unknown: bg.unknown ? describe(bg.unknown) : null });
    }
    /* placeholders */
    all.forEach(function (e) {
      if (!e.matches('input[placeholder], textarea[placeholder]') || e.value || !shown(e) || disabled(e)) return;
      var pc = parse(getComputedStyle(e, '::placeholder').color), bg = bgUnder(e, false);
      if (!pc) return;
      var c = over(pc, bg.c), rt = ratio(c, bg.c);
      if (rt + 0.005 < 4.5) add('1.4.3', 'contrast', 'placeholder ' + hex(c) + ' on ' + hex(bg.c) + ' is ' + r2(rt) + ':1 (needs 4.5:1)', e, { fg: hex(c), bg: hex(bg.c), ratio: r2(rt), need: 4.5, text: e.placeholder.slice(0, 40) });
    });
    /* non-text contrast: field outlines, checkbox and radio glyphs, switches, icon-only controls */
    all.forEach(function (e) {
      if (kit(e) || !shown(e) || disabled(e)) return;
      var cs, out, rt;
      if (e.matches('.rp-field-box') && !e.closest('.rp-select-inline')) {
        cs = getComputedStyle(e); out = bgUnder(e, true).c;
        var bw = parseFloat(cs.borderTopWidth) || 0, bc = parse(cs.borderTopColor), fill = parse(cs.backgroundColor);
        var a = bw && bc ? ratio(over(bc, out), out) : 1, b = fill ? ratio(over(fill, out), out) : 1;
        rt = Math.max(a, b);
        if (rt + 0.005 < 3) add('1.4.11', 'non-text', 'field outline ' + (bc ? hex(over(bc, out)) : 'none') + ' on ' + hex(out) + ' is ' + r2(rt) + ':1 (needs 3:1 to see the field)', e, { fg: bc ? hex(over(bc, out)) : '', bg: hex(out), ratio: r2(rt), need: 3 });
      }
      if (e.matches('input.rp-checkbox, input.rp-radio')) {
        var img = getComputedStyle(e).backgroundImage || '', m = /fill=(?:'|%27|\\'|\\")?%23([0-9a-fA-F]{6})/.exec(img);
        if (m) {
          var gc = parse('#' + m[1]); out = bgUnder(e, true).c; rt = ratio(gc, out);
          if (rt + 0.005 < 3) add('1.4.11', 'non-text', (e.type === 'radio' ? 'radio' : 'checkbox') + ' ' + hex(gc) + ' on ' + hex(out) + ' is ' + r2(rt) + ':1 (needs 3:1)', e, { fg: hex(gc), bg: hex(out), ratio: r2(rt), need: 3 });
        }
      }
      if (e.matches('.rp-switch')) {
        cs = getComputedStyle(e); out = bgUnder(e, true).c;
        var tr = parse(cs.backgroundColor), brd = parse(cs.borderTopColor), bwid = parseFloat(cs.borderTopWidth) || 0;
        rt = Math.max(tr ? ratio(over(tr, out), out) : 1, bwid && brd ? ratio(over(brd, out), out) : 1);
        if (rt + 0.005 < 3) add('1.4.11', 'non-text', 'switch track ' + (tr ? hex(over(tr, out)) : '') + ' on ' + hex(out) + ' is ' + r2(rt) + ':1 (needs 3:1)', e, { fg: tr ? hex(over(tr, out)) : '', bg: hex(out), ratio: r2(rt), need: 3 });
      }
      if (e.matches('button, a[href], [role="button"]') && !label(e).length) return;
      if (e.matches('button, a[href], [role="button"], [role="tab"]') && !e.textContent.trim()) {
        var ic = e.querySelector('.rp-icon:not(.rp-icon-multicolor)');
        if (ic && shown(ic)) {
          var icol = parse(getComputedStyle(ic).backgroundColor);
          if (icol && icol.a > 0) {
            var ib = bgUnder(ic, true).c, icc = over({ r: icol.r, g: icol.g, b: icol.b, a: icol.a * opacityOf(ic) }, ib);
            rt = ratio(icc, ib);
            if (rt + 0.005 < 3) add('1.4.11', 'non-text', 'icon-only control: icon ' + hex(icc) + ' on ' + hex(ib) + ' is ' + r2(rt) + ':1 (needs 3:1)', e, { fg: hex(icc), bg: hex(ib), ratio: r2(rt), need: 3 });
          }
        }
      }
    });
    /* charts: colour alone (1.4.1) and data marks (1.4.11) */
    [].forEach.call(doc.querySelectorAll('svg'), function (svg) {
      if (kit(svg) || !shown(svg)) return;
      var segs = [].filter.call(svg.querySelectorAll('circle[pathLength][stroke-dasharray]'), function (c) { return parseFloat(c.getAttribute('stroke-dasharray')) > 0; });
      var colours = new Set(segs.map(function (c) { return hex(parse(getComputedStyle(c).stroke) || { r: 0, g: 0, b: 0 }); }));
      var holder = svg.closest('.summary-item, .kit-kpi, .rp-tile-content, .rp-tile') || svg.parentElement;
      if (colours.size > 1 && !(holder && holder.querySelector('.kit-legend'))) add('1.4.1', 'colour', 'chart with ' + colours.size + ' colours and no legend: what each colour means is told by colour alone', svg);
      var bg = bgUnder(svg, true).c;
      segs.forEach(function (c) {
        var col = parse(getComputedStyle(c).stroke); if (!col) return;
        var rt = ratio(over(col, bg), bg);
        if (rt + 0.005 < 3) add('1.4.11', 'chart', 'chart segment ' + hex(over(col, bg)) + ' on ' + hex(bg) + ' is ' + r2(rt) + ':1 (3:1 unless the values are in text next to it)', c, { fg: hex(over(col, bg)), bg: hex(bg), ratio: r2(rt), need: 3 });
      });
      if (svg.classList.contains('kit-chart')) {
        var series = [].filter.call(svg.querySelectorAll('polyline, path'), function (p) { var s = getComputedStyle(p); return (s.fill !== 'none' || s.stroke !== 'none'); });
        if (series.length > 1) { var tile = svg.closest('.rp-tile, .rp-tile-content') || svg.parentElement; if (!tile.querySelector('.kit-legend')) add('1.4.1', 'colour', 'line chart with ' + series.length + ' series and no legend', svg); }
        series.forEach(function (p) {
          var s = getComputedStyle(p), sc = s.stroke !== 'none' ? parse(s.stroke) : null, fc = s.fill !== 'none' ? parse(s.fill) : null;
          var sw = parseFloat(s.strokeWidth) || 0, op = parseFloat(s.opacity) || 1;
          var best = Math.max(sc && sw ? ratio(over({ r: sc.r, g: sc.g, b: sc.b, a: sc.a * op }, bg), bg) : 1, fc ? ratio(over({ r: fc.r, g: fc.g, b: fc.b, a: fc.a * op * (parseFloat(s.fillOpacity) || 1) }, bg), bg) : 1);
          if (best + 0.005 < 3) add('1.4.11', 'chart', (fc ? 'area' : 'line') + ' ' + p.tagName + ' is ' + r2(best) + ':1 on ' + hex(bg) + ' (3:1 for the line or the edge of the area)', p, { ratio: r2(best), need: 3 });
        });
      }
    });
    /* target size (2.5.8): 24x24, or spaced so 24px circles do not overlap other targets */
    var targets = all.filter(function (e) { return e.matches('button, a[href], input:not([type="hidden"]), [role="button"], [role="tab"], [role="switch"], [role="checkbox"]') && shown(e) && !disabled(e) && !kit(e); });
    var boxes = targets.map(function (e) { return { e: e, r: e.getBoundingClientRect() }; });
    boxes.forEach(function (b) {
      if (b.r.width >= 24 && b.r.height >= 24) return;
      if (b.e.matches('.rp-side-bar-toggle') && doc.querySelector('[data-rp-side-bar-toggle]')) return; /* equivalent 32px control in the rail */
      if (b.e.matches('a') && b.e.closest('p, li, td, .rp-alert, .rp-disclaimer') && getComputedStyle(b.e).display === 'inline') return; /* inline link in text */
      var cx = b.r.left + b.r.width / 2, cy = b.r.top + b.r.height / 2;
      var hit = boxes.filter(function (o) {
        if (o === b || o.e.contains(b.e) || b.e.contains(o.e)) return false;
        var small = o.r.width < 24 || o.r.height < 24;
        if (small) { var ox = o.r.left + o.r.width / 2, oy = o.r.top + o.r.height / 2; return Math.hypot(cx - ox, cy - oy) < 24; }
        var dx = Math.max(o.r.left - cx, 0, cx - o.r.right), dy = Math.max(o.r.top - cy, 0, cy - o.r.bottom);
        return Math.hypot(dx, dy) < 12;
      });
      if (hit.length) add('2.5.8', 'target', 'target ' + Math.round(b.r.width) + 'x' + Math.round(b.r.height) + 'px is closer than 24px to ' + describe(hit[0].e), b.e);
    });
    return out;
  };

  /* ── focus: how each focusable looks before the walk ── */
  var PROPS = ['outlineStyle', 'outlineWidth', 'outlineColor', 'outlineOffset', 'boxShadow', 'borderTopColor', 'borderRightColor', 'borderBottomColor', 'borderLeftColor',
    'borderTopWidth', 'backgroundColor', 'color', 'textDecorationLine'];
  function snap(el) {
    var o = {};
    if (!el || el.nodeType !== 1) return o;
    var cs = getComputedStyle(el);
    PROPS.forEach(function (p) { o[p] = cs[p]; });
    ['::before', '::after'].forEach(function (ps) { var s = getComputedStyle(el, ps); o[ps] = [s.content, s.backgroundColor, s.height, s.width, s.boxShadow, s.borderTopColor, s.opacity].join('|'); });
    return o;
  }
  function chain(el) { var c = [el], n = el.parentElement; for (var i = 0; i < 2 && n; i++, n = n.parentElement) c.push(n); var k = el.querySelector(':scope > .rp-field-box, :scope > .rp-switch'); if (k) c.push(k); return c; }
  var base = new WeakMap(), ids = new WeakMap(), nextId = 1;
  function idOf(el) { if (!ids.has(el)) ids.set(el, nextId++); return ids.get(el); }
  A.baseline = function () {
    var list = [].filter.call(doc.querySelectorAll(FOCUSABLE), focusable).filter(function (e) { return !e.closest('#dl-tweak-host') && e.getAttribute('data-a11y-probe') !== 'start'; });
    if (doc.activeElement && doc.activeElement !== doc.body) doc.activeElement.blur();
    list.forEach(function (e) { base.set(e, chain(e).map(snap)); });
    /* expected tab stops: radios count once per group */
    var groups = {};
    var expect = list.filter(function (e) {
      if (!e.matches('input[type="radio"]') || !e.name) return true;
      var g = groups[e.name] || (groups[e.name] = [].filter.call(doc.querySelectorAll('input[type="radio"][name="' + CSS.escape(e.name) + '"]'), focusable));
      var chk = g.filter(function (x) { return x.checked; })[0];
      return chk ? e === chk : e === g[0];
    });
    return expect.map(function (e) { return { id: idOf(e), el: describe(e), where: where(e), kit: kit(e) }; });
  };
  function shadowColours(s) {
    if (!s || s === 'none') return [];
    return (s.match(/(rgba?\([^)]+\)|color\([^)]+\)|#[0-9a-fA-F]{3,8})/g) || []).map(parse).filter(Boolean);
  }
  A.step = function () {
    var el = doc.activeElement;
    if (!el || el === doc.body || el === doc.documentElement || el.getAttribute('data-a11y-probe') === 'start') return { body: true };
    var res = { id: idOf(el), el: describe(el), where: where(el), kit: kit(el), shown: shown(el) };
    var b = base.get(el);
    if (!b) { res.unchecked = true; return res; }
    var now = chain(el).map(snap), changes = [];
    var outside = bgUnder(el, true).c, inside = bgUnder(el, false).c;
    now.forEach(function (o, i) {
      var was = b[i] || {};
      var node = chain(el)[i];
      var outlineNow = o.outlineStyle !== 'none' && parseFloat(o.outlineWidth) > 0;
      var outlineWas = was.outlineStyle && was.outlineStyle !== 'none' && parseFloat(was.outlineWidth) > 0;
      var outlineChanged = outlineNow && (!outlineWas || o.outlineColor !== was.outlineColor || o.outlineWidth !== was.outlineWidth || o.outlineOffset !== was.outlineOffset);
      PROPS.concat(['::before', '::after']).forEach(function (p) {
        if (p === 'outlineColor' ? !outlineChanged : o[p] === was[p]) return;
        if (/^(outlineStyle|outlineWidth|outlineOffset|borderTopWidth)$/.test(p)) return; /* read with the outline colour */
        var c = null, against = outside, how = p;
        if (p === 'outlineColor') {
          c = parse(o.outlineColor); against = parseFloat(o.outlineOffset) < 0 ? bgUnder(node, false).c : bgUnder(node, true).c; how = 'outline ' + o.outlineWidth;
        } else if (p === 'boxShadow') {
          var cols = shadowColours(o.boxShadow); if (!cols.length) return;
          var bestc = null, bestr = 0;
          cols.forEach(function (sc) { var r = ratio(over(sc, outside), outside); if (r > bestr) { bestr = r; bestc = sc; } });
          c = bestc; how = 'ring';
        } else if (/^border\w+Color$/.test(p)) { c = parse(o[p]); how = 'border'; }
        else if (p === 'backgroundColor') { c = parse(o[p]); against = bgUnder(node, true).c; how = 'fill'; }
        else if (p === 'color') { c = parse(o[p]); against = parse(was[p]) || inside; how = 'text colour'; }
        else if (p === 'textDecorationLine') { if (!/underline/.test(o[p])) return; c = parse(getComputedStyle(node).color); against = inside; how = 'underline'; }
        else if (p === '::before' || p === '::after') { var pc = (o[p] || '').split('|'); if (pc[0] === 'none' && pc[1] === 'rgba(0, 0, 0, 0)') return; c = parse(pc[1]) || parse(pc[5]); how = 'mark (' + p + ')'; }
        if (!c || c.a === 0) return;
        changes.push({ how: how, ratio: r2(ratio(over(c, against), against)), colour: hex(over(c, against)), against: hex(against) });
      });
    });
    res.visible = changes.length > 0;
    res.changes = changes;
    res.best = changes.reduce(function (m, c) { return c.ratio > m.ratio ? c : m; }, { ratio: 0 });
    /* hidden by sticky or fixed parts (2.4.11) */
    var r = el.getBoundingClientRect(), pts = [[0.5, 0.5], [0.15, 0.2], [0.85, 0.2], [0.15, 0.8], [0.85, 0.8]], covered = 0, by = null;
    pts.forEach(function (p) {
      var x = r.left + r.width * p[0], y = r.top + r.height * p[1];
      if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) { covered++; by = by || 'outside the window'; return; }
      var top = doc.elementFromPoint(x, y);
      if (!top || top === el || el.contains(top) || top.contains(el)) return;
      for (var n = top; n && n.nodeType === 1; n = n.parentElement) {
        var pos = getComputedStyle(n).position;
        if (pos === 'fixed' || pos === 'sticky') { covered++; by = by || describe(n); return; }
      }
    });
    res.hidden = covered === pts.length ? 'full' : covered ? 'partial' : 'none';
    res.hiddenBy = by;
    return res;
  };

  /* ── keyboard flows ── */
  A.probe = function (css, n) {
    var list = [].filter.call(doc.querySelectorAll(css), function (e) { return focusable(e) && !kit(e) && !e.closest('.rp-menu:not(.open)'); }).slice(0, n || 1);
    return list.map(function (e) { var id = 'p' + idOf(e); e.setAttribute('data-a11y-probe', id); return { id: id, el: describe(e) }; });
  };
  A.focusProbe = function (id) { var e = doc.querySelector('[data-a11y-probe="' + id + '"]'); if (!e) return false; e.focus(); return doc.activeElement === e; };
  A.flowState = function (id) {
    var e = doc.querySelector('[data-a11y-probe="' + id + '"]'), act = doc.activeElement;
    var menu = doc.querySelector('.rp-menu.open'), overlay = doc.querySelector('.rp-dialog-overlay.open, .rp-drawer-overlay.open');
    var panel = doc.querySelector('.rp-side-bar-panel.open');
    var tip = doc.querySelector('.rp-tooltip:not([hidden])');
    return {
      onProbe: act === e, focus: describe(act), expanded: e ? e.getAttribute('aria-expanded') : null,
      menuOpen: !!menu, inMenu: !!(menu && menu.contains(act)), overlayOpen: !!overlay,
      inOverlay: !!(overlay && (overlay.querySelector('.rp-dialog, .rp-drawer') || overlay).contains(act)),
      panelOpen: !!panel, tip: !!(tip && shown(tip)), selected: e ? e.getAttribute('aria-selected') : null,
      tabSelected: act && act.getAttribute ? act.getAttribute('aria-selected') : null,
      snackbar: (function () { var s = doc.querySelector('.rp-snackbar'); if (!s) return null; var live = s.closest('[role="status"], [role="alert"], [aria-live]'); return { live: !!live, role: live ? (live.getAttribute('role') || 'aria-live=' + live.getAttribute('aria-live')) : '' }; })(),
      inMain: !!(act && act.closest && act.closest('main, [role="main"]'))
    };
  };
  A.skipLink = function () { var s = doc.querySelector('a.v2-skip-link, a[data-rp-skip-link]'); return s ? { id: idOf(s), href: s.getAttribute('href') } : null; };
  A.reset = function () {
    var s = doc.querySelector('[data-a11y-probe="start"]');
    if (!s) { s = doc.createElement('span'); s.setAttribute('tabindex', '-1'); s.setAttribute('data-a11y-probe', 'start'); s.style.cssText = 'position:absolute;top:0;left:0;width:1px;height:1px;overflow:hidden'; doc.body.insertBefore(s, doc.body.firstChild); }
    window.scrollTo(0, 0);
    s.focus({ preventScroll: true });
    return doc.activeElement === s;
  };
  /* wait until no CSS transition or animation is running (after a theme switch), at most ms */
  A.settle = function (ms) {
    var end = Date.now() + (ms || 1500);
    return new Promise(function (res) {
      (function check() {
        var busy = doc.getAnimations().filter(function (a) { return a.playState === 'running' && a.effect && a.effect.getTiming().iterations !== Infinity; });
        if (!busy.length || Date.now() > end) return res(busy.length);
        setTimeout(check, 50);
      })();
    });
  };

  /* ── motion and reflow ── */
  A.motion = function () {
    return doc.getAnimations().filter(function (a) {
      var t = a.effect && a.effect.target;
      return a.playState === 'running' && t && !kit(t) && !(t.closest && t.closest('.rp-loader, .rp-progress-bar-indeterminate'));
    }).map(function (a) {
      var t = a.effect.target, tm = a.effect.getTiming();
      return { el: describe(t), name: a.animationName || a.transitionProperty || 'script', iterations: tm.iterations === Infinity ? 'endless' : tm.iterations, duration: tm.duration };
    });
  };
  A.reflow = function () {
    var chrome = [].slice.call(doc.querySelectorAll(KIT_CHROME)), was = chrome.map(function (e) { return e.style.display; });
    chrome.forEach(function (e) { e.style.display = 'none'; });   /* the kit's own controls are not part of the product */
    var w = doc.documentElement.clientWidth, sw = doc.documentElement.scrollWidth;
    chrome.forEach(function (e, i) { e.style.display = was[i]; });
    var wide = [].filter.call(doc.querySelectorAll('body *'), function (e) {
      if (kit(e) || !shown(e) || e.closest('table, svg, .rp-tile-table, pre, code')) return false;
      var r = e.getBoundingClientRect(); return r.right > w + 1 && r.width < w * 3;
    }).slice(0, 5).map(describe);
    var clipped = [].filter.call(doc.querySelectorAll('button, .rp-chip, .rp-tab, label, .rp-menu-item, .rp-side-bar-panel-item, h1, h2, h3, p, li'), function (e) {
      if (kit(e) || !shown(e)) return false;
      var cs = getComputedStyle(e);
      if (cs.textOverflow === 'ellipsis') return false;
      return (cs.overflow === 'hidden' || cs.overflowX === 'hidden' || cs.overflowY === 'hidden') && (e.scrollWidth > e.clientWidth + 2 || e.scrollHeight > e.clientHeight + 2);
    }).slice(0, 5).map(describe);
    return { scrollsSideways: sw > w + 2, viewport: w, contentWidth: sw, wide: wide, clipped: clipped };
  };
  A.textSpacing = function () {
    var st = doc.createElement('style'); st.setAttribute('data-a11y-probe', 'spacing');
    st.textContent = '* { line-height: 1.5 !important; letter-spacing: 0.12em !important; word-spacing: 0.16em !important; } p { margin-bottom: 2em !important; }';
    doc.head.appendChild(st);
    return true;
  };
})();
