#!/usr/bin/env python3
"""Windows variant of keep-version.sh (same rules: one version per Kiro task until it is named
in names.json): before Kiro writes a page, keep it in
.tweak-history/<page>/<date>_<time>__kiro.html so it shows up in Tweak's Save & history.
  python .kiro/scripts/keep-version.py --windows-only     (Kiro hook, reads the hook JSON on stdin)
  python .kiro/scripts/keep-version.py mockups/x/a.html   (before a shell edit)"""
import json, os, re, shutil, sys, time
def main(argv):
    if "--windows-only" in argv and os.name != "nt":
        return
    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
    args = [a for a in argv if not a.startswith("--")]
    p = args[0] if args else ""
    if not p:
        raw = sys.stdin.read()
        m = re.search(r'"(?:path|targetFile)"\s*:\s*"((?:[^"\\]|\\.)*)"', raw)
        p = json.loads('"' + m.group(1) + '"') if m else ""
    n = p.replace("\\", "/")
    if not re.search(r"\.html?$", n) or "/.tweak-history/" in n or "/__" in n: return
    if not re.search(r"mockups/|design-system/examples/|design-system/foundation/tweak/tweak-ui\.html", n): return
    if not os.path.isfile(p): return
    h = os.path.join(os.path.dirname(p), ".tweak-history", os.path.splitext(os.path.basename(p))[0])
    os.makedirs(h, exist_ok=True)
    vers = sorted([f for f in os.listdir(h) if re.search(r"__[a-z]+\.html$", f)], key=lambda f: (os.path.getmtime(os.path.join(h, f)), f), reverse=True)
    if vers:
        newest = os.path.join(h, vers[0])
        if open(newest, "rb").read() == open(p, "rb").read(): return
        names = os.path.join(h, "names.json")
        named = os.path.isfile(names) and ('"' + vers[0] + '"') in open(names, encoding="utf-8", errors="ignore").read()
        if vers[0].endswith("__kiro.html") and time.time() - os.path.getmtime(newest) < 900 and not named: return
    shutil.copyfile(p, os.path.join(h, time.strftime("%Y-%m-%d_%H-%M-%S") + "__kiro.html"))
    for old in sorted([f for f in os.listdir(h) if re.search(r"__[a-z]+\.html$", f)], reverse=True)[40:]:
        os.remove(os.path.join(h, old))
if __name__ == "__main__":
    try: main(sys.argv[1:])
    except Exception: pass
