#!/usr/bin/env python3
"""
Build the kit website and the download zip (maintainer script).

Writes:
  download/kiro-mockup-designer.zip   the kit people download: .kiro/, design-system/, templates/ (with .figma/),
                                      mockups/example-*/, index.html, README.md, .gitignore
  public/                             the static website: index.html, design-system/, mockups/example-*/, download/
                                      Publish this folder on any static host (GitLab Pages, GitHub Pages, an internal server).

Usage:
  python3 .kiro/scripts/build-site.py            # check, then build
  python3 .kiro/scripts/build-site.py --serve    # build, then preview on http://localhost:8000
Python 3.9+, standard library only. Refuses to build when check-mockup.py --all reports errors.
"""
import http.server
import os
import shutil
import socketserver
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
NAME = "kiro-mockup-designer"
SKIP_NAMES = {".DS_Store", "__pycache__", ".tweak-history", "tweak-changes.md", ".playwright-mcp", ".agents"}
KIT_ITEMS = [".kiro", "design-system", "templates", "index.html", "README.md", ".gitignore"]
SITE_ITEMS = ["index.html", "design-system"]


def skip(path):
    parts = set(path.relative_to(ROOT).parts)
    if parts & SKIP_NAMES:
        return True
    rel = path.relative_to(ROOT).as_posix()
    return rel.startswith((".kiro/tmp", ".kiro/specs", ".kiro/settings"))


def files_of(item):
    p = ROOT / item
    if p.is_file():
        yield p
        return
    for f in sorted(p.rglob("*")):
        if f.is_file() and not skip(f):
            yield f


def examples():
    return sorted(d for d in (ROOT / "mockups").glob("example-*") if d.is_dir())


def build_zip():
    out = ROOT / "download" / (NAME + ".zip")
    out.parent.mkdir(exist_ok=True)
    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for item in KIT_ITEMS + ["mockups/" + d.name for d in examples()]:
            for f in files_of(item):
                z.write(f, NAME + "/" + f.relative_to(ROOT).as_posix())
                count += 1
        z.writestr(NAME + "/mockups/.gitkeep", "")
    print("download/%s.zip: %d files, %d KB" % (NAME, count, out.stat().st_size // 1024))
    return out


def build_public(zip_path):
    pub = ROOT / "public"
    if pub.exists():
        shutil.rmtree(pub)
    pub.mkdir()
    for item in SITE_ITEMS + ["mockups/" + d.name for d in examples()]:
        for f in files_of(item):
            dest = pub / f.relative_to(ROOT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dest)
    (pub / "download").mkdir()
    shutil.copy2(zip_path, pub / "download" / zip_path.name)
    size = sum(f.stat().st_size for f in pub.rglob("*") if f.is_file()) // 1024
    print("public/: website ready (%d KB). Open public/index.html or publish the folder." % size)
    return pub


def main():
    r = subprocess.run([sys.executable, str(ROOT / ".kiro" / "scripts" / "check-mockup.py"), "--all"], capture_output=True, text=True)
    if r.returncode:
        print(r.stdout[-3000:])
        sys.exit("check-mockup.py --all reports errors: fix them before building the site.")
    subprocess.run([sys.executable, str(ROOT / ".kiro" / "scripts" / "generate-index.py")], check=False)
    pub = build_public(build_zip())
    if "--serve" in sys.argv:
        os.chdir(pub)
        with socketserver.TCPServer(("127.0.0.1", 8000), http.server.SimpleHTTPRequestHandler) as httpd:
            print("Preview: http://localhost:8000  (Ctrl+C to stop)")
            httpd.serve_forever()


if __name__ == "__main__":
    main()
