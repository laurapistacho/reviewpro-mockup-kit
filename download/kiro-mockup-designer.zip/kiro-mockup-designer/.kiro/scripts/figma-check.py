"""
Figma fidelity check (maintainer script): renders kit components and compares them, pixel by pixel,
with PNG renders of the matching Figma UI App components.

Inputs:
  design-system/figma/checks.json   one entry per component variant:
      {"id": "button/large-primary-filled", "node": "76:9778", "kit": "<button class=...>", "bg": "#FFFFFF"}
      node = the Figma component (variant) id in file ubE7R2jeqiwS8BZ4a5vwHw; kit = the kit markup that should
      look the same (same text, same icon). Optional: bg (colour behind it, default white), box (CSS for the wrapper,
      e.g. "width:764px" for fixed-width components), at ("x,y" where the component sits in the export when Figma
      added room for a shadow), region ("x,y,w,h" to compare part of it), threshold (%), snap (round text widths
      up like Figma), known (true = a documented Figma/product difference: reported, not failed), note.
  design-system/figma/ref/<node>.png  the Figma render at scale 1 (export with the Figma MCP, see below).

Output: one line per check with the share of pixels that differ, and design-system/figma/out/<id>.png
(Figma | kit | difference) for every check above the threshold. Exit code 1 when a check fails.

Usage:
  python3 .kiro/scripts/figma-check.py                   # all checks, threshold 3%
  python3 .kiro/scripts/figma-check.py button chip       # only ids that start with these prefixes
  python3 .kiro/scripts/figma-check.py --threshold 1.5
  python3 .kiro/scripts/figma-check.py --missing         # print the Figma nodes that still need a reference PNG

Refreshing the references: with the Figma MCP, call download_figma_images on file ubE7R2jeqiwS8BZ4a5vwHw with
pngScale 1 and fileName "<node with : replaced by ->.png" for every node, then copy the files to
design-system/figma/ref/. Text anti-aliasing alone gives 0.2-1% (Figma and Chrome rasterise text differently);
a wrong size, colour, radius or spacing gives far more.
Python 3.9+, standard library only, plus Google Chrome.
"""
import argparse
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
FIG = ROOT / "design-system" / "figma"
FOUND = ROOT / "design-system" / "foundation"
CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
]


def chrome():
    for c in CHROME_CANDIDATES:
        if os.path.exists(c):
            return c
    found = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chrome")
    if not found:
        sys.exit("Google Chrome not found: install it or add it to CHROME_CANDIDATES in this script.")
    return found


# ---------- PNG (8-bit RGB / RGBA / grey, non-interlaced) ----------
def png_read(path):
    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG: %s" % path)
    pos, idat, w = 8, b"", 0
    while pos < len(data):
        n, typ = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, inter = struct.unpack(">IIBBBBB", body)
            if depth != 8 or inter:
                raise ValueError("unsupported PNG (need 8-bit, non-interlaced): %s" % path)
        elif typ == b"PLTE":
            plte = body
        elif typ == b"IDAT":
            idat += body
        pos += 12 + n
    bpp = {0: 1, 2: 3, 4: 2, 6: 4, 3: 1}[ctype]
    raw = zlib.decompress(idat)
    stride = w * bpp
    out = bytearray(h * stride)
    prev = bytearray(stride)
    i = 0
    for y in range(h):
        f = raw[i]
        line = bytearray(raw[i + 1:i + 1 + stride])
        i += 1 + stride
        if f == 1:
            for x in range(bpp, stride):
                line[x] = (line[x] + line[x - bpp]) & 255
        elif f == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif f == 3:
            for x in range(stride):
                left = line[x - bpp] if x >= bpp else 0
                line[x] = (line[x] + ((left + prev[x]) >> 1)) & 255
        elif f == 4:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                b = prev[x]
                c = prev[x - bpp] if x >= bpp else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = line
    rgba = bytearray(w * h * 4)
    for p in range(w * h):
        s = p * bpp
        if ctype == 6:
            rgba[p * 4:p * 4 + 4] = out[s:s + 4]
        elif ctype == 2:
            rgba[p * 4:p * 4 + 3] = out[s:s + 3]; rgba[p * 4 + 3] = 255
        elif ctype == 3:
            k = out[s] * 3
            rgba[p * 4:p * 4 + 3] = plte[k:k + 3]; rgba[p * 4 + 3] = 255
        elif ctype == 4:
            rgba[p * 4:p * 4 + 3] = bytes([out[s]] * 3); rgba[p * 4 + 3] = out[s + 1]
        else:
            rgba[p * 4:p * 4 + 3] = bytes([out[s]] * 3); rgba[p * 4 + 3] = 255
    return w, h, rgba


def png_write(path, w, h, rgb):
    raw = b"".join(b"\x00" + bytes(rgb[y * w * 3:(y + 1) * w * 3]) for y in range(h))
    def chunk(t, b):
        return struct.pack(">I", len(b)) + t + b + struct.pack(">I", zlib.crc32(t + b) & 0xFFFFFFFF)
    Path(path).write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                           + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def flatten(w, h, rgba, bg):
    """RGBA over a solid background, cropped/padded to w x h -> RGB bytes."""
    return bytes(round(rgba[p * 4 + c] * rgba[p * 4 + 3] / 255 + bg[c] * (255 - rgba[p * 4 + 3]) / 255)
                 for p in range(w * h) for c in range(3))


def crop(w, h, rgba, cw, ch, bg):
    out = bytearray()
    for y in range(ch):
        for x in range(cw):
            if x < w and y < h:
                out += rgba[(y * w + x) * 4:(y * w + x) * 4 + 4]
            else:
                out += bytes(bg) + b"\xff"
    return out


def sub(w, rgba, x, y, cw, ch):
    out = bytearray()
    for yy in range(y, y + ch):
        out += rgba[(yy * w + x) * 4:(yy * w + x + cw) * 4]
    return out


def hex_rgb(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


# ---------- render ----------
PAGE = """<!doctype html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700&display=block">
<link rel="stylesheet" href="{found}/shared.css"><link rel="stylesheet" href="{found}/rp-icons.css">
<style>html,body{{margin:0;background:{bg}}} #c{{position:absolute;left:{x}px;top:{y}px;{size}}} *{{transition:none!important;animation:none!important}}</style>
</head><body><div id="c">{kit}</div>{snap}</body></html>"""
# Figma rounds the width of auto-width text up to a whole pixel; Chrome keeps fractions. Without this, a label 0.4px
# narrower shifts everything after it and the anti-aliasing reads as a difference.
SNAP = """<script>(function () {{ var c = document.getElementById('c'), w = document.createTreeWalker(c, NodeFilter.SHOW_TEXT), t = [];
  while (w.nextNode()) {{ var n = w.currentNode; if (n.nodeValue.trim() && !n.parentNode.closest('script,style,textarea')) t.push(n); }}
  t.forEach(function (n) {{ var s = document.createElement('span'); n.parentNode.insertBefore(s, n); s.appendChild(n);
    var r = s.getBoundingClientRect().width; s.style.display = 'inline-block'; s.style.whiteSpace = 'nowrap'; s.style.width = Math.ceil(r - 0.01) + 'px'; }});
}})();</script>"""


def render(chrome_bin, entry, w, h, tmp):
    bg = entry.get("bg", "#FFFFFF")
    size = entry.get("box", "")  # e.g. "width:400px" when the Figma frame is a fixed width
    x, y = (int(v) for v in entry.get("at", "0,0").split(","))  # where the component sits in the Figma export (shadows)
    html = PAGE.format(found=FOUND.as_uri(), bg=bg, kit=entry["kit"], size=size, x=x, y=y,
                       snap=SNAP.replace("{{", "{").replace("}}", "}") if entry.get("snap") else "")
    page = Path(tmp) / "c.html"
    shot = Path(tmp) / "c.png"
    page.write_text(html, encoding="utf-8")
    ww, wh = max(w + 16, 500), max(h + 16, 300)
    if shot.exists():
        shot.unlink()
    subprocess.run([chrome_bin, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
                    "--force-device-scale-factor=1", "--font-render-hinting=none", "--allow-file-access-from-files",
                    "--virtual-time-budget=2500", "--window-size=%d,%d" % (ww, wh),
                    "--user-data-dir=" + str(Path(tmp) / "profile"), "--screenshot=" + str(shot), page.as_uri()],
                   capture_output=True, timeout=60)
    if not shot.exists():
        raise RuntimeError("Chrome did not write a screenshot")
    return png_read(shot)


def compare(fig, kit, w, h, bg):
    a = flatten(w, h, fig, bg)
    b = flatten(w, h, kit, bg)
    bad = 0
    diff = bytearray(w * h * 3)
    for p in range(w * h):
        d = max(abs(a[p * 3 + c] - b[p * 3 + c]) for c in range(3))
        if d > 48:
            bad += 1
            diff[p * 3:p * 3 + 3] = b"\xff\x00\xff"
        else:
            g = 235 - d
            diff[p * 3:p * 3 + 3] = bytes([g, g, g])
    return 100.0 * bad / (w * h), a, b, bytes(diff)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prefix", nargs="*")
    ap.add_argument("--threshold", type=float, default=3.0)
    ap.add_argument("--missing", action="store_true")
    args = ap.parse_args()
    checks = json.loads((FIG / "checks.json").read_text(encoding="utf-8"))["checks"]
    if args.prefix:
        checks = [c for c in checks if any(c["id"].startswith(p) for p in args.prefix)]
    ref = FIG / "ref"
    if not ref.is_dir():
        sys.exit("No Figma renders in %s. They are maintainer data: run from the kit's git repository (the download leaves them out)." % ref)
    if args.missing:
        miss = [c["node"] for c in checks if not (ref / (c["node"].replace(":", "-") + ".png")).exists()]
        print(json.dumps(miss))
        return 0
    out = FIG / "out"
    out.mkdir(exist_ok=True)
    chrome_bin = chrome()
    fails = 0
    with tempfile.TemporaryDirectory() as tmp:
        for c in checks:
            rp = ref / (c["node"].replace(":", "-") + ".png")
            if not rp.exists():
                print("%-44s  no reference (%s)" % (c["id"], rp.name))
                continue
            stale = out / (c["id"].replace("/", "__") + ".png")
            if stale.exists():
                stale.unlink()
            w, h, fig = png_read(rp)
            try:
                kw, kh, kit = render(chrome_bin, c, w, h, tmp)
            except Exception as e:  # noqa: BLE001 - report and continue
                print("%-44s  render failed: %s" % (c["id"], e))
                fails += 1
                continue
            bg = hex_rgb(c.get("bg", "#FFFFFF"))
            kit = crop(kw, kh, kit, w, h, bg)
            if c.get("region"):  # compare only part of the component (x,y,w,h in the Figma render)
                rx, ry, rw, rh = (int(v) for v in c["region"].split(","))
                fig = sub(w, fig, rx, ry, rw, rh)
                kit = sub(w, kit, rx, ry, rw, rh)
                w, h = rw, rh
            pct, a, b, d = compare(fig, kit, w, h, bg)
            ok = pct <= c.get("threshold", args.threshold)
            known = not ok and c.get("known")  # a documented Figma/product difference, see design-system/figma/README.md
            fails += 0 if ok or known else 1
            print("%-44s  %5.2f%%  %s  %dx%d  %s" % (c["id"], pct, "ok  " if ok else "known" if known else "FAIL", w, h, c.get("note", "")))
            if not ok:
                gap = 8
                W = w * 3 + gap * 2
                rows = bytearray()
                for y in range(h):
                    for img in (a, b, d):
                        rows += img[y * w * 3:(y + 1) * w * 3]
                        if img is not d:
                            rows += b"\x88\x88\x88" * gap
                png_write(out / (c["id"].replace("/", "__") + ".png"), W, h, rows)
    print("%d check(s) above the threshold%s" % (fails, " (side-by-side images in design-system/figma/out/)" if fails else ""))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
