#!/bin/sh
# Create a new mockup folder from templates/ + the closest pattern example(s).
# macOS / Linux. Needs only sh, cp, sed (built into macOS). Windows: new-mockup.py.
#
# Usage:
#   sh .kiro/scripts/new-mockup.sh <mockup-name> [pattern[:file.html]] ...
#
#   pattern   number (01) or example file name (01-dashboard-grid.html)
#   :file     target file name; default is index.html for the first pattern,
#             the example name without its number for the others (10-itinerary.html -> itinerary.html)
#
# Examples:
#   sh .kiro/scripts/new-mockup.sh rate-plans 01
#   sh .kiro/scripts/new-mockup.sh guest-flow 01 17:profile.html 19:wizard.html
#
# Never overwrites: fails if mockups/<mockup-name> already exists.
set -eu
cd "$(dirname "$0")/../.."

name=${1:-}
if [ -z "$name" ]; then
  sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'
  exit 2
fi
shift
case "$name" in
  *[!a-z0-9-]*|-*) echo "Mockup name must be kebab-case (a-z, 0-9, -): $name" >&2; exit 2 ;;
esac

dest="mockups/$name"
if [ -e "$dest" ]; then
  echo "$dest already exists — pick another name or edit the existing mockup" >&2
  exit 1
fi

[ $# -eq 0 ] && set -- 00

find_example() {
  p=$1
  case "$p" in
    *.html) f="design-system/examples/$p" ;;
    *) f=$(ls design-system/examples/"$p"-*.html 2>/dev/null | head -n 1) ;;
  esac
  if [ -z "$f" ] || [ ! -f "$f" ]; then
    echo "No example for pattern '$p'. See design-system/foundation/decision-tree.md" >&2
    return 1
  fi
  echo "$f"
}

# Validate every pattern before creating anything.
for arg in "$@"; do
  find_example "${arg%%:*}" >/dev/null || exit 1
done

mkdir -p "$dest"
cp -R templates/. "$dest/"
find "$dest" -name .DS_Store -delete 2>/dev/null || true

copy_page() {
  src=$1; target=$2
  if [ -e "$dest/$target" ]; then
    echo "  skip $target (already created)"; return 0
  fi
  sed -e 's#\.\./foundation/##g' -e 's#\.\./brand/##g' "$src" > "$dest/$target"
  echo "  $target  <-  $(basename "$src")"
  # Pages embedded by the example (e.g. an iframe background) come along under their own name.
  for ref in $(grep -o -E '(src|href)="[0-9][0-9]-[a-z0-9-]+\.html"' "$src" | sed -E 's/.*"(.*)"/\1/' | sort -u); do
    if [ ! -e "$dest/$ref" ]; then
      sed -e 's#\.\./foundation/##g' -e 's#\.\./brand/##g' "design-system/examples/$ref" > "$dest/$ref"
      echo "  $ref  (embedded by $(basename "$src"))"
    fi
  done
}

echo "Created $dest"
first=1
for arg in "$@"; do
  pattern=${arg%%:*}
  src=$(find_example "$pattern")
  if [ "$arg" != "$pattern" ]; then
    target=${arg#*:}
  elif [ $first -eq 1 ]; then
    target=index.html
  else
    target=$(basename "$src" | sed -E 's/^[0-9]+-//')
  fi
  copy_page "$src" "$target"
  first=0
done

echo "Next: edit the pages, then run  sh .kiro/scripts/check-mockup.sh $dest"
