#!/bin/sh
# macOS / Linux wrapper for check-mockup.py. Finds a working Python 3 without
# triggering the Xcode Command Line Tools install dialog on a fresh Mac.
#
# Usage: sh .kiro/scripts/check-mockup.sh mockups/<name>   (or a single .html, or --all)
cd "$(dirname "$0")/../.." || exit 0
for py in python3 python; do
  path=$(command -v "$py" 2>/dev/null) || continue
  if [ "$(uname -s)" = "Darwin" ] && [ "$path" = "/usr/bin/python3" ]; then
    xcode-select -p >/dev/null 2>&1 || continue
  fi
  "$path" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null || continue
  exec "$path" .kiro/scripts/check-mockup.py "$@"
done
echo "check-mockup needs Python 3.9+ — not found. Skipping the automatic check."
echo "Verify manually with the QA checklist in the skill, or install Python (macOS: xcode-select --install)."
exit 0
