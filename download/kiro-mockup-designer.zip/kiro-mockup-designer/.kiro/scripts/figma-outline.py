"""
Figma frame -> kit outline: turns any frame built with the Figma UI App library into a build plan in kit classes.

1. Get the frame with the Figma MCP: get_figma_data(fileKey, nodeId). Large results are saved to a file; copy that file.
2. python3 .kiro/scripts/figma-outline.py <frame.yaml|frame.json> [--node <id>] [--depth 12]
3. Build the page from the outline: every library instance becomes the kit class shown, every auto-layout frame a
   flex box with the gap and padding shown, every text a text in the kit text style shown, every icon an rp-icon.
   Lines marked NOT IN KIT need a decision (see design-system/figma/README.md, "Missing").
4. Check the result against a PNG of the frame (download_figma_images, scale 1) with a screenshot side by side.

Reads design-system/figma/figma-map.json (component sets) and design-system/foundation/icons-figma/manifest.json
(icons). YAML is read with the vendored PyYAML in .kiro/scripts/vendor/ when PyYAML is not installed. Python 3.9+.
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
FIG = ROOT / "design-system" / "figma"
ICONS = ROOT / "design-system" / "foundation" / "icons-figma" / "manifest.json"
COLORS = {"#111111": "", "#636363": "rp-text-secondary", "#35678F": "rp-text-active", "#FFFFFF": "(white)",
          "#D3000C": "rp-text-error", "#B0000A": "rp-text-error", "#157934": "rp-text-success", "#014CB7": "(RPP70)",
          "#777777": "(neutral main)", "#3F7BAB": "(blue main)"}


def load(path):
    text = Path(path).read_text(encoding="utf-8")
    if path.endswith(".json"):
        return json.loads(text)
    try:
        import yaml  # noqa: PLC0415
    except ImportError:  # use the vendored pure-Python copy (.kiro/scripts/vendor)
        sys.path.insert(0, os.environ.get("RP_PYYAML_PATH") or str(Path(__file__).resolve().parent / "vendor"))
        import yaml  # noqa: PLC0415
    loader = getattr(yaml, "CSafeLoader", yaml.SafeLoader)
    return yaml.load(text, Loader=loader)


def norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--node")
    ap.add_argument("--depth", type=int, default=14)
    a = ap.parse_args()
    d = load(a.file)
    styles = (d.get("globalVars") or {}).get("styles") or {}
    meta = d.get("metadata") or {}
    comps, sets = meta.get("components") or {}, meta.get("componentSets") or {}
    fdata = json.loads((FIG / "figma-map.json").read_text(encoding="utf-8"))
    fmap, atoms = fdata["sets"], {k: v for k, v in (fdata.get("atoms") or {}).items() if not k.startswith("_")}
    icons = {}
    if ICONS.exists():
        for e in json.loads(ICONS.read_text(encoding="utf-8"))["icons"]:
            icons.setdefault(norm(e["figma"].split("/")[-1]), e["class"])
            icons.setdefault(norm(e["figma"]), e["class"])
    unknown = {}

    def res(v):
        return styles.get(v, v) if isinstance(v, str) else v

    def layout(n):
        l = res(n.get("layout"))
        if not isinstance(l, dict):
            return ""
        bits = []
        if l.get("mode") in ("row", "column"):
            bits.append("flex " + l["mode"])
        for k in ("gap", "padding"):
            if l.get(k):
                bits.append("%s %s" % (k, l[k]))
        if l.get("justifyContent"):
            bits.append("justify " + l["justifyContent"])
        if l.get("alignItems"):
            bits.append("align " + l["alignItems"])
        dm, sz = l.get("dimensions") or {}, l.get("sizing") or {}
        if sz.get("horizontal") == "fixed" and dm.get("width"):
            bits.append("width %spx" % dm["width"])
        elif sz.get("horizontal") == "fill":
            bits.append("width fill")
        if sz.get("vertical") == "fixed" and dm.get("height"):
            bits.append("height %spx" % dm["height"])
        if l.get("position") == "absolute":
            p = l.get("locationRelativeToParent") or {}
            bits.append("absolute at %s,%s" % (p.get("x"), p.get("y")))
        return ", ".join(bits)

    def paint(v):
        v = res(v)
        if isinstance(v, list) and v:
            x = v[0]
            return x if isinstance(x, str) else (x.get("hex") or x.get("type") or "")
        return ""

    def text_class(n):
        t = res(n.get("textStyle")) or {}
        if not isinstance(t, dict):
            return ""
        size, weight = t.get("fontSize"), t.get("fontWeight") or 400
        base = {34: "rp-text-h4", 20: "rp-text-h6", 16: "rp-text-subtitle1" if weight == 500 else "rp-text-body1",
                14: "rp-text-subtitle2" if weight == 600 else "rp-text-body2", 12: "rp-text-caption"}.get(size, "%spx" % size)
        extra = " rp-text-bold" if weight == 700 else " rp-text-semibold" if weight == 600 and size != 14 else ""
        color = COLORS.get(str(paint(n.get("fills"))).upper(), paint(n.get("fills")))
        return (base + extra + (" " + color if color else "")).strip()

    def kit_for(n):
        c = comps.get(n.get("componentId")) or {}
        set_name = (sets.get(c.get("componentSetId")) or {}).get("name") if c.get("componentSetId") else None
        name = set_name or c.get("name") or n.get("name")
        variant = c.get("name") if set_name else ""
        entry = fmap.get(name)
        if entry is None:
            return name, variant, None
        if entry.get("kit") == "Missing":
            return name, variant, "Missing"
        base = entry["kit"].split()[0]
        classes, attrs = entry["kit"].split(), []
        for kv in [x.strip() for x in variant.split(",") if x.strip()]:
            rule = (entry.get("variants") or {}).get(kv)
            if not rule or rule == "=":
                continue
            if rule == "Missing":
                classes.append("[%s: not in kit]" % kv)
            elif rule.startswith("@"):
                classes[0] = base = rule[1:]
                classes = [base] + [x.replace(entry["kit"].split()[0], base) for x in classes[1:]]
            elif rule.startswith("+"):
                classes.append(rule[1:])
            elif rule.startswith("{base}"):
                classes.append(base + rule[len("{base}"):])
            elif rule.startswith("attr:"):
                attrs.append(rule[5:])
        out = " ".join(dict.fromkeys(classes))
        if attrs:
            out += "  [" + " ".join(attrs) + "]"
        return name, variant, out

    def texts_icons(n, acc):
        if n.get("visible") is False:
            return acc
        t = n.get("type")
        if t == "TEXT" and str(n.get("text", "")).strip():
            acc.append('"%s"' % str(n["text"]).replace("\n", " ")[:60])
        elif t in ("IMAGE-SVG", "INSTANCE") and n.get("componentId"):
            cn = (comps.get(n["componentId"]) or {}).get("name") or n.get("name")
            k = icons.get(norm(cn))
            if k and not (n.get("children") and t == "INSTANCE" and fmap.get(cn)):
                l = res(n.get("layout")) or {}
                size = ((l.get("dimensions") or {}).get("width") if isinstance(l, dict) else None) or ""
                acc.append("rp-icon-%s%s" % (k, " %spx" % int(size) if size else ""))
                return acc
        for c in n.get("children") or []:
            texts_icons(c, acc)
        return acc

    out = []

    def walk(n, depth):
        if n.get("visible") is False or depth > a.depth:
            return
        pad = "  " * depth
        t = n.get("type")
        if t == "INSTANCE":
            name, variant, kit = kit_for(n)
            if kit and kit != "Missing":
                bits = texts_icons(n, [])
                out.append("%s%s  <- %s%s%s" % (pad, kit, name, (" (%s)" % variant) if variant else "",
                                                ("  :: " + " | ".join(bits[:8])) if bits else ""))
                if name in ("Tile", "TileState", "Card", "Dialog",
                            "SidebarDrawer", "SidebarPanel", "Menu", "Toolbar", "Tabs-Desktop", "Breadcrumbs",
                            "Accordion", "headerPageContainer", "Toggle Button_New", "PopOver"):
                    for c in n.get("children") or []:
                        walk(c, depth + 1)
                return
            cn = (comps.get(n.get("componentId")) or {}).get("name") or n.get("name")
            k = icons.get(norm(cn))
            if k:
                l = res(n.get("layout")) or {}
                size = (l.get("dimensions") or {}).get("width") if isinstance(l, dict) else ""
                out.append("%srp-icon-%s %spx" % (pad, k, size or 24))
                return
            if name in atoms:  # a state layer: the parent frame is a detached copy of the component
                bits = texts_icons(n, [])
                out.append("%s^ the frame above is a detached %s  (%s%s)%s" % (pad, atoms[name], name, (" " + variant) if variant else "",
                                                                         ("  :: " + " | ".join(bits[:8])) if bits else ""))
                return
            label = "NOT IN KIT" if kit == "Missing" else "unmapped component"
            unknown[name] = unknown.get(name, 0) + 1
            out.append("%s%s: %s%s  [%s]" % (pad, label, name, (" (%s)" % variant) if variant else "", layout(n)))
        elif t == "TEXT":
            out.append('%stext "%s"  {%s}' % (pad, str(n.get("text", "")).replace("\n", " ")[:80], text_class(n)))
            return
        elif t in ("IMAGE-SVG",):
            cn = (comps.get(n.get("componentId")) or {}).get("name") or n.get("name")
            k = icons.get(norm(cn))
            l = res(n.get("layout")) or {}
            size = (l.get("dimensions") or {}).get("width") if isinstance(l, dict) else ""
            out.append("%s%s %spx" % (pad, ("rp-icon-" + k) if k else "svg/image " + str(cn), size or ""))
            return
        else:
            fill = paint(n.get("fills"))
            out.append("%s%s %r  [%s]%s" % (pad, t.lower() if t else "node", n.get("name"), layout(n),
                                           (" fill " + fill) if fill and fill not in ("#FFFFFF",) else ""))
        for c in n.get("children") or []:
            walk(c, depth + 1)

    roots = d.get("nodes") or []
    if a.node:
        def find(n):
            if n.get("id") == a.node:
                return n
            for c in n.get("children") or []:
                r = find(c)
                if r:
                    return r
            return None
        roots = [r for r in (find(n) for n in roots) if r]
        if not roots:
            sys.exit("node %s not found" % a.node)
    for r in roots:
        walk(r, 0)
    print("\n".join(out))
    if unknown:
        print("\n# Components with no kit mapping (add them to design-system/figma/figma-map.json or build them):")
        for k, v in sorted(unknown.items(), key=lambda x: -x[1]):
            print("#   %3d x %s" % (v, k))
    return 0


if __name__ == "__main__":
    sys.exit(main())
