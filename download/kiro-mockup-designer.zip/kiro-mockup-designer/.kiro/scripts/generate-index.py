#!/usr/bin/env python
"""
Regenerate the pattern list in root index.html.

Scans design-system/examples/*.html for pattern pages and updates
the AUTO-GENERATED:PATTERNS section in index.html.

Run manually or via Kiro hook on file changes.
"""

import os
import re
import sys
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent.parent
INDEX_FILE = WORKSPACE / "index.html"
EXAMPLES_DIR = WORKSPACE / "design-system" / "examples"

PATTERN_NAMES = {
    "00": "Blank Page",
    "01": "Settings List",
    "02": "Settings Hub",
    "03": "Dashboard",
    "04": "Results Table",
    "05": "Tabs in a Tile",
    "06": "Edit Form",
    "07": "Tracking Inbox",
    "08": "Dialog Form",
    "09": "Wizard",
    "10": "Analysis Table",
    "11": "Accordion Table",
    "12": "Hybrid Table",
    "13": "Index Table",
    "14": "Index Navigation",
    "15": "Editable Table",
    "16": "Operations List",
}


def generate_pattern_cards() -> str:
    cards = []
    for f in sorted(EXAMPLES_DIR.glob("[0-9][0-9]-*.html")):
        num = f.name[:2]
        name = PATTERN_NAMES.get(num, f.stem[3:].replace("-", " ").title())
        cards.append(
            f'        <a class="pattern-card" onclick="openPattern(\'{f.name}\', \'{name}\'); return false;" href="design-system/examples/{f.name}">\n'
            f'          <span class="pattern-num">{num}</span><span class="pattern-name">{name}</span>\n'
            f'        </a>'
        )
    return "\n".join(cards)


def main():
    # Windows hooks pass --windows-only; macOS/Linux hooks use generate-index.sh.
    if "--windows-only" in sys.argv and os.name != "nt":
        return

    if not INDEX_FILE.exists():
        print(f"Error: {INDEX_FILE} not found", file=sys.stderr)
        sys.exit(1)

    html = INDEX_FILE.read_text(encoding="utf-8")
    new_cards = generate_pattern_cards()

    pattern = r"(<!-- AUTO-GENERATED:PATTERNS-START -->)\n.*?\n(\s*<!-- AUTO-GENERATED:PATTERNS-END -->)"
    result, count = re.subn(pattern, rf"\1\n{new_cards}\n\2", html, flags=re.DOTALL)

    if count == 0:
        print("Warning: PATTERNS markers not found in index.html", file=sys.stderr)
        sys.exit(1)

    if result == html:
        return  # same list: do not touch the file
    INDEX_FILE.write_text(result, encoding="utf-8")
    pattern_count = len(list(EXAMPLES_DIR.glob("[0-9][0-9]-*.html")))
    print(f"index.html updated: {pattern_count} patterns")


if __name__ == "__main__":
    main()
