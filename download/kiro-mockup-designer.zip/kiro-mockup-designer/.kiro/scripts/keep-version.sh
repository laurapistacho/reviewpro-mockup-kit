#!/bin/sh
# Kiro hook (PreToolUse on file writes, .kiro/hooks/keep-version.json): before Kiro writes a page,
# keep the page as it is now in .tweak-history/<page>/<date>_<time>__kiro.html next to it. These
# are the same versions Tweak mode keeps, so "Before Kiro edit" shows up in Tweak's Save & history
# and can be previewed or restored there. POSIX sh only (fresh Macs).
#   sh .kiro/scripts/keep-version.sh                 reads the hook JSON on stdin (the "path")
#   sh .kiro/scripts/keep-version.sh mockups/x/a.html  for a shell edit (sed, scripts)
# One version per Kiro task: while the newest version is Kiro's, younger than 15 minutes and not
# named yet in names.json (Kiro names it when the task is done, see the skill), later edits add
# none. None when the page equals the newest version. The 40 newest per page are kept.
# Never fails the tool call.
cd "$(dirname "$0")/../.." || exit 0
if [ -n "$1" ]; then p=$1
else p=$(cat 2>/dev/null | tr ',{}' '\n\n\n' | grep -m1 -E '"(path|targetFile)"[[:space:]]*:' | sed -E 's/^[^:]*:[[:space:]]*"//; s/"[[:space:]]*$//')
fi
case "$p" in *.html|*.htm) ;; *) exit 0 ;; esac
case "$p" in */.tweak-history/*|*/__*) exit 0 ;; esac
case "$p" in *mockups/*|*design-system/examples/*|*design-system/foundation/tweak/tweak-ui.html) ;; *) exit 0 ;; esac
[ -f "$p" ] || exit 0
name=$(basename "$p"); h="$(dirname "$p")/.tweak-history/${name%.*}"
mkdir -p "$h" 2>/dev/null || exit 0
newest=$(cd "$h" 2>/dev/null && ls -1t -- *__*.html 2>/dev/null | head -n 1)  # by time: versions of the same second sort by kind
if [ -n "$newest" ]; then
  cmp -s "$p" "$h/$newest" && exit 0
  case "$newest" in *__kiro.html)
    m=$(stat -f %m "$h/$newest" 2>/dev/null || stat -c %Y "$h/$newest" 2>/dev/null || echo 0)
    if [ $(( $(date +%s) - m )) -lt 900 ] && ! grep -q "\"$newest\"" "$h/names.json" 2>/dev/null; then exit 0; fi ;;
  esac
fi
cp "$p" "$h/$(date +%Y-%m-%d_%H-%M-%S)__kiro.html" 2>/dev/null
ls -1 "$h" | grep -E '__[a-z]+\.html$' | sort -r | tail -n +41 | while read -r o; do rm -f "$h/$o"; done
exit 0
