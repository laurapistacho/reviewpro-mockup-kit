#!/usr/bin/env python3
"""
Lint ReviewPro HTML mockups against the kit rules (design-system/foundation/rules.md).

Usage:
  python3 .kiro/scripts/check-mockup.py mockups/<name>        # one mockup folder
  python3 .kiro/scripts/check-mockup.py mockups/<name>/page.html
  python3 .kiro/scripts/check-mockup.py --all                 # starters, showcase, example mockups + kit consistency

ERROR = breaks the mockup or a hard rule (exit 1). WARN = read it; fix it unless it is deliberate page layout.
Python 3.9+, standard library only.
"""
import filecmp
import json
import re
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
DS = ROOT / "design-system"
FOUND = DS / "foundation"
EXAMPLES = DS / "examples"
V2 = DS / "v2"
V2_FILES = ("theme-v2.css", "motion-v2.js")
TEMPLATES = ROOT / "templates"
RUNTIME = ["shared.css", "shared.js", "rp-icons.css"]
BRAND = ["reviewpro-reputation-logo.svg", "establishment-logo.png"]
Z_LADDER = {"0", "1", "2", "3", "4", "10", "1000", "1200", "1300", "1500", "1600", "1700", "auto", "-1"}
FORBIDDEN_LIBS = [r"react(\.production|\.development|-dom)", r"tailwind", r"bootstrap", r"chart\.js", r"cdn\.jsdelivr\.net/npm/chart", r"d3(\.v\d)?\.js|d3js\.org",
                  r"highcharts", r"font-awesome|fontawesome", r"fonts\.googleapis\.com/icon", r"material-icons|material-symbols", r"lucide", r"jquery"]
BANNED_COPY = [("successfully", "say what happened: 'User deleted', not 'deleted successfully'"), ("are you sure", "dialog titles state the decision: 'Delete this user?'"),
               ("something went wrong", "say what failed and what to do"), ("oops", "plain, specific copy"), ("click here", "name the destination"),
               ("lorem ipsum", "filler text comes from The Metamorphosis (rules.md § Standard sample data)"), ("item 1", "realistic hospitality data"), ("sorry", "plain, specific copy"),
               ("alex rivera", "the sample user is Gregor Samsa (rules.md § Standard sample data)"), ("sam torres", "staff is Grete Samsa (rules.md § Standard sample data)")]
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF\u2B50\u2B06\u2B07\u2190-\u21FF\u2705\u274C\u2714\u2716\u25B2\u25BC\u25BE\u2630\u22EE]")
# words that keep a capital in sentence case
PROPER = set("""GRI GRI™ NPS AI PMS SFTP SMS PII ID IDs URL API FAQ LiveFAQ ReviewPro Google Booking.com Tripadvisor Expedia Hotels.com Trip.com HolidayCheck WhatsApp Facebook Instagram
English Spanish German French Italian Dutch Portuguese Russian Chinese Japanese Grand Marina Resort Spa Azure Bay Hotel Seaside Palace Harbor View Suites Cliff Edge Coastal Hotels Group
Gregor Grete Samsa Anna Mr Mrs Reviewpro Europe Madrid Barcelona CSV PDF Excel QA I Competitive Quality Index™ Insights""".split())


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags, self.classes, self.ids, self.refs, self.styles, self.links, self.scripts = [], {}, set(), [], [], [], []
        self.style_attrs, self.texts, self.buttons, self._stack, self._in_style, self._style_buf = [], [], [], [], False, []
        self.onclick_divs, self.selects, self.tables, self._in_th = [], 0, [], False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        line = self.getpos()[0]
        self.tags.append(tag)
        for c in (a.get("class") or "").split():
            self.classes.setdefault(c, line)
        if a.get("id"):
            self.ids.add(a["id"])
        for k in ("data-rp-open", "data-rp-menu", "aria-controls", "data-rp-table", "data-rp-filter", "data-rp-empty-for", "data-rp-count-for", "data-rp-clear-filters"):
            if a.get(k):
                self.refs.append((k, a[k], line))
        if tag == "link" and a.get("href"):
            self.links.append((a["href"], line))
        if tag == "script" and a.get("src"):
            self.scripts.append((a["src"], line))
        if tag in ("img", "iframe", "source") and a.get("src"):
            self.links.append((a["src"], line))
        if tag == "a" and a.get("href"):
            self.links.append((a["href"], line))
        if a.get("style"):
            self.style_attrs.append((a["style"], line))
        if tag == "select":
            self.selects += 1
        if tag == "table":
            self.tables.append(((a.get("class") or ""), line))
        if tag in ("div", "span", "li", "td", "tr") and a.get("onclick"):
            self.onclick_divs.append(line)
        if tag == "style":
            self._in_style, self._style_buf = True, []
        if tag == "button" or (a.get("class") and re.search(r"\brp-(main|default|ghost|icon)-button\b", a.get("class", ""))):
            self.buttons.append({"cls": a.get("class", ""), "aria": a.get("aria-label") or a.get("title") or a.get("data-rp-tooltip"), "text": "", "line": line, "icons": 0})
            self._stack.append(len(self.buttons) - 1)
        elif tag == "span" and "rp-icon" in (a.get("class") or "").split() and self._stack:
            self.buttons[self._stack[-1]]["icons"] += 1
        if tag == "th":
            self.texts.append(["th", "", line])
            self._in_th = True
        elif getattr(self, "_in_th", False) and "rp-table-head-secondary" in (a.get("class") or "").split():
            [t for t in self.texts if t[0] == "th"][-1][1] += " | "  # a two-line header: each line is checked on its own
        if tag == "input" and a.get("placeholder"):
            self.texts.append(["placeholder", a["placeholder"], line])

    def handle_endtag(self, tag):
        if tag == "style":
            self._in_style = False
            self.styles.append("".join(self._style_buf))
        if tag == "button" and self._stack:
            self._stack.pop()
        if tag == "th":
            self._in_th = False

    def handle_data(self, data):
        if self._in_style:
            self._style_buf.append(data)
            return
        if self._stack:
            self.buttons[self._stack[-1]]["text"] += data
        if self._in_th:
            th = [t for t in self.texts if t[0] == "th"][-1]
            th[1] += data + " "
            return
        if data.strip():
            self.texts.append(["text", data.strip(), self.getpos()[0]])


def css_classes(path):
    s = re.sub(r"/\*.*?\*/", "", path.read_text(encoding="utf-8"), flags=re.S)
    s = re.sub(r'url\("[^"]*"\)|url\([^)]*\)', "", s)
    return set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", s))


def title_case(text):
    words = [w for w in re.split(r"\s+", text.strip()) if w]
    if len(words) < 2:
        return False
    rest = [w for w in words[1:] if re.match(r"^[A-Za-z]", w) and w not in PROPER and not w.isupper() and not w.endswith(".")]
    return bool(rest) and all(w[0].isupper() for w in rest)


def is_v2(html):
    return bool(re.search(r'<html[^>]*data-rp-version="v2"', html))


def check_v2(path, html, p, page_css, errors, warns):
    """Modernised (V2) pages: the rules of design-system/v2/README.md that a script can check."""
    folder = path.parent
    kit = folder.resolve() == EXAMPLES.resolve()
    hrefs = [h for h, _ in p.links] + [s for s, _ in p.scripts]
    for f in V2_FILES:
        if not any(h.endswith(f) for h in hrefs):
            errors.append("V2 page without %s (run make-v2.py %s --theme-only)" % (f, "design-system/examples" if kit else folder.relative_to(ROOT)))
        elif not kit:
            local = folder / f
            if not local.exists():
                errors.append("%s is linked but missing in the folder (run make-v2.py --theme-only)" % f)
            elif not filecmp.cmp(local, V2 / f, shallow=False):
                warns.append("%s is older than design-system/v2/%s (run make-v2.py %s --theme-only)" % (f, f, folder.relative_to(ROOT)))
    if 'data-rp-version="current"' not in html.split("</head>")[0]:
        warns.append("V2 page without the alternate link to its current page (the version switch needs it)")
    if "rp-top-bar" in p.classes:
        for need, what in (("v2-skip-link", "a Skip to main content link"), ("data-rp-side-bar-toggle", "the Expand navigation rail button"), ('id="main-content"', "id=\"main-content\" on the main area")):
            if need not in html:
                errors.append("V2 page without %s (WCAG 2.4.1 / 2.5.8: run make-v2.py --theme-only)" % what)
    css_all = [(page_css, 0)] + p.style_attrs
    for txt, line in css_all:
        at = ("line %d: " % line) if line else "<style>: "
        if re.search(r"gradient\s*\(", txt):
            errors.append(at + "gradient in a V2 page (V2 rule: no gradients anywhere, flat colours and opacity tints)")
        if re.search(r"transition\s*:\s*all\b", txt):
            errors.append(at + "transition: all (list the properties that move)")
    plain = re.sub(r"@media[^{]*prefers-reduced-motion[^{]*\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}", "", page_css)
    if re.search(r"\b(animation|transition)\s*:", plain) or "@keyframes" in plain:
        warns.append("<style>: motion outside @media (prefers-reduced-motion: no-preference): V2 motion lives in theme-v2.css § 6 and motion-v2.js")
    for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", re.sub(r"/\*.*?\*/", "", page_css, flags=re.S)):
        sel, body = m.group(1).strip(), m.group(2)
        if re.search(r"button", sel) and re.search(r"border-radius\s*:\s*(999|50%|[2-9]\d+px)", body):
            warns.append("<style>: %s: buttons get 10px corners in V2, never pills" % sel[:60])
        if re.search(r"--v2-green|--neon-|#0AFFAB", body, re.I) and not re.search(r"\b(ai|insight)", sel, re.I):
            warns.append("<style>: %s uses Energetic Green: only the AI call to action and its chip may" % sel[:60])
        if re.search(r"--v2-font-display|Shiji Day Sans|Aeonik", body) and not re.search(r"h1|title|kpi|hero|donut|display", sel, re.I):
            warns.append("<style>: %s uses the display font: only the page title and hero numbers may" % sel[:60])
    cur = re.search(r'<link rel="alternate" data-rp-version="current" href="([^"]+)"', html)
    if cur and (folder / cur.group(1)).exists():
        cp = Page()
        cp.feed((folder / cur.group(1)).read_text(encoding="utf-8"))
        cur_classes = set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", re.sub(r"/\*.*?\*/", "", "\n".join(cp.styles), flags=re.S)))
        mine = set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", re.sub(r"/\*.*?\*/", "", page_css, flags=re.S)))
        for c in sorted(mine - cur_classes):
            if not c.startswith(("v2-", "rp-", "kit-")) and not kit:
                warns.append("<style>: .%s is new in the V2 page: page-only V2 classes start with v2-" % c)


def check_page(path, ds_classes, icon_classes, in_kit_examples):
    errors, warns = [], []
    html = path.read_text(encoding="utf-8")
    p = Page()
    p.feed(html)
    rel = path.relative_to(ROOT)
    folder = path.parent
    page_css = "\n".join(p.styles)
    page_classes = set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", re.sub(r"/\*.*?\*/", "", page_css, flags=re.S)))
    is_showcase = path.name in ("index.html", "index-v2.html") and in_kit_examples
    v2 = is_v2(html)
    if v2:
        ds_classes = ds_classes | css_classes(V2 / "theme-v2.css")

    # assets
    hrefs = [h for h, _ in p.links] + [s for s, _ in p.scripts]
    if not any("fonts.googleapis.com/css2?family=Noto+Sans" in h for h in hrefs):
        errors.append("Noto Sans <link> missing in <head> (copy the three lines of 00-blank-page.html)")
    if not v2 and any(h.endswith(V2_FILES) for h in hrefs):
        errors.append("the current page loads a V2 file: V2 lives only in the -v2 copy (make-v2.py)")
    for asset in ("shared.css", "rp-icons.css", "shared.js"):
        if not any(h.endswith(asset) for h in hrefs):
            errors.append("%s is not linked" % asset)
        elif not in_kit_examples and not (folder / asset).exists():
            errors.append("%s is linked but missing in the folder (run new-mockup, or copy it from templates/)" % asset)
    if not in_kit_examples:
        for h, line in p.links + p.scripts:
            if h.startswith("../"):
                errors.append("line %d: '../' path %s (assets are siblings of the page)" % (line, h))
        for m in re.finditer(r"url\(['\"]?\.\./", html):
            errors.append("line %d: url('../…') in CSS (assets are siblings of the page)" % (html[:m.start()].count("\n") + 1))
    for h, line in p.links + p.scripts:
        if h.endswith(".html") and not h.startswith(("http", "#", "mailto:")) and not (folder / h.split("#")[0]).exists():
            errors.append("line %d: link to %s, which does not exist" % (line, h))
        for lib in FORBIDDEN_LIBS:
            if re.search(lib, h, re.I):
                errors.append("line %d: forbidden library %s (plain HTML + kit only)" % (line, h))

    # classes
    for c, line in sorted(p.classes.items(), key=lambda x: x[1]):
        if c.startswith("rp-icon-") and c not in ("rp-icon-button", "rp-icon-multicolor") and not c.startswith("rp-icon-size-") and not c.startswith("rp-icon-button-"):
            if c not in icon_classes:
                errors.append("line %d: unknown icon class %s (see foundation/icons-full-reference.md)" % (line, c))
        elif c.startswith(("rp-", "kit-")):
            if c not in ds_classes:
                errors.append("line %d: %s is not a kit class (rp-map.json / shared.css); use a real component" % (line, c))
        elif c not in page_classes and c not in ds_classes and c not in ("open", "on") and not c.startswith("dl-"):
            warns.append("line %d: class %s is not defined by the kit or the page style (invented component?)" % (line, c))
    if "rp-page-header" in p.classes and "rp-page-header-divider" not in p.classes and "rp-page-header-tabs" not in p.classes and "data-rp-hide-divider" not in html:
        warns.append("line %d: PageHeader without its divider: add <hr class=\"rp-divider rp-page-header-divider\" /> (or data-rp-hide-divider when nothing follows the header, like hideDivider)" % p.classes["rp-page-header"])
    for m in re.finditer(r'<div class="rp-page-header-actions[^"]*">(.*?)</div>', html, flags=re.S):
        prim = len(re.findall(r'class="rp-ghost-button(?![^"]*rp-ghost-button-inherit)[^"]*"', m.group(1)))
        if prim > 1:
            warns.append("line %d: %d primary page actions: one primary ghost button, the others rp-ghost-button-inherit (rules.md 15)" % (html[:m.start()].count("\n") + 1, prim))
    if "rp-top-bar-qa" in p.classes:
        warns.append("line %d: rp-top-bar-qa is the green QA bar; mockups use the blue production bar, even from QA screenshots (rules.md § Copying a screenshot)" % p.classes["rp-top-bar-qa"])
    # lessons from design reviews (rules.md 20-26)
    if not is_showcase:
        at = lambda i: html[:i].count("\n") + 1
        m = re.search(r'<td[^>]*>\s*<span class="rp-icon rp-icon-right"[^>]*></span>\s*</td>', html)
        if m:
            warns.append("line %d: a decorative chevron at the end of a row: the row opens through its name, a link (rp-link) (rules.md 26)" % at(m.start()))
        for m in re.finditer(r'<[a-z]+ class="rp-disclaimer\b', html):
            before = html[:m.start()]
            if before.rfind("<main") > before.rfind("</main>") and not re.search(r'<main[^>]*\brp-content\b[^>]*>\s*$', before):
                warns.append("line %d: the AI disclaimer goes first in rp-content, right under the top bar, edge to edge (rules.md 24)" % at(m.start()))
        for m in re.finditer(r'<p class="rp-tile-title-secondary">\s*(Expand|Click|Double-click|Drag|Tap|Hover|Press|Scroll)\b', html):
            warns.append("line %d: a tile subtitle that tells how to use the UI: cut it, the UI shows that (rules.md 21)" % at(m.start()))
        h1 = re.search(r'<h1 class="rp-(?:page-header-title|page-title)[^"]*">([^<]+)</h1>', html)
        for m in re.finditer(r'<h2 class="rp-tile-title-label[^"]*">([^<]+)</h2>', html) if h1 else ():
            rest = re.split(r'<div class="rp-tile-(?:table|content)|<div class="rp-toolbar|</section>', html[m.end():], maxsplit=1)[0]
            if m.group(1).strip().lower() == h1.group(1).strip().lower() and "rp-tile-title-actions" not in rest:
                warns.append("line %d: the tile title '%s' repeats the page title: a tile that holds the page's table needs no title (rules.md 21)" % (at(m.start()), m.group(1).strip()))
        for m in re.finditer(r'class="((?:[^"]*\s)?rp-toggle-button-group(?=[\s"])[^"]*)"', html):
            if "rp-toggle-button-group-size-small" not in m.group(1):
                warns.append("line %d: a medium toggle group: toolbars, tiles and tables use rp-toggle-button-group-size-small (rules.md 13, 23)" % at(m.start()))
    if p.selects:
        errors.append("native <select> (use rp-select)")
    for cls, line in p.tables:
        if "rp-table" not in cls.split():
            errors.append("line %d: <table> without rp-table" % line)
    if EMOJI.search(re.sub(r"<script.*?</script>|<style.*?</style>", "", html, flags=re.S)):
        errors.append("emoji or symbol characters used as icons (use rp-icon classes)")
    if not is_showcase and "rp-top-bar" not in p.classes and "rp-dialog" not in p.classes:
        warns.append("no app shell (rp-top-bar): every admin page starts from a starter")

    # dangling references (dead controls)
    for attr, target, line in p.refs:
        if target and target not in p.ids:
            errors.append("line %d: %s=\"%s\" points at no element with that id" % (line, attr, target))

    # buttons
    for b in p.buttons:
        if b["icons"] and not b["text"].strip() and not b["aria"]:
            warns.append("line %d: icon-only button without aria-label" % b["line"])
        txt = re.sub(r"\s+", " ", b["text"]).strip()
        if re.search(r"rp-(main|default|ghost)-button", b["cls"]) and title_case(txt):
            warns.append("line %d: button '%s' in Title Case (buttons use sentence case)" % (b["line"], txt))
    for kind, txt, line in p.texts:
        t = re.sub(r"\s+", " ", txt).strip()
        if kind == "th" and any(title_case(part) for part in t.split("|")):
            warns.append("line %d: table header '%s' in Title Case (headers use sentence case)" % (line, t))
        low = t.lower()
        for word, fix in BANNED_COPY:
            if word in low:
                warns.append("line %d: copy '%s' — %s" % (line, t[:60], fix))
    for line in p.onclick_divs:
        warns.append("line %d: onclick on a non-interactive element (use <button> or <a href>)" % line)
    if v2:
        check_v2(path, html, p, page_css, errors, warns)

    # page CSS
    css_lines = page_css.count("\n")
    if css_lines > 60 and not is_showcase:
        warns.append("<style> has %d lines: page CSS is layout only, compose from DS components" % css_lines)
    for txt, line in [(page_css, 0)] + p.style_attrs:
        for m in re.finditer(r"(?<!var\(--)(?<![\w-])#[0-9a-fA-F]{3,8}\b", re.sub(r"var\([^)]*\)", "", txt)):
            if not is_showcase:
                warns.append("%sraw hex color %s (use a token: var(--blue-60))" % ("line %d: " % line if line else "<style>: ", m.group(0)))
        for m in re.finditer(r"z-index\s*:\s*([\w-]+)", txt):
            if m.group(1) not in Z_LADDER and not m.group(1).startswith("var"):
                warns.append("%sz-index %s is not on the ladder (2–4 · 10 · 1000 · 1200 · 1300 · 1500 · 1600 · 1700)" % ("line %d: " % line if line else "<style>: ", m.group(1)))
    return errors, warns


def kit_checks():
    errors = []
    r = subprocess.run([sys.executable, str(ROOT / ".kiro" / "scripts" / "build-docs.py"), "--check"], capture_output=True, text=True)
    if r.returncode:
        errors += [l.replace("ERROR ", "") for l in r.stdout.splitlines() if l.startswith("ERROR")] or ["build-docs.py --check failed"]
    for f in RUNTIME:
        a, b = FOUND / f, TEMPLATES / f
        if not b.exists() or not filecmp.cmp(a, b, shallow=False):
            errors.append("templates/%s differs from design-system/foundation/%s (copy it)" % (f, f))
    for f in BRAND:
        a, b = DS / "brand" / f, TEMPLATES / f
        if not b.exists() or not filecmp.cmp(a, b, shallow=False):
            errors.append("templates/%s differs from design-system/brand/%s (copy it)" % (f, f))
    theme = re.sub(r"/\*.*?\*/", "", (V2 / "theme-v2.css").read_text(encoding="utf-8"), flags=re.S)
    theme = re.sub(r'url\("[^"]*"\)', "", theme)
    if re.search(r"gradient\s*\(", theme):
        errors.append("design-system/v2/theme-v2.css has a gradient (V2 rule: no gradients anywhere)")
    if re.search(r"transition\s*:\s*all\b", theme):
        errors.append("design-system/v2/theme-v2.css uses transition: all")
    if 'data-rp-version="v2"' in (EXAMPLES / "index.html").read_text(encoding="utf-8").split("</head>")[0] and not (EXAMPLES / "index-v2.html").exists():
        errors.append("the showcase links its V2 copy, but examples/index-v2.html is missing (make-v2.py design-system/examples index.html)")
    data = json.loads((DS / "rp-map.json").read_text(encoding="utf-8"))
    showcase = (EXAMPLES / "index.html").read_text(encoding="utf-8")
    for comp in data["components"]:
        if comp.get("category") == "App shell" or comp["class"] in ("rp-snackbar", "rp-tooltip"):
            continue
        if not re.search(r'class="[^"]*\b%s\b' % re.escape(comp["class"]), showcase):
            errors.append("showcase (examples/index.html) has no example of %s" % comp["class"])
    return errors


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    ds_classes = css_classes(FOUND / "shared.css") | css_classes(FOUND / "rp-icons.css")
    icon_classes = set(c for c in css_classes(FOUND / "rp-icons.css") if c.startswith("rp-icon-"))
    targets = []
    if "--all" in sys.argv:
        targets = [(p, True) for p in sorted(EXAMPLES.glob("*.html"))]
        targets += [(p, False) for p in sorted((ROOT / "mockups").glob("example-*/*.html"))]
    for a in args:
        p = (ROOT / a) if not Path(a).is_absolute() else Path(a)
        if p.is_dir():
            targets += [(f, p.resolve() == EXAMPLES.resolve()) for f in sorted(p.glob("*.html"))]
        elif p.exists():
            targets.append((p, p.parent.resolve() == EXAMPLES.resolve()))
        else:
            print("Not found: %s" % a)
            sys.exit(2)
    if not targets:
        print(__doc__)
        sys.exit(2)
    total_e = total_w = 0
    for path, kit in targets:
        e, w = check_page(path.resolve(), ds_classes, icon_classes, kit)
        total_e += len(e)
        total_w += len(w)
        status = "OK" if not e and not w else ("%d error(s), %d warning(s)" % (len(e), len(w)))
        print("%s — %s" % (path.resolve().relative_to(ROOT), status))
        for m in e:
            print("  ERROR " + m)
        for m in w[:25]:
            print("  WARN  " + m)
        if len(w) > 25:
            print("  WARN  … %d more" % (len(w) - 25))
    if "--all" in sys.argv:
        ke = kit_checks()
        total_e += len(ke)
        print("kit consistency — %s" % ("OK" if not ke else "%d error(s)" % len(ke)))
        for m in ke:
            print("  ERROR " + m)
    print("\n%d error(s), %d warning(s)" % (total_e, total_w))
    sys.exit(1 if total_e else 0)


if __name__ == "__main__":
    main()
