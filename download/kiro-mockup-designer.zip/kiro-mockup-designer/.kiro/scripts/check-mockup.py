#!/usr/bin/env python3
"""
Lint ReviewPro HTML mockups against the kit rules (design-system/foundation/rules.md).

Usage:
  python3 .kiro/scripts/check-mockup.py mockups/<name>        # one mockup folder
  python3 .kiro/scripts/check-mockup.py mockups/<name>/page.html
  python3 .kiro/scripts/check-mockup.py --all                 # starters, showcase, example mockups + kit consistency

ERROR = breaks the mockup or a hard rule (exit 1). WARN = read it; fix it unless it is deliberate page layout.
Python 3.9+, standard library only.
"""
import filecmp
import json
import re
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
DS = ROOT / "design-system"
FOUND = DS / "foundation"
EXAMPLES = DS / "examples"
TEMPLATES = ROOT / "templates"
RUNTIME = ["shared.css", "shared.js", "rp-icons.css"]
BRAND = ["reviewpro-reputation-logo.svg", "establishment-logo.png"]
Z_LADDER = {"0", "1", "2", "3", "4", "10", "1000", "1200", "1300", "1500", "1600", "1700", "auto", "-1"}
FORBIDDEN_LIBS = [r"react(\.production|\.development|-dom)", r"tailwind", r"bootstrap", r"chart\.js", r"cdn\.jsdelivr\.net/npm/chart", r"d3(\.v\d)?\.js|d3js\.org",
                  r"highcharts", r"font-awesome|fontawesome", r"fonts\.googleapis\.com/icon", r"material-icons|material-symbols", r"lucide", r"jquery"]
BANNED_COPY = [("successfully", "say what happened: 'User deleted', not 'deleted successfully'"), ("are you sure", "dialog titles state the decision: 'Delete this user?'"),
               ("something went wrong", "say what failed and what to do"), ("oops", "plain, specific copy"), ("click here", "name the destination"),
               ("lorem ipsum", "realistic hospitality data"), ("item 1", "realistic hospitality data"), ("sorry", "plain, specific copy")]
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF\u2B50\u2B06\u2B07\u2190-\u21FF\u2705\u274C\u2714\u2716\u25B2\u25BC\u25BE\u2630\u22EE]")
# words that keep a capital in sentence case
PROPER = set("""GRI GRI™ NPS AI PMS SFTP SMS PII ID IDs URL API FAQ LiveFAQ ReviewPro Google Booking.com Tripadvisor Expedia Hotels.com Trip.com HolidayCheck WhatsApp Facebook Instagram
English Spanish German French Italian Dutch Portuguese Russian Chinese Japanese Grand Marina Resort Spa Azure Bay Hotel Seaside Palace Harbor View Suites Cliff Edge Coastal Hotels Group
Alex Rivera Sam Torres Jordan Europe Madrid Barcelona CSV PDF Excel QA I Competitive Quality Index™ Insights""".split())


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags, self.classes, self.ids, self.refs, self.styles, self.links, self.scripts = [], {}, set(), [], [], [], []
        self.style_attrs, self.texts, self.buttons, self._stack, self._in_style, self._style_buf = [], [], [], [], False, []
        self.onclick_divs, self.selects, self.tables, self._in_th = [], 0, [], False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        line = self.getpos()[0]
        self.tags.append(tag)
        for c in (a.get("class") or "").split():
            self.classes.setdefault(c, line)
        if a.get("id"):
            self.ids.add(a["id"])
        for k in ("data-rp-open", "data-rp-menu", "aria-controls", "data-rp-table", "data-rp-filter", "data-rp-empty-for", "data-rp-count-for", "data-rp-clear-filters"):
            if a.get(k):
                self.refs.append((k, a[k], line))
        if tag == "link" and a.get("href"):
            self.links.append((a["href"], line))
        if tag == "script" and a.get("src"):
            self.scripts.append((a["src"], line))
        if tag in ("img", "iframe", "source") and a.get("src"):
            self.links.append((a["src"], line))
        if tag == "a" and a.get("href"):
            self.links.append((a["href"], line))
        if a.get("style"):
            self.style_attrs.append((a["style"], line))
        if tag == "select":
            self.selects += 1
        if tag == "table":
            self.tables.append(((a.get("class") or ""), line))
        if tag in ("div", "span", "li", "td", "tr") and a.get("onclick"):
            self.onclick_divs.append(line)
        if tag == "style":
            self._in_style, self._style_buf = True, []
        if tag == "button" or (a.get("class") and re.search(r"\brp-(main|default|ghost|icon)-button\b", a.get("class", ""))):
            self.buttons.append({"cls": a.get("class", ""), "aria": a.get("aria-label") or a.get("title") or a.get("data-rp-tooltip"), "text": "", "line": line, "icons": 0})
            self._stack.append(len(self.buttons) - 1)
        elif tag == "span" and "rp-icon" in (a.get("class") or "").split() and self._stack:
            self.buttons[self._stack[-1]]["icons"] += 1
        if tag == "th":
            self.texts.append(["th", "", line])
            self._in_th = True
        if tag == "input" and a.get("placeholder"):
            self.texts.append(["placeholder", a["placeholder"], line])

    def handle_endtag(self, tag):
        if tag == "style":
            self._in_style = False
            self.styles.append("".join(self._style_buf))
        if tag == "button" and self._stack:
            self._stack.pop()
        if tag == "th":
            self._in_th = False

    def handle_data(self, data):
        if self._in_style:
            self._style_buf.append(data)
            return
        if self._stack:
            self.buttons[self._stack[-1]]["text"] += data
        if self._in_th:
            th = [t for t in self.texts if t[0] == "th"][-1]
            th[1] += data + " "
            return
        if data.strip():
            self.texts.append(["text", data.strip(), self.getpos()[0]])


def css_classes(path):
    s = re.sub(r"/\*.*?\*/", "", path.read_text(encoding="utf-8"), flags=re.S)
    s = re.sub(r'url\("[^"]*"\)|url\([^)]*\)', "", s)
    return set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", s))


def title_case(text):
    words = [w for w in re.split(r"\s+", text.strip()) if w]
    if len(words) < 2:
        return False
    rest = [w for w in words[1:] if re.match(r"^[A-Za-z]", w) and w not in PROPER and not w.isupper() and not w.endswith(".")]
    return bool(rest) and all(w[0].isupper() for w in rest)


def check_page(path, ds_classes, icon_classes, in_kit_examples):
    errors, warns = [], []
    html = path.read_text(encoding="utf-8")
    p = Page()
    p.feed(html)
    rel = path.relative_to(ROOT)
    folder = path.parent
    page_css = "\n".join(p.styles)
    page_classes = set(re.findall(r"\.(-?[a-zA-Z_][\w-]*)", re.sub(r"/\*.*?\*/", "", page_css, flags=re.S)))
    is_showcase = path.name == "index.html" and in_kit_examples

    # assets
    hrefs = [h for h, _ in p.links] + [s for s, _ in p.scripts]
    if not any("fonts.googleapis.com/css2?family=Noto+Sans" in h for h in hrefs):
        errors.append("Noto Sans <link> missing in <head> (copy the three lines of 00-blank-page.html)")
    for asset in ("shared.css", "rp-icons.css", "shared.js"):
        if not any(h.endswith(asset) for h in hrefs):
            errors.append("%s is not linked" % asset)
        elif not in_kit_examples and not (folder / asset).exists():
            errors.append("%s is linked but missing in the folder (run new-mockup, or copy it from templates/)" % asset)
    if not in_kit_examples:
        for h, line in p.links + p.scripts:
            if h.startswith("../"):
                errors.append("line %d: '../' path %s (assets are siblings of the page)" % (line, h))
        for m in re.finditer(r"url\(['\"]?\.\./", html):
            errors.append("line %d: url('../…') in CSS (assets are siblings of the page)" % (html[:m.start()].count("\n") + 1))
    for h, line in p.links + p.scripts:
        if h.endswith(".html") and not h.startswith(("http", "#", "mailto:")) and not (folder / h.split("#")[0]).exists():
            errors.append("line %d: link to %s, which does not exist" % (line, h))
        for lib in FORBIDDEN_LIBS:
            if re.search(lib, h, re.I):
                errors.append("line %d: forbidden library %s (plain HTML + kit only)" % (line, h))

    # classes
    for c, line in sorted(p.classes.items(), key=lambda x: x[1]):
        if c.startswith("rp-icon-") and c not in ("rp-icon-button", "rp-icon-multicolor") and not c.startswith("rp-icon-size-") and not c.startswith("rp-icon-button-"):
            if c not in icon_classes:
                errors.append("line %d: unknown icon class %s (see foundation/icons-full-reference.md)" % (line, c))
        elif c.startswith(("rp-", "kit-")):
            if c not in ds_classes:
                errors.append("line %d: %s is not a kit class (rp-map.json / shared.css); use a real component" % (line, c))
        elif c not in page_classes and c not in ("open", "on") and not c.startswith("dl-"):
            warns.append("line %d: class %s is not defined by the kit or the page style (invented component?)" % (line, c))
    if "rp-top-bar-qa" in p.classes:
        warns.append("line %d: rp-top-bar-qa is the green QA bar; mockups use the blue production bar, even from QA screenshots (rules.md § Copying a screenshot)" % p.classes["rp-top-bar-qa"])
    if p.selects:
        errors.append("native <select> (use rp-select)")
    for cls, line in p.tables:
        if "rp-table" not in cls.split():
            errors.append("line %d: <table> without rp-table" % line)
    if EMOJI.search(re.sub(r"<script.*?</script>|<style.*?</style>", "", html, flags=re.S)):
        errors.append("emoji or symbol characters used as icons (use rp-icon classes)")
    if not is_showcase and "rp-top-bar" not in p.classes and "rp-dialog" not in p.classes:
        warns.append("no app shell (rp-top-bar): every admin page starts from a starter")

    # dangling references (dead controls)
    for attr, target, line in p.refs:
        if target and target not in p.ids:
            errors.append("line %d: %s=\"%s\" points at no element with that id" % (line, attr, target))

    # buttons
    for b in p.buttons:
        if b["icons"] and not b["text"].strip() and not b["aria"]:
            warns.append("line %d: icon-only button without aria-label" % b["line"])
        txt = re.sub(r"\s+", " ", b["text"]).strip()
        if re.search(r"rp-(main|default|ghost)-button", b["cls"]) and title_case(txt):
            warns.append("line %d: button '%s' in Title Case (buttons use sentence case)" % (b["line"], txt))
    for kind, txt, line in p.texts:
        t = re.sub(r"\s+", " ", txt).strip()
        if kind == "th" and title_case(t):
            warns.append("line %d: table header '%s' in Title Case (headers use sentence case)" % (line, t))
        low = t.lower()
        for word, fix in BANNED_COPY:
            if word in low:
                warns.append("line %d: copy '%s' — %s" % (line, t[:60], fix))
    for line in p.onclick_divs:
        warns.append("line %d: onclick on a non-interactive element (use <button> or <a href>)" % line)

    # page CSS
    css_lines = page_css.count("\n")
    if css_lines > 60 and not is_showcase:
        warns.append("<style> has %d lines: page CSS is layout only, compose from DS components" % css_lines)
    for txt, line in [(page_css, 0)] + p.style_attrs:
        for m in re.finditer(r"(?<!var\(--)(?<![\w-])#[0-9a-fA-F]{3,8}\b", re.sub(r"var\([^)]*\)", "", txt)):
            if not is_showcase:
                warns.append("%sraw hex color %s (use a token: var(--blue-60))" % ("line %d: " % line if line else "<style>: ", m.group(0)))
        for m in re.finditer(r"z-index\s*:\s*([\w-]+)", txt):
            if m.group(1) not in Z_LADDER and not m.group(1).startswith("var"):
                warns.append("%sz-index %s is not on the ladder (2–4 · 10 · 1000 · 1200 · 1300 · 1500 · 1600 · 1700)" % ("line %d: " % line if line else "<style>: ", m.group(1)))
    return errors, warns


def kit_checks():
    errors = []
    r = subprocess.run([sys.executable, str(ROOT / ".kiro" / "scripts" / "build-docs.py"), "--check"], capture_output=True, text=True)
    if r.returncode:
        errors += [l.replace("ERROR ", "") for l in r.stdout.splitlines() if l.startswith("ERROR")] or ["build-docs.py --check failed"]
    for f in RUNTIME:
        a, b = FOUND / f, TEMPLATES / f
        if not b.exists() or not filecmp.cmp(a, b, shallow=False):
            errors.append("templates/%s differs from design-system/foundation/%s (copy it)" % (f, f))
    for f in BRAND:
        a, b = DS / "brand" / f, TEMPLATES / f
        if not b.exists() or not filecmp.cmp(a, b, shallow=False):
            errors.append("templates/%s differs from design-system/brand/%s (copy it)" % (f, f))
    data = json.loads((DS / "rp-map.json").read_text(encoding="utf-8"))
    showcase = (EXAMPLES / "index.html").read_text(encoding="utf-8")
    for comp in data["components"]:
        if comp.get("category") == "App shell" or comp["class"] in ("rp-snackbar", "rp-tooltip"):
            continue
        if not re.search(r'class="[^"]*\b%s\b' % re.escape(comp["class"]), showcase):
            errors.append("showcase (examples/index.html) has no example of %s" % comp["class"])
    return errors


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    ds_classes = css_classes(FOUND / "shared.css") | css_classes(FOUND / "rp-icons.css")
    icon_classes = set(c for c in css_classes(FOUND / "rp-icons.css") if c.startswith("rp-icon-"))
    targets = []
    if "--all" in sys.argv:
        targets = [(p, True) for p in sorted(EXAMPLES.glob("*.html"))]
        targets += [(p, False) for p in sorted((ROOT / "mockups").glob("example-*/*.html"))]
    for a in args:
        p = (ROOT / a) if not Path(a).is_absolute() else Path(a)
        if p.is_dir():
            targets += [(f, p.resolve() == EXAMPLES.resolve()) for f in sorted(p.glob("*.html"))]
        elif p.exists():
            targets.append((p, p.parent.resolve() == EXAMPLES.resolve()))
        else:
            print("Not found: %s" % a)
            sys.exit(2)
    if not targets:
        print(__doc__)
        sys.exit(2)
    total_e = total_w = 0
    for path, kit in targets:
        e, w = check_page(path.resolve(), ds_classes, icon_classes, kit)
        total_e += len(e)
        total_w += len(w)
        status = "OK" if not e and not w else ("%d error(s), %d warning(s)" % (len(e), len(w)))
        print("%s — %s" % (path.resolve().relative_to(ROOT), status))
        for m in e:
            print("  ERROR " + m)
        for m in w[:25]:
            print("  WARN  " + m)
        if len(w) > 25:
            print("  WARN  … %d more" % (len(w) - 25))
    if "--all" in sys.argv:
        ke = kit_checks()
        total_e += len(ke)
        print("kit consistency — %s" % ("OK" if not ke else "%d error(s)" % len(ke)))
        for m in ke:
            print("  ERROR " + m)
    print("\n%d error(s), %d warning(s)" % (total_e, total_w))
    sys.exit(1 if total_e else 0)


if __name__ == "__main__":
    main()
