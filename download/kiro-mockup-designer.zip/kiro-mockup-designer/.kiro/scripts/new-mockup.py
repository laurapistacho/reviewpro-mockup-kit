#!/usr/bin/env python
"""
Create a new mockup folder from templates/ + the closest pattern example(s).
Windows variant of new-mockup.sh (same behavior). Works on macOS/Linux too.

Usage:
  python .kiro/scripts/new-mockup.py <mockup-name> [pattern[:file.html]] ...

  pattern   number (01) or example file name (01-dashboard-grid.html)
  :file     target file name; default is index.html for the first pattern,
            the example name without its number for the others (10-itinerary.html -> itinerary.html)

Examples:
  python .kiro/scripts/new-mockup.py rate-plans 01
  python .kiro/scripts/new-mockup.py guest-flow 01 17:profile.html 19:wizard.html

Never overwrites: fails if mockups/<mockup-name> already exists.
"""

import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
EXAMPLES = ROOT / "design-system" / "examples"


def find_example(pattern):
    if pattern.endswith(".html"):
        f = EXAMPLES / pattern
        return f if f.is_file() else None
    matches = sorted(EXAMPLES.glob(f"{pattern}-*.html"))
    return matches[0] if matches else None


def localize(text):
    return text.replace("../foundation/", "").replace("../brand/", "")


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    name, args = argv[0], argv[1:] or ["00"]
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", name):
        print(f"Mockup name must be kebab-case (a-z, 0-9, -): {name}", file=sys.stderr)
        return 2
    dest = ROOT / "mockups" / name
    if dest.exists():
        print(f"mockups/{name} already exists — pick another name or edit the existing mockup", file=sys.stderr)
        return 1

    plan = []
    for i, arg in enumerate(args):
        pattern, _, target = arg.partition(":")
        src = find_example(pattern)
        if src is None:
            print(f"No example for pattern '{pattern}'. See design-system/foundation/decision-tree.md", file=sys.stderr)
            return 1
        if not target:
            target = "index.html" if i == 0 else re.sub(r"^\d+-", "", src.name)
        plan.append((src, target))

    shutil.copytree(ROOT / "templates", dest, ignore=shutil.ignore_patterns(".DS_Store", "Thumbs.db"))
    print(f"Created mockups/{name}")
    for src, target in plan:
        out = dest / target
        if out.exists():
            print(f"  skip {target} (already created)")
            continue
        text = src.read_text(encoding="utf-8")
        out.write_text(localize(text), encoding="utf-8")
        print(f"  {target}  <-  {src.name}")
        for ref in sorted(set(re.findall(r'(?:src|href)="(\d\d-[a-z0-9-]+\.html)"', text))):
            emb = dest / ref
            if not emb.exists() and (EXAMPLES / ref).is_file():
                emb.write_text(localize((EXAMPLES / ref).read_text(encoding="utf-8")), encoding="utf-8")
                print(f"  {ref}  (embedded by {src.name})")
    print(f"Next: edit the pages, then run  python .kiro/scripts/check-mockup.py mockups/{name}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
