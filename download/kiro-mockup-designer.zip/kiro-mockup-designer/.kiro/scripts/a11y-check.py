#!/usr/bin/env python3
"""
Accessibility check of mockup pages in Chrome, against WCAG 2.2 level AA (the level EN 301 549 v4.1.1 and the European
Accessibility Act point to). It uses the keyboard like a person: real Tab, Shift+Tab, Enter, Escape and arrow presses.

  python3 .kiro/scripts/a11y-check.py mockups/<name>               # every page; Modernised (V2) pages in Light and Dark
  python3 .kiro/scripts/a11y-check.py mockups/<name>/index-v2.html
  python3 .kiro/scripts/a11y-check.py --all                        # starters, showcase (both versions), every mockup
  options: --theme light|dark|both   --json <file>   --quick (no zoom, spacing or motion pass)

What it checks, per page (and per theme on V2 pages):
  structure   lang, <title>, one h1, heading order, landmarks, skip link (V2), ARIA references, duplicate ids
  names       every control, image, chart and frame has an accessible name; required fields say so
  contrast    every visible text (4.5:1, large 3:1), placeholders, field outlines, checkbox and radio glyphs, switches,
              icon-only controls (3:1); charts: colour alone needs a legend (1.4.1), data marks 3:1 (1.4.11)
  keyboard    Tab walk through the whole page: every control is reachable, no trap, focus is always visible with a
              3:1 indicator and never hidden under the top bar or fixed buttons (2.1.1, 2.1.2, 2.4.3, 2.4.7, 2.4.11);
              selects, menus, dialogs, the side bar, the top bar selectors, tabs, tooltips and snackbars work with the
              keyboard and give focus back (Escape)
  targets     24x24px or enough space around (2.5.8)
  motion      nothing moves with reduced motion (V2); nothing loops endlessly (2.2.2)
  zoom        200% and 400% zoom (1.4.4, 1.4.10) and text spacing (1.4.12): reported as warnings

Severity
  ERROR   fails a WCAG 2.2 AA criterion. Exit code 1.
  WARN    needs a look: a likely failure, or a "library" finding on a Current UI page. Current UI pages copy the product
          as it is, so their contrast, focus-appearance, target and zoom findings are listed for the product backlog
          (the Modernised version is where they are fixed); keyboard, name and structure problems are still errors.
Python 3.9+, standard library only, plus Google Chrome (or Chromium / Edge; env CHROME overrides the path).
"""
import base64
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
AUDIT_JS = (Path(__file__).resolve().parent / "a11y-audit.js").read_text(encoding="utf-8")
CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
]
KEYS = {"Tab": ("Tab", 9, None), "Enter": ("Enter", 13, "\r"), "Escape": ("Escape", 27, None), " ": ("Space", 32, " "),
        "ArrowDown": ("ArrowDown", 40, None), "ArrowUp": ("ArrowUp", 38, None), "ArrowRight": ("ArrowRight", 39, None),
        "ArrowLeft": ("ArrowLeft", 37, None)}
LIBRARY = {"contrast", "non-text", "chart", "colour", "target", "focus-look", "zoom", "motion"}   # copied from the product: WARN on Current UI pages
MAX_TABS = 600


def chrome_path():
    if os.environ.get("CHROME"):
        return os.environ["CHROME"]
    for c in CHROME_CANDIDATES:
        if os.path.exists(c):
            return c
    found = shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chrome") or shutil.which("msedge")
    if not found:
        sys.exit("Google Chrome not found: install it, or set CHROME to its path.")
    return found


# ── a small WebSocket client (RFC 6455, client side, text frames) ──
class WebSocket:
    def __init__(self, url, timeout=60):
        m = re.match(r"ws://([^:/]+):(\d+)(/.*)", url)
        self.sock = socket.create_connection((m.group(1), int(m.group(2))), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(("GET %s HTTP/1.1\r\nHost: %s:%s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                           "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (m.group(3), m.group(1), m.group(2), key)).encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise RuntimeError("Chrome closed the DevTools connection")
            buf += chunk
        head, self.buf = buf.split(b"\r\n\r\n", 1)
        if b" 101 " not in head.split(b"\r\n")[0] + b" ":
            raise RuntimeError("DevTools refused the connection: " + head.split(b"\r\n")[0].decode(errors="replace"))

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(max(65536, n - len(self.buf)))
            if not chunk:
                raise RuntimeError("Chrome closed the DevTools connection")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send(self, text, opcode=0x1):
        data = text.encode("utf-8") if isinstance(text, str) else text
        head = bytearray([0x80 | opcode])
        n = len(data)
        if n < 126:
            head.append(0x80 | n)
        elif n < 65536:
            head.append(0x80 | 126)
            head += struct.pack(">H", n)
        else:
            head.append(0x80 | 127)
            head += struct.pack(">Q", n)
        mask = os.urandom(4)
        head += mask
        whole = (mask * (n // 4 + 1))[:n]
        masked = (int.from_bytes(data, "big") ^ int.from_bytes(whole, "big")).to_bytes(n, "big") if n else b""
        self.sock.sendall(bytes(head) + masked)

    def recv(self):
        parts = []
        while True:
            b1, b2 = self._read(2)
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            payload = self._read(n)
            op = b1 & 0x0F
            if op == 0x8:
                raise RuntimeError("Chrome closed the DevTools connection")
            if op == 0x9:
                self.send(payload, 0xA)
                continue
            if op in (0x0, 0x1, 0x2):
                parts.append(payload)
            if b1 & 0x80 and op != 0xA:
                return b"".join(parts).decode("utf-8")


class Browser:
    """Headless Chrome with one page, driven over the DevTools protocol."""

    def __init__(self):
        self.profile = tempfile.mkdtemp(prefix="rp-a11y-")
        # the background/occlusion flags keep the page rendering after key presses (Escape otherwise pauses frames)
        self.proc = subprocess.Popen([chrome_path(), "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
                                      "--hide-scrollbars", "--mute-audio", "--remote-debugging-port=0", "--user-data-dir=" + self.profile,
                                      "--allow-file-access-from-files", "--window-size=1440,900", "--force-color-profile=srgb",
                                      "--disable-background-timer-throttling", "--disable-backgrounding-occluded-windows",
                                      "--disable-renderer-backgrounding", "--disable-ipc-flooding-protection", "--enable-automation",
                                      "--disable-extensions", "--disable-default-apps", "--disable-popup-blocking", "--disable-hang-monitor",
                                      "--password-store=basic", "--use-mock-keychain", "about:blank"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        port_file, port = Path(self.profile) / "DevToolsActivePort", None
        end = time.time() + 30
        while time.time() < end and port is None:
            if port_file.exists():
                lines = port_file.read_text().split()
                port = lines[0] if lines else None
            else:
                time.sleep(0.1)
        if not port:
            self.close()
            sys.exit("Chrome did not start its DevTools endpoint.")
        target = None
        for _ in range(50):
            try:
                targets = json.loads(urllib.request.urlopen("http://127.0.0.1:%s/json/list" % port, timeout=5).read())
                target = next((t for t in targets if t.get("type") == "page"), None)
            except OSError:
                target = None
            if target:
                break
            time.sleep(0.1)
        if not target:
            self.close()
            sys.exit("Chrome has no page to drive.")
        self.ws = WebSocket(target["webSocketDebuggerUrl"])
        self.n, self.events = 0, []
        self.call("Page.enable")
        self.call("Runtime.enable")
        self.call("Emulation.setFocusEmulationEnabled", enabled=True)   # the page behaves as the focused window

    def close(self):
        try:
            self.proc.terminate()
            self.proc.wait(timeout=10)
        except Exception:
            pass
        shutil.rmtree(self.profile, ignore_errors=True)

    def call(self, method, **params):
        self.n += 1
        mid = self.n
        self.ws.sock.settimeout(60)
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s: %s" % (method, msg["error"].get("message")))
                return msg.get("result", {})
            if "method" in msg:
                self.events.append(msg)

    def wait_event(self, name, timeout=30):
        end = time.time() + timeout
        while time.time() < end:
            for i, e in enumerate(self.events):
                if e.get("method") == name:
                    del self.events[:i + 1]
                    return e
            self.ws.sock.settimeout(max(0.05, end - time.time()))
            try:
                msg = json.loads(self.ws.recv())
            except socket.timeout:
                break
            if "method" in msg:
                self.events.append(msg)
        raise RuntimeError("timeout waiting for " + name)

    def js(self, expr, wait=False):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=wait)
        if "exceptionDetails" in r:
            d = r["exceptionDetails"]
            raise RuntimeError("page script error: " + (d.get("exception", {}).get("description") or d.get("text", ""))[:400])
        return r.get("result", {}).get("value")

    def sleep(self, ms):
        self.js("new Promise(function (r) { setTimeout(r, %d); })" % ms, wait=True)

    def key(self, name, shift=False):
        code, vk, text = KEYS[name]
        mods = 8 if shift else 0
        down = {"type": "keyDown" if text else "rawKeyDown", "key": name, "code": code, "windowsVirtualKeyCode": vk,
                "nativeVirtualKeyCode": vk, "modifiers": mods}
        if text:
            down.update(text=text, unmodifiedText=text)
        self.call("Input.dispatchKeyEvent", **down)
        self.call("Input.dispatchKeyEvent", type="keyUp", key=name, code=code, windowsVirtualKeyCode=vk, nativeVirtualKeyCode=vk, modifiers=mods)

    def viewport(self, width, height, scale=1):
        self.call("Emulation.setDeviceMetricsOverride", width=width, height=height, deviceScaleFactor=scale, mobile=False)

    def load(self, url, theme=None, reduce=True):
        self.call("Emulation.setEmulatedMedia", features=[{"name": "prefers-reduced-motion", "value": "reduce" if reduce else "no-preference"}])
        self.events.clear()
        self.call("Page.navigate", url=url)
        self.wait_event("Page.loadEventFired")
        self.js("document.fonts.ready.then(function () { return true; })", wait=True)
        self.sleep(400)
        if theme == "dark":
            self.js("document.documentElement.setAttribute('data-rp-theme', 'dark')")
        elif theme == "light":
            self.js("document.documentElement.removeAttribute('data-rp-theme')")
        self.js(AUDIT_JS)
        self.js("__rpA11y.settle(2000)", wait=True)   # colour transitions of the theme switch


# ── one page, one theme ──
def run_page(b, path, theme, quick):
    url = path.resolve().as_uri()
    v2 = 'data-rp-version="v2"' in path.read_text(encoding="utf-8").split("</head>")[0][:400] or path.name.endswith("-v2.html")
    shell = "rp-top-bar" in path.read_text(encoding="utf-8")
    found = []

    def add(sc, kind, msg, el="", where="", extra=None, error=True):
        found.append({"sc": sc, "kind": kind, "msg": msg, "el": el, "where": where, "extra": extra, "error": error})

    b.viewport(1440, 900)
    b.load(url, theme=theme)
    for f in b.js("__rpA11y.audit()"):
        add(f["sc"], f["kind"], f["msg"], f["el"], f["where"], f["extra"])

    # Tab walk
    expect = b.js("__rpA11y.baseline()")
    b.js("__rpA11y.reset()")
    visited, order, last_id = {}, [], None
    for i in range(MAX_TABS):
        b.key("Tab")
        s = b.js("__rpA11y.step()")
        if s.get("body"):
            if order:
                break
            continue
        if s["id"] in visited:
            break
        visited[s["id"]] = s
        order.append(s)
    else:
        add("2.1.2", "keyboard", "the Tab walk did not come back to the start after %d stops (keyboard trap?)" % MAX_TABS)
    by_id = {e["id"]: e for e in expect}
    missing = [e for e in expect if e["id"] not in visited and not e["kit"]]
    for e in missing[:12]:
        add("2.1.1", "keyboard", "not reachable with Tab", e["el"], e["where"])
    if len(missing) > 12:
        add("2.1.1", "keyboard", "%d more elements not reachable with Tab" % (len(missing) - 12))
    looks, hidden = [], []
    for s in order:
        if s.get("kit") or s.get("unchecked"):
            continue
        if not s.get("shown"):
            add("2.4.7", "keyboard", "focus lands on an element that is not visible", s["el"], s["where"])
            continue
        if not s.get("visible"):
            looks.append(("no visible focus indicator", s))
        elif s["best"]["ratio"] < 3:
            looks.append(("focus indicator %s %s on %s is %s:1 (needs 3:1)" % (s["best"]["how"], s["best"]["colour"], s["best"]["against"], s["best"]["ratio"]), s))
        if s.get("hidden") == "full":
            hidden.append(s)
    grouped = {}
    for msg, s in looks:
        key = msg if msg.startswith("no visible") else re.sub(r" is [\d.]+:1", "", msg)
        grouped.setdefault(key, []).append(s)
    for key, items in grouped.items():
        sc = "2.4.7" if key.startswith("no visible") else "1.4.11"
        examples = ", ".join(x["el"] for x in items[:4]) + (" and %d more" % (len(items) - 4) if len(items) > 4 else "")
        add(sc, "focus-look", "%s: %d control(s), e.g. %s" % (key if key.startswith("no visible") else key + " or less", len(items), examples))
    for s in hidden[:6]:
        add("2.4.11", "keyboard", "focused element is hidden by %s" % (s.get("hiddenBy") or "a fixed part"), s["el"], s["where"])
    # Shift+Tab goes back
    if len(order) > 3:
        b.js("__rpA11y.reset()")
        b.key("Tab")
        b.key("Tab")
        b.key("Tab")
        third = b.js("__rpA11y.step()")
        b.key("Tab", shift=True)
        back = b.js("__rpA11y.step()")
        if back.get("id") != order[1]["id"] and third.get("id") == order[2]["id"]:
            add("2.4.3", "keyboard", "Shift+Tab does not go back to the previous control", back.get("el", ""))

    # skip link: first stop; Enter moves focus to the main content (or the next Tab lands there)
    sk = b.js("__rpA11y.skipLink()")
    if sk and order:
        if order[0]["id"] != sk["id"]:
            add("2.4.1", "keyboard", "the skip link is not the first Tab stop", order[0]["el"])
        b.js("__rpA11y.reset()")
        b.key("Tab")
        b.key("Enter")
        b.sleep(80)
        st = b.js("__rpA11y.flowState('none')")
        if not st["inMain"]:
            b.key("Tab")
            st = b.js("__rpA11y.flowState('none')")
            if not st["inMain"]:
                add("2.4.1", "keyboard", "the skip link does not move focus into the main content (focus: %s)" % st["focus"])

    flows(b, add)
    if not quick:
        extra_passes(b, url, theme, v2, add)

    # severity
    for f in found:
        if not v2 and f["kind"] in LIBRARY:
            f["error"] = False
            f["library"] = True
        if f["kind"] in ("zoom", "chart", "best-practice"):
            f["error"] = False
    return {"page": str(path.resolve().relative_to(ROOT)), "theme": theme or "light", "v2": v2, "shell": shell,
            "stops": len(order), "expected": len(expect), "findings": found}


def flows(b, add):
    """Each component the page has, driven with the keyboard; Escape must close it and give focus back."""
    def state(pid):
        return b.js("__rpA11y.flowState(%s)" % json.dumps(pid))

    def start(pid):
        b.key("Escape")
        b.key("Escape")
        b.js("__rpA11y.reset()")
        return b.js("__rpA11y.focusProbe(%s)" % json.dumps(pid))

    for p in b.js("__rpA11y.probe('.rp-select:not(.rp-select-disabled) > .rp-select-trigger', 2)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(120)
        s = state(p["id"])
        if not s["menuOpen"]:
            add("2.1.1", "keyboard", "select does not open with Enter", p["el"])
            continue
        if not s["inMenu"]:
            add("2.1.1", "keyboard", "select opens but focus stays outside its list (arrows cannot reach the options)", p["el"])
        before = s["focus"]
        b.key("ArrowDown")
        if state(p["id"])["focus"] == before:
            add("2.1.1", "keyboard", "arrow keys do not move through the select options", p["el"])
        b.key("Escape")
        b.sleep(80)
        s = state(p["id"])
        if s["menuOpen"] or not s["onProbe"]:
            add("2.4.3", "keyboard", "Escape does not close the select and give focus back to it (focus: %s)" % s["focus"], p["el"])
    for p in b.js("__rpA11y.probe('[data-rp-menu]', 2)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(120)
        s = state(p["id"])
        if not s["menuOpen"]:
            add("2.1.1", "keyboard", "menu button does not open its menu with Enter", p["el"])
            continue
        if not s["inMenu"]:
            add("2.1.1", "keyboard", "menu opens but focus stays on the button", p["el"])
        b.key("Escape")
        b.sleep(80)
        s = state(p["id"])
        if s["menuOpen"] or not s["onProbe"]:
            add("2.4.3", "keyboard", "Escape does not close the menu and give focus back (focus: %s)" % s["focus"], p["el"])
    for p in b.js("__rpA11y.probe('[data-rp-open]', 2)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(200)
        s = state(p["id"])
        if not s["overlayOpen"]:
            add("2.1.1", "keyboard", "dialog or drawer does not open with Enter", p["el"])
            continue
        if not s["inOverlay"]:
            add("2.4.3", "keyboard", "dialog opens but focus is not inside it (focus: %s)" % s["focus"], p["el"])
        escaped = False
        for _ in range(25):
            b.key("Tab")
            if not state(p["id"])["inOverlay"]:
                escaped = True
                break
        if escaped:
            add("2.4.3", "keyboard", "Tab leaves the open dialog: focus must stay inside until it closes", p["el"])
        b.key("Escape")
        b.sleep(150)
        s = state(p["id"])
        if s["overlayOpen"] or not s["onProbe"]:
            add("2.4.3", "keyboard", "Escape does not close the dialog and give focus back to its button (focus: %s)" % s["focus"], p["el"])
    for p in b.js("__rpA11y.probe('.rp-side-bar-item[aria-controls], .rp-side-bar-item[data-rp-section]:not([data-rp-current])', 1)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(150)
        s = state(p["id"])
        if not s["panelOpen"]:
            add("2.1.1", "keyboard", "side bar section does not open its panel with Enter", p["el"])
            continue
        b.key("Escape")
        b.sleep(150)
        s = state(p["id"])
        if s["panelOpen"]:
            b.key("Escape")
            b.sleep(120)
            s = state(p["id"])
        if s["panelOpen"] or not s["onProbe"]:
            add("2.4.3", "keyboard", "Escape does not close the section panel and give focus back to the rail (focus: %s)" % s["focus"], p["el"])
    for p in b.js("__rpA11y.probe('[data-rp-top-bar=\"establishment\"], [data-rp-top-bar=\"date\"]', 2)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(200)
        s = state(p["id"])
        if not s["menuOpen"]:
            add("2.1.1", "keyboard", "top bar selector does not open with Enter", p["el"])
            continue
        if not s["inMenu"]:
            add("2.4.3", "keyboard", "top bar selector opens but focus is not inside it", p["el"])
        b.key("Escape")
        b.sleep(120)
        s = state(p["id"])
        if s["menuOpen"] or not s["onProbe"]:
            add("2.4.3", "keyboard", "Escape does not close the top bar selector and give focus back (focus: %s)" % s["focus"], p["el"])
    for p in b.js("__rpA11y.probe('[role=\"tab\"][aria-selected=\"true\"]', 1)"):
        if not start(p["id"]):
            continue
        b.key("ArrowRight")
        b.sleep(80)
        s = state(p["id"])
        if s["onProbe"]:
            add("2.1.1", "keyboard", "arrow keys do not move between tabs", p["el"])
    for p in b.js("__rpA11y.probe('[data-rp-tooltip]', 1)"):
        if not start(p["id"]):
            continue
        b.sleep(80)
        s = state(p["id"])
        if not s["tip"]:
            add("1.4.13", "keyboard", "tooltip does not show on keyboard focus", p["el"], error=False)
            continue
        b.key("Escape")
        b.sleep(60)
        s = state(p["id"])
        if s["tip"]:
            add("1.4.13", "keyboard", "Escape does not dismiss the tooltip", p["el"])
    for p in b.js("__rpA11y.probe('button[data-rp-snackbar]:not(.rp-menu-item)', 1)"):
        if not start(p["id"]):
            continue
        b.key("Enter")
        b.sleep(150)
        s = state(p["id"])
        if s["snackbar"] is not None and not s["snackbar"]["live"]:
            add("4.1.3", "aria", "the snackbar is not announced (needs role=\"status\" or aria-live)", p["el"])


def extra_passes(b, url, theme, v2, add):
    # motion: with reduced motion nothing moves; without it nothing loops endlessly
    moving = b.js("__rpA11y.motion()")
    if moving and v2:
        add("2.3.3", "motion", "with reduced motion, %d animation(s) still run, e.g. %s" % (len(moving), moving[0]["el"]))
    b.load(url, theme=theme, reduce=False)
    b.sleep(300)
    endless = [m for m in b.js("__rpA11y.motion()") if m["iterations"] == "endless"]
    for m in endless[:3]:
        add("2.2.2", "motion", "endless animation %s on %s (it must stop within 5 s or have a pause)" % (m["name"], m["el"]))
    # zoom: 200% of a 1280px window, then 400% (320 CSS px); text spacing
    b.viewport(640, 400, 2)
    b.load(url, theme=theme)
    z = b.js("__rpA11y.reflow()")
    if z["clipped"]:
        add("1.4.4", "zoom", "at 200%% zoom text is cut off in %s" % ", ".join(z["clipped"][:3]))
    b.viewport(320, 256, 4)
    b.load(url, theme=theme)
    z = b.js("__rpA11y.reflow()")
    if z["scrollsSideways"]:
        add("1.4.10", "zoom", "at 400%% zoom (320 CSS px) the page scrolls sideways (content %dpx wide), e.g. %s" % (z["contentWidth"], ", ".join(z["wide"][:2]) or "the app shell"))
    b.viewport(1440, 900)
    b.load(url, theme=theme)
    b.js("__rpA11y.textSpacing()")
    b.sleep(100)
    z = b.js("__rpA11y.reflow()")
    if z["clipped"]:
        add("1.4.12", "zoom", "with wider text spacing text is cut off in %s" % ", ".join(z["clipped"][:3]))


# ── report ──
def summarize(res):
    errors = [f for f in res["findings"] if f["error"]]
    warns = [f for f in res["findings"] if not f["error"]]
    label = "%s · %s" % (res["page"], ("Dark" if res["theme"] == "dark" else "Light") if res["v2"] else "Current UI")
    print("%s — %s" % (label, "OK" if not errors and not warns else "%d error(s), %d warning(s)" % (len(errors), len(warns))))
    for kind, items in (("ERROR", errors), ("WARN ", warns)):
        groups = {}
        for f in items:
            groups.setdefault((f["sc"], f["msg"]), []).append(f)
        for (sc, msg), fs in groups.items():
            where = "; ".join(dict.fromkeys(f["el"] for f in fs if f["el"]))
            where = where if len(where) <= 200 else where[:197] + "…"
            tag = " (library)" if fs[0].get("library") else ""
            more = " ×%d" % len(fs) if len(fs) > 1 else ""
            print("  %s %-6s %s%s%s%s" % (kind, sc, msg, more, tag, (" · " + where) if where else ""))
    print("  keyboard: %d tab stops (%d expected)" % (res["stops"], res["expected"]))
    return len(errors), len(warns)


def pages_of(args):
    targets = []
    if "--all" in args:
        targets += sorted((ROOT / "design-system" / "examples").glob("*.html"))
        targets += sorted(p for p in (ROOT / "mockups").glob("*/*.html"))
    for a in [x for x in args if not x.startswith("--") and not re.match(r"^(light|dark|both)$", x) and not x.endswith(".json")]:
        p = Path(a) if Path(a).is_absolute() else ROOT / a
        if p.is_dir():
            targets += sorted(p.glob("*.html"))
        elif p.exists():
            targets.append(p)
        else:
            sys.exit("Not found: %s" % a)
    return [t for t in targets if not t.name.startswith("__")]


def main(argv):
    if not [a for a in argv if not a.startswith("--")] and "--all" not in argv:
        print(__doc__)
        return 2
    theme_opt = "both"
    if "--theme" in argv:
        theme_opt = argv[argv.index("--theme") + 1]
    out_json = argv[argv.index("--json") + 1] if "--json" in argv else None
    quick = "--quick" in argv
    targets = pages_of(argv)
    b = Browser()
    results, te, tw = [], 0, 0
    try:
        for p in targets:
            v2 = p.name.endswith("-v2.html") or 'data-rp-version="v2"' in p.read_text(encoding="utf-8")[:600]
            themes = (["light", "dark"] if theme_opt == "both" else [theme_opt]) if v2 else [None]
            for th in themes:
                try:
                    r = run_page(b, p, th, quick)
                except RuntimeError as e:
                    r = {"page": str(p.resolve().relative_to(ROOT)), "theme": th or "light", "v2": v2, "shell": False, "stops": 0, "expected": 0,
                         "findings": [{"sc": "-", "kind": "run", "msg": "the check could not run: %s" % e, "el": "", "where": "", "extra": None, "error": True}]}
                results.append(r)
                e, w = summarize(r)
                te += e
                tw += w
    finally:
        b.close()
    if out_json:
        Path(out_json).write_text(json.dumps(results, indent=1, ensure_ascii=False), encoding="utf-8")
    print("\n%d error(s), %d warning(s) · WCAG 2.2 AA" % (te, tw))
    return 1 if te else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
