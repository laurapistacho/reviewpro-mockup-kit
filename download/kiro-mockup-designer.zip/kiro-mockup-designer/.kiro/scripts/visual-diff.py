#!/usr/bin/env python3
"""
Before/after layout diff of every DS example and mockup in headless Chrome (DS maintainers).

Usage:
  python3 .kiro/scripts/visual-diff.py               # working tree vs HEAD
  python3 .kiro/scripts/visual-diff.py --ref dbc8673 # working tree vs a commit
  python3 .kiro/scripts/visual-diff.py --ref HEAD design-system/examples/02-filters-panel.html
  python3 .kiro/scripts/visual-diff.py --ref dbc8673 --local-before /path/to/backup   # see below

For every element on the page it compares position, size, colors, font, borders, display,
shadow and opacity (1440x900 viewport), plus page errors, the Noto Sans load state and icons
without a glyph. Prints only pages that differ. Exit 1 when a page differs or breaks.

"Before" = `git archive <ref>`. Gitignored local mockups are not in git: their before-HTML
is the current file, with shared.css / shared.js / tweak/ taken from <ref>'s templates/.
After a rename that also rewrote their HTML, pass --local-before DIR: a folder with
<mockup>/<page>.html copies made before the change (DIR/<mockup>/ mirrors mockups/<mockup>/).
Needs Google Chrome (env CHROME to override the path). Python 3 standard library only.
"""

import difflib
import functools
import glob
import html
import http.server
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CHROME = os.environ.get("CHROME", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
RUNTIME = ["shared.css", "shared.js", "tokens-extended.css"]

SIG_JS = r"""
(function () {
  function run() {
    var font = []; document.fonts.forEach(function (f) { if (f.family.replace(/["']/g, '') === 'Noto Sans') font.push(f.status); });
    var empty = [];
    document.querySelectorAll('.rp-icon').forEach(function (i) { var st = getComputedStyle(i); if (!st.getPropertyValue('--rp-icon').trim() && st.backgroundImage === 'none') empty.push(i.className); });
    var els = Array.prototype.filter.call(document.body.querySelectorAll('*'), function (e) { return !/^(SCRIPT|STYLE|TEMPLATE|PRE)$/.test(e.tagName) && !/(^|\s)rp-tooltip(\s|$)/.test(e.className); });
    var sig = els.map(function (e) {
      if (e.getAnimations && e.getAnimations().length) return e.tagName + '|animated';
      var r = e.getBoundingClientRect(), s = getComputedStyle(e);
      return [e.tagName, Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height), s.color, s.backgroundColor, s.fontSize, s.fontWeight,
        s.borderTopWidth + ' ' + s.borderTopColor + ' ' + s.borderLeftWidth + ' ' + s.borderLeftColor, s.display, s.boxShadow === 'none' ? '' : 'sh', s.opacity, s.textTransform].join('|');
    });
    var where = els.map(function (e) { return e.tagName.toLowerCase() + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).join('.') : ''); });
    var p = document.createElement('pre'); p.id = 'vd-report';
    p.textContent = JSON.stringify({ errors: window.__vdErrs || [], font: font, empty: empty.slice(0, 5), sig: sig, where: where });
    document.body.appendChild(p);
  }
  window.addEventListener('load', function () { document.fonts.ready.then(function () { setTimeout(run, 200); }); });
})();
"""
HOOK = '<script>window.__vdErrs=[];window.addEventListener("error",function(e){window.__vdErrs.push(String(e.message))});</script>'


def pages(args):
    if args:
        return args
    out = sorted(glob.glob("design-system/examples/*.html"))
    for d in sorted(glob.glob("mockups/*/")):
        out += sorted(glob.glob(d + "*.html"))
    return [p for p in out if not re.search(r'http-equiv=["\']refresh', open(p, encoding="utf-8").read(), re.I)]


def build_before(ref, tmp, local_before=None):
    before = os.path.join(tmp, "before")
    os.makedirs(before)
    data = subprocess.run(["git", "-C", ROOT, "archive", ref], capture_output=True, check=True).stdout
    with tarfile.open(fileobj=__import__("io").BytesIO(data)) as tf:
        tf.extractall(before, filter="data")
    tracked = set(subprocess.run(["git", "-C", ROOT, "ls-files", "mockups"], capture_output=True, text=True).stdout.split())
    for d in glob.glob(os.path.join(ROOT, "mockups", "*", "")):
        rel = os.path.relpath(d, ROOT)
        if any(t.startswith(rel) for t in tracked):
            continue
        dst = os.path.join(before, rel)
        shutil.copytree(d, dst, dirs_exist_ok=True)
        if local_before:
            for f in glob.glob(os.path.join(local_before, os.path.basename(rel.rstrip("/")), "*.html")):
                shutil.copy(f, dst)
        for f in RUNTIME:
            src = os.path.join(before, "templates", f)
            if os.path.exists(os.path.join(dst, f)) and os.path.exists(src):
                shutil.copy(src, os.path.join(dst, f))
        if os.path.isdir(os.path.join(dst, "tweak")) and os.path.isdir(os.path.join(before, "templates", "tweak")):
            shutil.rmtree(os.path.join(dst, "tweak"))
            shutil.copytree(os.path.join(before, "templates", "tweak"), os.path.join(dst, "tweak"))
    os.symlink(ROOT, os.path.join(tmp, "after"))
    return tmp


def serve(directory):
    class H(http.server.SimpleHTTPRequestHandler):
        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            super().end_headers()

        def log_message(self, *a):
            pass
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), functools.partial(H, directory=directory))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return port


def grab(tmp, port, side, page):
    d, n = os.path.split(page)
    src = os.path.join(tmp, side, page)
    if not os.path.exists(src):
        return None
    probe = os.path.join(tmp, side, d, "__vd_" + n)
    t = open(src, encoding="utf-8").read()
    t = re.sub(r"(<head[^>]*>)", lambda m: m.group(1) + HOOK, t, count=1)
    t = t.replace("</body>", "<script>" + SIG_JS + "</script></body>", 1)
    open(probe, "w", encoding="utf-8").write(t)
    try:
        out = subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--window-size=1440,900",
                              "--virtual-time-budget=4000", "--dump-dom", f"http://127.0.0.1:{port}/{side}/{d}/__vd_{n}"],
                             capture_output=True, text=True, timeout=45).stdout
    except subprocess.TimeoutExpired:
        out = ""
    finally:
        os.remove(probe)
    m = list(re.finditer(r'<pre id="vd-report">(.*?)</pre>', out, re.S))
    return json.loads(html.unescape(m[-1].group(1))) if m else None


def compare(tmp, port, page):
    b, a = grab(tmp, port, "before", page), grab(tmp, port, "after", page)
    if a is None:
        return {"page": page, "problem": "after page did not report"}
    if b is None:
        return {"page": page, "new": True, "errors": a["errors"], "empty": a["empty"], "font": a["font"], "diffs": []}
    tag = lambda s: [x.split("|")[0] for x in s["sig"]]
    sm = difflib.SequenceMatcher(None, tag(b), tag(a), autojunk=False)
    diffs = [(a["where"][blk.b + k], b["sig"][blk.a + k], a["sig"][blk.b + k])
             for blk in sm.get_matching_blocks() for k in range(blk.size) if a["sig"][blk.b + k] != b["sig"][blk.a + k]]
    return {"page": page, "els": f"{len(b['sig'])}->{len(a['sig'])}", "errors": a["errors"], "empty": a["empty"],
            "font": a["font"], "diffs": diffs}


def main(argv):
    ref = "HEAD"
    if "--ref" in argv:
        i = argv.index("--ref"); ref = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
    local_before = None
    if "--local-before" in argv:
        i = argv.index("--local-before"); local_before = os.path.abspath(argv[i + 1]); argv = argv[:i] + argv[i + 2:]
    os.chdir(ROOT)
    todo = pages([a for a in argv if not a.startswith("--")])
    tmp = build_before(ref, tempfile.mkdtemp(prefix="rp-visual-diff-"), local_before)
    port = serve(tmp)
    try:
        with ThreadPoolExecutor(6) as ex:
            res = list(ex.map(lambda p: compare(tmp, port, p), todo))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    bad = 0
    for r in res:
        broken = r.get("problem") or r["errors"] or r["empty"] or (r["font"] and "loaded" not in r["font"])
        if not broken and not r["diffs"] and not r.get("new"):
            continue
        bad += 1 if (broken or r["diffs"]) else 0
        head = r.get("problem") or ("NEW page" if r.get("new") else f"{len(r['diffs'])} element(s) differ, elements {r['els']}")
        print(f"## {r['page']} — {head}")
        for k in ("errors", "empty"):
            if r.get(k):
                print(f"   {k}: {r[k]}")
        if r.get("font") and "loaded" not in r["font"]:
            print(f"   Noto Sans: {r['font']}")
        for w, x, y in r.get("diffs", [])[:4]:
            print(f"   {w[:100]}\n      before {x[:160]}\n      after  {y[:160]}")
    print(f"\n{len(res)} page(s) vs {ref}: {len(res) - bad} identical, {bad} differ or broken")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
