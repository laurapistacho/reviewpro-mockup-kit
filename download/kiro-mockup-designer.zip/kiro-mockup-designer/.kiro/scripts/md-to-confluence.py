#!/usr/bin/env python3
"""
Convert a kit Markdown document into Confluence wiki markup, for pasting into a Confluence page
(Confluence Data Center: in the editor choose Insert > Markup > Confluence wiki, paste, Insert).

  python3 .kiro/scripts/md-to-confluence.py design-system/v2/MODERNISATION-PLAN.md
      -> design-system/v2/modernisation-plan.confluence.txt
  python3 .kiro/scripts/md-to-confluence.py <file.md> <out.txt>

Handles the Markdown the kit docs use: headings, paragraphs, bullet and numbered lists, tables (a header row becomes
||header||), **bold**, *italic*, `code`, [links](url) and > quotes (an {info} panel). Table cells that are exactly
Low, Medium or High become coloured status lozenges (green, yellow, red); Ready, Decision and Design become blue,
grey and purple ones. Text that wiki markup would read as markup ({ } [ ] | at the start of a cell) is escaped.
Python 3.9+, standard library only.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
STATUS = {"Low": "Green", "Medium": "Yellow", "High": "Red", "Ready": "Blue", "Decision": "Grey", "Design": "Purple"}


def inline(text):
    """Markdown inline -> wiki inline. Code first, so nothing inside it is converted."""
    parts = re.split(r"(`[^`]+`)", text)
    out = []
    for part in parts:
        if part.startswith("`") and part.endswith("`") and len(part) > 1:
            code = part[1:-1].replace("{", "\\{").replace("}", "\\}").replace("[", "\\[").replace("]", "\\]")
            out.append("{{" + code + "}}")
            continue
        s = part
        s = s.replace("{", "\\{").replace("}", "\\}")
        links = []

        def keep_link(m):
            links.append("[%s|%s]" % (m.group(1).replace("|", "-"), m.group(2)))
            return "\x00%d\x00" % (len(links) - 1)
        s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", keep_link, s)
        s = s.replace("[", "\\[").replace("]", "\\]")
        s = re.sub(r"\*\*(.+?)\*\*", lambda m: "\x01" + m.group(1) + "\x01", s)   # bold
        s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"_\1_", s)   # italic
        s = s.replace("\x01", "*")
        s = re.sub(r"\x00(\d+)\x00", lambda m: links[int(m.group(1))], s)
        out.append(s)
    return "".join(out)


def cell(text):
    t = text.strip()
    if t in STATUS:
        return "{status:colour=%s|title=%s}" % (STATUS[t], t)
    m = re.match(r"^(%s) (\(.*\))$" % "|".join(STATUS), t)   # "Decision (M0.1)"
    if m:
        return "{status:colour=%s|title=%s} %s" % (STATUS[m.group(1)], m.group(1), inline(m.group(2)))
    s = inline(t).replace("|", "\\|") if "|" in t and "](" not in t else inline(t)
    return s if s else " "


def split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    cells, cur, depth = [], "", 0
    for ch in line:   # a | inside `code` or a [link] does not split the cell
        if ch == "`":
            depth ^= 1
        if ch == "|" and not depth:
            cells.append(cur)
            cur = ""
        else:
            cur += ch
    cells.append(cur)
    return cells


def convert(md):
    lines = md.splitlines()
    out, i = [], 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            out.append("")
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            out.append("h%d. %s" % (len(m.group(1)), inline(m.group(2))))
            i += 1
            continue
        if line.startswith(">"):
            quote = []
            while i < len(lines) and lines[i].startswith(">"):
                quote.append(lines[i].lstrip(">").strip())
                i += 1
            out.append("{info}" + inline(" ".join(quote)) + "{info}")
            continue
        if line.lstrip().startswith("|"):
            rows = []
            while i < len(lines) and lines[i].lstrip().startswith("|"):
                rows.append(lines[i])
                i += 1
            header, body = rows[0], rows[1:]
            if body and re.match(r"^\s*\|?\s*:?-{3,}", body[0]):
                body = body[1:]
                heads = split_row(header)
                if any(h.strip() for h in heads):
                    out.append("||" + "||".join(" " + inline(h.strip()) + " " for h in heads) + "||")
                    rows_out = body
                else:   # an empty header row (a key / value table): no header
                    rows_out = body
            else:
                rows_out = rows
            for r in rows_out:
                out.append("|" + "|".join(" " + cell(c) + " " for c in split_row(r)) + "|")
            continue
        m = re.match(r"^(\s*)([-*]|\d+\.)\s+(.*)$", line)
        if m:
            while i < len(lines):
                m = re.match(r"^(\s*)([-*]|\d+\.)\s+(.*)$", lines[i])
                if not m:
                    if lines[i].startswith("   ") and lines[i].strip() and out:   # continuation of the item
                        out[-1] += " " + inline(lines[i].strip())
                        i += 1
                        continue
                    break
                depth = len(m.group(1)) // 2 + 1
                mark = "#" if m.group(2)[0].isdigit() else "*"
                out.append(mark * depth + " " + inline(m.group(3)))
                i += 1
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#{1,6}\s|>|\s*\||\s*([-*]|\d+\.)\s)", lines[i]):
            para.append(lines[i].strip())
            i += 1
        out.append(inline(" ".join(para)))
    text = "\n".join(out)
    return re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    src = Path(argv[0]) if Path(argv[0]).is_absolute() else ROOT / argv[0]
    dst = Path(argv[1]) if len(argv) > 1 else src.with_name(re.sub(r"[^a-z0-9]+", "-", src.stem.lower()).strip("-") + ".confluence.txt")
    dst.write_text(convert(src.read_text(encoding="utf-8")), encoding="utf-8")
    print("%s written (Confluence: Insert > Markup > Confluence wiki)" % dst.relative_to(ROOT) if dst.is_relative_to(ROOT) else dst)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
