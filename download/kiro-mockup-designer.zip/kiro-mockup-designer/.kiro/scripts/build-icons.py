#!/usr/bin/env python3
"""
Generate the icon classes from the production ReviewPro icons (maintainer script).

Source of truth: the React icon components of @reviewpro/ui-components
(frontend-workspace/libs/ui-components/src/icons/*.tsx). Each one is a single <SvgIcon>.
The script turns every icon into a CSS mask (a data URI), so a mockup uses an icon like a font
glyph: <span class="rp-icon rp-icon-search"></span>. The color is currentColor.
Icons drawn in several fixed colors (logos, channel icons) keep their colors (background image).

Writes:
  1. design-system/foundation/rp-icons.css   .rp-icon base, sizes, one class per icon (+ aliases)
  2. the GLYPHS:GENERATED block in design-system/foundation/shared.css
     (:root --rp-glyph-* variables, the few glyphs components draw themselves: checkbox, select arrow…)
  3. design-system/foundation/icons-full-reference.md   every icon: class, React import, aliases
  4. design-system/foundation/tweak/glyphs.js            the icon picker list (ICON-LIST block)

Usage:
  python3 .kiro/scripts/build-icons.py                        # default source path (below)
  python3 .kiro/scripts/build-icons.py --src <path to libs/ui-components/src/icons>
Then copy rp-icons.css and shared.css to templates/ (CI-style check: check-mockup.py --all).
"""
import argparse
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
FOUND = ROOT / "design-system" / "foundation"
CSS_OUT = FOUND / "rp-icons.css"
SHARED = FOUND / "shared.css"
REF = FOUND / "icons-full-reference.md"
TWEAK = FOUND / "tweak" / "glyphs.js"
DEFAULT_SRC = Path.home() / "frontend-workspace" / "libs" / "ui-components" / "src" / "icons"

G_START = "/* GLYPHS:GENERATED-START — do not edit by hand, run .kiro/scripts/build-icons.py */"
G_END = "/* GLYPHS:GENERATED-END */"
LIST_START = "/*ICON-LIST-START*/"
LIST_END = "/*ICON-LIST-END*/"

# Glyphs that components draw themselves (shared.css uses var(--rp-glyph-<name>)).
COMPONENT_GLYPHS = ["check", "close", "down", "up", "arrow-up", "arrow-down", "minus", "search",
                    "triangle-down", "calendar"]

# Names people and AI agents commonly guess -> the production icon name (kebab case).
ALIASES = {
    "plus": "add", "new": "add", "create": "add",
    "trash": "delete", "bin": "delete", "remove": "delete",
    "pencil": "edit", "x": "close", "cancel": "close",
    "kebab": "actions", "dots": "actions", "ellipsis": "actions", "more-vert": "actions",
    "chevron-down": "down", "chevron-up": "up", "chevron-left": "left", "chevron-right": "right",
    "caret-down": "triangle-down", "gear": "settings-outlined", "cog": "settings-outlined",
    "settings": "settings-outlined", "bell": "notification", "notifications": "notification",
    "help": "question-mark", "question": "question-mark", "magnifier": "search", "find": "search",
    "funnel": "filter", "mail": "email", "envelope": "email", "person": "user",
    "logout": "log-out", "sign-out": "log-out", "eye": "show", "visible": "show", "eye-off": "hide",
    "tick": "check", "done": "check", "external": "external-link", "duplicate-copy": "copy",
    "refresh": "sync", "hamburger": "menu", "sort": "sort-by", "drag": "drag-handle",
    "time": "clock", "globe": "languages", "language": "languages", "chat": "messaging",
    "message": "messaging", "warning-triangle": "warning", "alert-circle": "error",
    "home-outline": "home", "reviews-star": "reviews", "survey-list": "survey",
}

CAMEL_KEEP = {"viewBox", "gradientUnits", "gradientTransform", "maskUnits", "maskContentUnits",
              "patternUnits", "patternContentUnits", "patternTransform", "clipPathUnits",
              "preserveAspectRatio", "filterUnits", "primitiveUnits", "stdDeviation", "numOctaves",
              "baseFrequency", "kernelMatrix", "tableValues", "edgeMode", "lengthAdjust",
              "textLength", "spreadMethod", "refX", "refY", "markerWidth", "markerHeight", "markerUnits"}


def kebab(name):
    s = name.replace("&", " ")
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", s)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1-\2", s)
    s = re.sub(r"[^A-Za-z0-9]+", "-", s)
    return s.strip("-").lower()


def attr_name(n):
    if n in CAMEL_KEEP:
        return n
    if n == "xlinkHref":
        return "href"
    return re.sub(r"([a-z])([A-Z])", r"\1-\2", n).lower()


NUM = re.compile(r"-?\d*\.\d+(?:e-?\d+)?|-?\d+(?:e-?\d+)?")


def short_num(m):
    t = m.group(0)
    if "e" in t or "." not in t:
        return t
    v = round(float(t), 1)
    s = ("%.1f" % v).rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    if s.startswith("0."):
        s = s[1:]
    elif s.startswith("-0."):
        s = "-" + s[2:]
    return s


def minify_path(d):
    d = NUM.sub(short_num, d)
    d = re.sub(r"\s*,\s*", ",", d)
    d = re.sub(r"\s+", " ", d).strip()
    d = re.sub(r"\s*([A-Za-z])\s*", r"\1", d)
    d = re.sub(r",(-)", r"\1", d)
    d = re.sub(r" (-)", r"\1", d)
    return d


def convert(tsx):
    """JSX inside <SvgIcon …>…</SvgIcon> → (viewBox, svg inner markup, multicolor) or None."""
    m = re.search(r"<SvgIcon\b([^>]*)>(.*?)</SvgIcon>", tsx, re.S)
    if not m:
        return None
    head, body = m.group(1), m.group(2)
    vb = re.search(r'viewBox="([^"]+)"', head)
    viewbox = vb.group(1) if vb else "0 0 32 32"
    body = re.sub(r"\{/\*.*?\*/\}", "", body, flags=re.S)
    body = re.sub(r"\s+style=\{\{.*?\}\}", "", body, flags=re.S)
    body = re.sub(r"\s(?:key|className|data-[\w-]+)=(?:\{[^}]*\}|\"[^\"]*\")", "", body)
    body = re.sub(r"=\{(?:mainColor|color|secondaryColor)\}", '="#000"', body)
    body = re.sub(r"=\{\s*(-?[\d.]+)\s*\}", r'="\1"', body)
    body = re.sub(r"=\{\s*'([^']*)'\s*\}", r'="\1"', body)
    body = re.sub(r'=\{\s*"([^"]*)"\s*\}', r'="\1"', body)
    body = re.sub(r"\s[\w:-]+=\{[^{}]*\}", "", body)  # anything else dynamic: drop the attribute
    if "{" in body or "}" in body:
        return None

    def fix_tag(t):
        def fix_attr(a):
            name, val = a.group(1), a.group(2)
            name = attr_name(name)
            if name in ("d",):
                val = minify_path(val)
            elif name == "points":
                val = NUM.sub(short_num, val)
            return " %s='%s'" % (name, val.replace("'", "&apos;"))
        return re.sub(r'\s([\w:-]+)="([^"]*)"', fix_attr, t.group(0))

    body = re.sub(r"<[a-zA-Z][^>]*>", fix_tag, body)
    body = re.sub(r"<[^>]+>", lambda t: re.sub(r"\s+", " ", t.group(0)).replace(" />", "/>").replace(" >", ">"), body)
    body = re.sub(r">\s+<", "><", body).strip()
    colors = set(c.lower() for c in re.findall(r"(?:fill|stroke|stop-color)='(#[0-9a-fA-F]{3,8}|white|black)'", body))
    multicolor = bool(colors - {"#000", "#000000", "black"})
    return viewbox, body, multicolor


def data_uri(viewbox, body, multicolor):
    svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='%s'>%s</svg>" % (viewbox, body)
    if multicolor:
        svg = svg.replace("'#000'", "'#636363'")
    enc = svg.replace("%", "%25").replace("#", "%23").replace("<", "%3C").replace(">", "%3E").replace('"', "'")
    return 'url("data:image/svg+xml,%s")' % enc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.environ.get("RP_ICONS_SRC", str(DEFAULT_SRC)))
    args = ap.parse_args()
    src = Path(args.src).expanduser()
    if not src.is_dir():
        sys.exit("Icon source not found: %s\nPass --src <frontend-workspace>/libs/ui-components/src/icons" % src)

    icons, skipped = {}, []
    for f in sorted(src.glob("*.tsx")):
        if f.name.endswith((".stories.tsx", ".test.tsx")):
            continue
        res = convert(f.read_text(encoding="utf-8"))
        if res is None:
            skipped.append(f.stem)
            continue
        icons[kebab(f.stem)] = (f.stem,) + res

    aliases = {}
    for a, target in ALIASES.items():
        if target in icons and a not in icons:
            aliases.setdefault(target, []).append(a)

    # 1. rp-icons.css
    out = ["/* ReviewPro icons — GENERATED by .kiro/scripts/build-icons.py from @reviewpro/ui-components/icons.",
           "   Do not edit by hand. <span class=\"rp-icon rp-icon-search\"></span> = <Search size={24} />.",
           "   Mask icons take the text color (currentColor); multicolor icons keep their own colors. */",
           ".rp-icon { display: inline-block; flex: none; width: 24px; height: 24px; vertical-align: middle;",
           "  background-color: currentColor; -webkit-mask: var(--rp-icon) center / contain no-repeat; mask: var(--rp-icon) center / contain no-repeat; }",
           ".rp-icon-multicolor { background: var(--rp-icon) center / contain no-repeat; -webkit-mask: none; mask: none; }",
           ".rp-icon-size-12 { width: 12px; height: 12px; }",
           ".rp-icon-size-16 { width: 16px; height: 16px; }",
           ".rp-icon-size-20 { width: 20px; height: 20px; }",
           ".rp-icon-size-32 { width: 32px; height: 32px; }",
           ".rp-icon-size-48 { width: 48px; height: 48px; }",
           ".rp-icon-size-80 { width: 80px; height: 80px; }"]
    multi = []
    for name, (stem, vb, body, mc) in icons.items():
        sels = [".rp-icon-" + name] + [".rp-icon-" + a for a in aliases.get(name, [])]
        rule = "%s { --rp-icon: %s; }" % (", ".join(sels), data_uri(vb, body, mc))
        out.append(rule)
        if mc:
            multi.append(name)
    if multi:
        out.append(", ".join(".rp-icon.rp-icon-" + n for n in multi) +
                   " { background: var(--rp-icon) center / contain no-repeat; -webkit-mask: none; mask: none; }")
    CSS_OUT.write_text("\n".join(out) + "\n", encoding="utf-8")

    # 2. glyph variables in shared.css
    glyph_lines = [G_START, ":root {"]
    for g in COMPONENT_GLYPHS:
        if g in icons:
            stem, vb, body, mc = icons[g]
            glyph_lines.append("  --rp-glyph-%s: %s;" % (g, data_uri(vb, body, False)))
    glyph_lines += ["}", G_END]
    if SHARED.exists():
        css = SHARED.read_text(encoding="utf-8")
        if G_START in css and G_END in css:
            pre, rest = css.split(G_START, 1)
            post = rest.split(G_END, 1)[1]
            SHARED.write_text(pre + "\n".join(glyph_lines) + post, encoding="utf-8")
        else:
            print("shared.css has no GLYPHS:GENERATED markers; glyph variables not written")

    # 3. reference
    ref = ["# Icon Reference", "",
           "Every icon of `@reviewpro/ui-components/icons` (generated by `.kiro/scripts/build-icons.py`, do not edit).",
           "Use the **Class** column: `<span class=\"rp-icon rp-icon-search\"></span>` is `<Search size={24} />`.",
           "Sizes: no class = 24px (pass `size={24}` in code, the code default is 32), `rp-icon-size-12 | 16 | 20 | 32 | 48 | 80`.",
           "Color: the icon takes the text color (`color` prop in code). Multicolor icons keep their colors.", "",
           "%d icons, %d aliases. Skipped (not a single SvgIcon): %s" % (
               len(icons), sum(len(v) for v in aliases.values()), ", ".join(skipped) or "none"), "",
           "| Class | React import | Aliases | Note |", "|---|---|---|---|"]
    for name, (stem, vb, body, mc) in icons.items():
        ref.append("| `rp-icon-%s` | `import %s from '@reviewpro/ui-components/icons/%s'` | %s | %s |" % (
            name, re.sub(r"[^A-Za-z0-9]", "", stem), stem,
            ", ".join("`rp-icon-%s`" % a for a in aliases.get(name, [])), "multicolor" if mc else ""))
    REF.write_text("\n".join(ref) + "\n", encoding="utf-8")

    # 4. tweak icon picker list
    if TWEAK.exists():
        js = TWEAK.read_text(encoding="utf-8")
        items = [[n] + aliases.get(n, []) for n in icons]
        lst = "[" + ",".join('"%s"' % " ".join(i) for i in items) + "]"
        if LIST_START in js and LIST_END in js:
            pre, rest = js.split(LIST_START, 1)
            post = rest.split(LIST_END, 1)[1]
            TWEAK.write_text(pre + LIST_START + lst + LIST_END + post, encoding="utf-8")
        else:
            print("tweak/glyphs.js has no ICON-LIST markers; icon picker not updated")

    kb = CSS_OUT.stat().st_size // 1024
    print("rp-icons.css: %d icons (%d multicolor), %d aliases, %d KB" % (len(icons), len(multi), sum(len(v) for v in aliases.values()), kb))
    if skipped:
        print("skipped:", ", ".join(skipped))


if __name__ == "__main__":
    main()
