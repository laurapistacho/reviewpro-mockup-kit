#!/usr/bin/env python3
"""
Generate the icon classes from the ReviewPro icon library (maintainer script).

Sources, in order:
  1. the Figma icon library (Pictograms and Icons, page Icons): design-system/foundation/icons-figma/
     (manifest.json + one SVG per kit class). Figma is the source of truth: its SVG wins.
  2. the React icon components of @reviewpro/ui-components
     (frontend-workspace/libs/ui-components/src/icons/*.tsx and departments/*.tsx), for the icons
     Figma does not have, and for the React import shown in the reference. Each one is a single <SvgIcon>.
The script turns every icon into a CSS mask (a data URI), so a mockup uses an icon like a font
glyph: <span class="rp-icon rp-icon-search"></span>. The color is currentColor.
Icons drawn in several fixed colors (logos, channel icons) keep their colors (background image).

Writes:
  1. design-system/foundation/rp-icons.css   .rp-icon base, sizes, one class per icon (+ aliases)
  2. the GLYPHS:GENERATED block in design-system/foundation/shared.css
     (:root --rp-glyph-* variables, the few glyphs components draw themselves: checkbox, select arrow…)
  3. design-system/foundation/icons-full-reference.md   every icon: class, React import, aliases
  4. design-system/foundation/tweak/glyphs.js            the icon picker list (ICON-LIST block)

Usage:
  python3 .kiro/scripts/build-icons.py                        # default source path (below)
  python3 .kiro/scripts/build-icons.py --src <path to libs/ui-components/src/icons>
  python3 .kiro/scripts/build-icons.py --no-figma             # React icons only
To refresh the Figma icons: export the icon components as SVG with the Figma MCP
(download_figma_images, file sG8E7rdnYt59mgmYDMr7PY) into icons-figma/ under the names in manifest.json.
Then copy rp-icons.css and shared.css to templates/ (CI-style check: check-mockup.py --all).
"""
import argparse
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
FOUND = ROOT / "design-system" / "foundation"
CSS_OUT = FOUND / "rp-icons.css"
SHARED = FOUND / "shared.css"
REF = FOUND / "icons-full-reference.md"
TWEAK = FOUND / "tweak" / "glyphs.js"
DEFAULT_SRC = Path.home() / "frontend-workspace" / "libs" / "ui-components" / "src" / "icons"
FIGMA_DIR = FOUND / "icons-figma"

G_START = "/* GLYPHS:GENERATED-START — do not edit by hand, run .kiro/scripts/build-icons.py */"
G_END = "/* GLYPHS:GENERATED-END */"
LIST_START = "/*ICON-LIST-START*/"
LIST_END = "/*ICON-LIST-END*/"

# Glyphs that components draw themselves (shared.css uses var(--rp-glyph-<name>)).
COMPONENT_GLYPHS = ["check", "close", "down", "up", "arrow-up", "arrow-down", "minus", "search",
                    "triangle-down", "calendar"]

# Names people and AI agents commonly guess -> the production icon name (kebab case).
ALIASES = {
    "plus": "add", "new": "add", "create": "add",
    "trash": "delete", "bin": "delete", "remove": "delete",
    "pencil": "edit", "x": "close", "cancel": "close",
    "kebab": "actions", "dots": "actions", "ellipsis": "actions", "more-vert": "actions",
    "chevron-down": "down", "chevron-up": "up", "chevron-left": "left", "chevron-right": "right",
    "caret-down": "triangle-down", "gear": "settings-outlined", "cog": "settings-outlined",
    "settings": "settings-outlined", "bell": "notification", "notifications": "notification",
    "help": "question-mark", "question": "question-mark", "magnifier": "search", "find": "search",
    "funnel": "filter", "mail": "email", "envelope": "email", "person": "user",
    "logout": "log-out", "sign-out": "log-out", "eye": "show", "visible": "show", "eye-off": "hide",
    "tick": "check", "done": "check", "external": "external-link", "duplicate-copy": "copy",
    "refresh": "sync", "hamburger": "menu", "sort": "sort-by", "drag": "drag-handle",
    "time": "clock", "globe": "languages", "language": "languages", "chat": "messaging",
    "message": "messaging", "warning-triangle": "warning", "alert-circle": "error",
    "home-outline": "home", "reviews-star": "reviews", "survey-list": "survey",
}

CAMEL_KEEP = {"viewBox", "gradientUnits", "gradientTransform", "maskUnits", "maskContentUnits",
              "patternUnits", "patternContentUnits", "patternTransform", "clipPathUnits",
              "preserveAspectRatio", "filterUnits", "primitiveUnits", "stdDeviation", "numOctaves",
              "baseFrequency", "kernelMatrix", "tableValues", "edgeMode", "lengthAdjust",
              "textLength", "spreadMethod", "refX", "refY", "markerWidth", "markerHeight", "markerUnits"}


def kebab(name):
    s = name.replace("&", " ")
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", s)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1-\2", s)
    s = re.sub(r"[^A-Za-z0-9]+", "-", s)
    return s.strip("-").lower()


def attr_name(n):
    if n in CAMEL_KEEP:
        return n
    if n == "xlinkHref":
        return "href"
    return re.sub(r"([a-z])([A-Z])", r"\1-\2", n).lower()


NUM = re.compile(r"-?\d*\.\d+(?:e-?\d+)?|-?\d+(?:e-?\d+)?")


def short_num(m):
    t = m.group(0)
    if "e" in t or "." not in t:
        return t
    v = round(float(t), 1)
    s = ("%.1f" % v).rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    if s.startswith("0."):
        s = s[1:]
    elif s.startswith("-0."):
        s = "-" + s[2:]
    return s


def minify_path(d):
    d = NUM.sub(short_num, d)
    d = re.sub(r"\s*,\s*", ",", d)
    d = re.sub(r"\s+", " ", d).strip()
    d = re.sub(r"\s*([A-Za-z])\s*", r"\1", d)
    d = re.sub(r",(-)", r"\1", d)
    d = re.sub(r" (-)", r"\1", d)
    return d


def convert(tsx):
    """JSX inside <SvgIcon …>…</SvgIcon> → (viewBox, svg inner markup, multicolor) or None."""
    m = re.search(r"<SvgIcon\b([^>]*)>(.*?)</SvgIcon>", tsx, re.S)
    if not m:
        return None
    head, body = m.group(1), m.group(2)
    vb = re.search(r'viewBox="([^"]+)"', head)
    viewbox = vb.group(1) if vb else "0 0 32 32"
    body = re.sub(r"\{/\*.*?\*/\}", "", body, flags=re.S)
    body = re.sub(r"\s+style=\{\{.*?\}\}", "", body, flags=re.S)
    body = re.sub(r"\s(?:key|className|data-[\w-]+)=(?:\{[^}]*\}|\"[^\"]*\")", "", body)
    body = re.sub(r"=\{(?:mainColor|color|secondaryColor)\}", '="#000"', body)
    body = re.sub(r"=\{\s*(-?[\d.]+)\s*\}", r'="\1"', body)
    body = re.sub(r"=\{\s*'([^']*)'\s*\}", r'="\1"', body)
    body = re.sub(r'=\{\s*"([^"]*)"\s*\}', r'="\1"', body)
    body = re.sub(r"\s[\w:-]+=\{[^{}]*\}", "", body)  # anything else dynamic: drop the attribute
    if "{" in body or "}" in body:
        return None

    def fix_tag(t):
        def fix_attr(a):
            name, val = a.group(1), a.group(2)
            name = attr_name(name)
            if name in ("d",):
                val = minify_path(val)
            elif name == "points":
                val = NUM.sub(short_num, val)
            return " %s='%s'" % (name, val.replace("'", "&apos;"))
        return re.sub(r'\s([\w:-]+)="([^"]*)"', fix_attr, t.group(0))

    body = re.sub(r"<[a-zA-Z][^>]*>", fix_tag, body)
    body = re.sub(r"<[^>]+>", lambda t: re.sub(r"\s+", " ", t.group(0)).replace(" />", "/>").replace(" >", ">"), body)
    body = re.sub(r">\s+<", "><", body).strip()
    colors = set(c.lower() for c in re.findall(r"(?:fill|stroke|stop-color)='(#[0-9a-fA-F]{3,8}|white|black)'", body))
    multicolor = bool(colors - {"#000", "#000000", "black"})
    return viewbox, body, multicolor


def figma_svg(text, multicolor):
    """An SVG exported from Figma -> (viewBox, inner markup, multicolor), same form as convert()."""
    root = re.search(r"<svg\b([^>]*)>(.*)</svg>", text, re.S)
    head, body = root.group(1), root.group(2)
    vb = re.search(r'viewBox="([^"]+)"', head)
    viewbox = vb.group(1) if vb else "0 0 32 32"
    # a stroke drawn around the whole component in Figma (33px export): drop it, keep the 32px grid
    frame = re.compile(r'<rect x="0\.5" y="0\.5" width="32" height="32"[^>]*stroke="black"[^>]*/>')
    if frame.search(body):
        body = frame.sub("", body)
        viewbox = "0.5 0.5 32 32"
    body = re.sub(r"<foreignObject\b.*?</foreignObject>", "", body, flags=re.S)  # background-blur helpers
    body = body.replace("xlink:href=", "href=")
    if not multicolor:
        body = re.sub(r'\b(fill|stroke)="(?!none|white|url)[^"]+"', r'\1="#000"', body)
    body = re.sub(r'\sd="([^"]*)"', lambda m: ' d="%s"' % minify_path(m.group(1)), body)
    body = re.sub(r'\spoints="([^"]*)"', lambda m: ' points="%s"' % NUM.sub(short_num, m.group(1)), body)
    body = re.sub(r">\s+<", "><", body).strip()
    body = body.replace("'", "&apos;").replace('"', "'")
    # Figma puts fill="none" on <svg>: keep it for the children that inherit it
    return viewbox, "<g fill='none'>%s</g>" % body, multicolor


def data_uri(viewbox, body, multicolor):
    svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='%s'>%s</svg>" % (viewbox, body)
    if multicolor:
        svg = svg.replace("'#000'", "'#636363'")
    enc = svg.replace("%", "%25").replace("#", "%23").replace("<", "%3C").replace(">", "%3E").replace('"', "'")
    return 'url("data:image/svg+xml,%s")' % enc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.environ.get("RP_ICONS_SRC", str(DEFAULT_SRC)))
    ap.add_argument("--no-figma", action="store_true", help="ignore icons-figma/ (React icons only)")
    args = ap.parse_args()
    src = Path(args.src).expanduser()
    if not src.is_dir():
        sys.exit("Icon source not found: %s\nPass --src <frontend-workspace>/libs/ui-components/src/icons" % src)

    # icons[name] = (React import path or None, viewBox, body, multicolor); source[name] = Figma name or None
    icons, skipped, source = {}, [], {}
    files = sorted(src.glob("*.tsx")) + sorted(src.glob("departments/*.tsx"))
    for f in files:
        if f.name.endswith((".stories.tsx", ".test.tsx")):
            continue
        res = convert(f.read_text(encoding="utf-8"))
        if res is None:
            skipped.append(f.stem)
            continue
        rel = f.relative_to(src).with_suffix("").as_posix()
        name = kebab(f.stem)
        if name in icons:  # departments/Cleanliness next to Cleanliness
            name = "department-" + name
        icons[name] = (rel,) + res

    aliases = {}
    figma = []
    if not args.no_figma and not (FIGMA_DIR / "manifest.json").exists():
        # Fail closed: building without the Figma drawings would silently replace them with the React ones.
        sys.exit("Figma icon sources not found: %s/manifest.json\n"
                 "They are in the kit's git repository (the download zip leaves them out).\n"
                 "Run from a git checkout, or pass --no-figma to build from the React icons only." % FIGMA_DIR)
    if not args.no_figma:
        import json
        figma = json.loads((FIGMA_DIR / "manifest.json").read_text(encoding="utf-8"))["icons"]
    for e in figma:
        svg = FIGMA_DIR / e["file"]
        if not svg.exists():
            continue
        if e.get("png") and (FIGMA_DIR / e["png"]).exists():  # gradients SVG images cannot draw (see manifest note)
            import base64
            png = base64.b64encode((FIGMA_DIR / e["png"]).read_bytes()).decode()
            vb, body, mc = "0 0 32 32", "<image href='data:image/png;base64,%s' width='32' height='32'/>" % png, True
        else:
            vb, body, mc = figma_svg(svg.read_text(encoding="utf-8"), e["multicolor"])
        react = icons[e["class"]][0] if e["class"] in icons else None
        for a in e.get("aliases", []):
            if a in icons:  # a React icon drawn by this Figma icon (booking -> booking-color)
                react = react or icons[a][0]
                del icons[a]
            aliases.setdefault(e["class"], []).append(a)
        icons[e["class"]] = (react, vb, body, mc)
        source[e["class"]] = e["figma"]
    for a, target in ALIASES.items():
        if target in icons and a not in icons and a not in sum(aliases.values(), []):
            aliases.setdefault(target, []).append(a)

    # 1. rp-icons.css
    out = ["/* ReviewPro icons — GENERATED by .kiro/scripts/build-icons.py from the Figma icon library (icons-figma/) and @reviewpro/ui-components/icons.",
           "   Do not edit by hand. <span class=\"rp-icon rp-icon-search\"></span> = <Search size={24} />.",
           "   Mask icons take the text color (currentColor); multicolor icons keep their own colors. */",
           ".rp-icon { display: inline-block; flex: none; width: 24px; height: 24px; vertical-align: middle;",
           "  background-color: currentColor; -webkit-mask: var(--rp-icon) center / contain no-repeat; mask: var(--rp-icon) center / contain no-repeat; }",
           ".rp-icon-multicolor { background: var(--rp-icon) center / contain no-repeat; -webkit-mask: none; mask: none; }",
           ".rp-icon-size-12 { width: 12px; height: 12px; }",
           ".rp-icon-size-16 { width: 16px; height: 16px; }",
           ".rp-icon-size-20 { width: 20px; height: 20px; }",
           ".rp-icon-size-32 { width: 32px; height: 32px; }",
           ".rp-icon-size-48 { width: 48px; height: 48px; }",
           ".rp-icon-size-80 { width: 80px; height: 80px; }"]
    multi = []
    for name, (stem, vb, body, mc) in icons.items():
        sels = [".rp-icon-" + name] + [".rp-icon-" + a for a in aliases.get(name, [])]
        rule = "%s { --rp-icon: %s; }" % (", ".join(sels), data_uri(vb, body, mc))
        out.append(rule)
        if mc:
            multi += [name] + aliases.get(name, [])
    if multi:
        out.append(", ".join(".rp-icon.rp-icon-" + n for n in multi) +
                   " { background: var(--rp-icon) center / contain no-repeat; -webkit-mask: none; mask: none; }")
    CSS_OUT.write_text("\n".join(out) + "\n", encoding="utf-8")

    # 2. glyph variables in shared.css
    glyph_lines = [G_START, ":root {"]
    for g in COMPONENT_GLYPHS:
        if g in icons:
            stem, vb, body, mc = icons[g]
            glyph_lines.append("  --rp-glyph-%s: %s;" % (g, data_uri(vb, body, False)))
    glyph_lines += ["}", G_END]
    if SHARED.exists():
        css = SHARED.read_text(encoding="utf-8")
        if G_START in css and G_END in css:
            pre, rest = css.split(G_START, 1)
            post = rest.split(G_END, 1)[1]
            SHARED.write_text(pre + "\n".join(glyph_lines) + post, encoding="utf-8")
        else:
            print("shared.css has no GLYPHS:GENERATED markers; glyph variables not written")

    # 3. reference
    ref = ["# Icon Reference", "",
           "Every ReviewPro icon (generated by `.kiro/scripts/build-icons.py`, do not edit). The drawing comes from the Figma icon",
           "library (Pictograms and Icons) when Figma has it, otherwise from `@reviewpro/ui-components/icons`.",
           "Use the **Class** column: `<span class=\"rp-icon rp-icon-search\"></span>` is `<Search size={24} />`.",
           "**Figma only** = no React icon yet: tell the developers, they need to add it to `@reviewpro/ui-components/icons`.",
           "Sizes: no class = 24px (pass `size={24}` in code, the code default is 32), `rp-icon-size-12 | 16 | 20 | 32 | 48 | 80`.",
           "Color: the icon takes the text color (`color` prop in code). Multicolor icons keep their colors.", "",
           "%d icons (%d from Figma, %d Figma only), %d aliases. Skipped (not a single SvgIcon): %s" % (
               len(icons), len(source), sum(1 for n in source if not icons[n][0]),
               sum(len(v) for v in aliases.values()), ", ".join(skipped) or "none"), "",
           "| Class | React import | Figma | Aliases | Note |", "|---|---|---|---|---|"]
    for name, (stem, vb, body, mc) in sorted(icons.items()):
        react = "`import %s from '@reviewpro/ui-components/icons/%s'`" % (re.sub(r"[^A-Za-z0-9]", "", stem.split("/")[-1]), stem) if stem else "**Figma only**"
        ref.append("| `rp-icon-%s` | %s | %s | %s | %s |" % (
            name, react, source.get(name, ""),
            ", ".join("`rp-icon-%s`" % a for a in aliases.get(name, [])), "multicolor" if mc else ""))
    REF.write_text("\n".join(ref) + "\n", encoding="utf-8")

    # 4. tweak icon picker list
    if TWEAK.exists():
        js = TWEAK.read_text(encoding="utf-8")
        items = [[n] + aliases.get(n, []) for n in icons]
        lst = "[" + ",".join('"%s"' % " ".join(i) for i in items) + "]"
        if LIST_START in js and LIST_END in js:
            pre, rest = js.split(LIST_START, 1)
            post = rest.split(LIST_END, 1)[1]
            TWEAK.write_text(pre + LIST_START + lst + LIST_END + post, encoding="utf-8")
        else:
            print("tweak/glyphs.js has no ICON-LIST markers; icon picker not updated")

    kb = CSS_OUT.stat().st_size // 1024
    print("rp-icons.css: %d icons (%d multicolor, %d drawn from Figma, %d Figma only), %d aliases, %d KB" % (
        len(icons), len(multi), len(source), sum(1 for n in source if not icons[n][0]), sum(len(v) for v in aliases.values()), kb))
    if skipped:
        print("skipped:", ", ".join(skipped))


if __name__ == "__main__":
    main()
