"""
Make the Modernised (V2) copy of a mockup (reviewpro-ui-modernise skill). The current page is left as it is,
apart from a <link rel="alternate"> that shows the version switch.

  python3 .kiro/scripts/make-v2.py mockups/<slug>               # every page of the mockup: x.html -> x-v2.html
  python3 .kiro/scripts/make-v2.py mockups/<slug> index.html    # one page
  python3 .kiro/scripts/make-v2.py mockups/<slug> --theme-only  # refresh theme-v2.css only (keeps your V2 edits)
  python3 .kiro/scripts/make-v2.py mockups/<slug> --force       # rebuild the -v2 pages from the current ones (loses V2 edits)

What it does, per page:
  1. copies design-system/v2/theme-v2.css into the mockup folder (flat, so Figma Make still works);
  2. writes <page>-v2.html: <html data-rp-version="v2">, theme-v2.css after rp-icons.css, "(V2)" in the title,
     links to sibling pages rewritten to their -v2 copies, and an alternate link back to the current page;
  3. adds to <page>.html an alternate link to the V2 page (that is all it changes there).
Both pages then show the switch at the bottom (Current UI | Modernised, and Light | Dark on V2; Alt+Shift+V).
Python 3.9+, standard library only.
"""
import argparse
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
THEME = ROOT / "design-system" / "v2" / "theme-v2.css"


def v2_name(name):
    return name[:-5] + "-v2.html"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("pages", nargs="*")
    ap.add_argument("--theme-only", action="store_true")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    folder = Path(a.folder).resolve()
    if not (folder / "shared.css").exists():
        sys.exit("%s is not a mockup folder (no shared.css)" % folder)
    shutil.copy2(THEME, folder / "theme-v2.css")
    print("theme-v2.css copied")
    if a.theme_only:
        return 0
    pages = a.pages or sorted(p.name for p in folder.glob("*.html") if not p.name.endswith("-v2.html"))
    siblings = set(pages)
    for name in pages:
        src = folder / name
        dst = folder / v2_name(name)
        html = src.read_text(encoding="utf-8")
        alt_v2 = '<link rel="alternate" data-rp-version="v2" href="%s" title="Modernised">' % dst.name
        if 'data-rp-version="v2"' not in html.split("</head>")[0]:
            html_cur = re.sub(r"(\s*)</head>", r"\1  %s\1</head>" % alt_v2, html, count=1)
            src.write_text(html_cur, encoding="utf-8")
        if dst.exists() and not a.force:
            print("%s exists: kept (use --force to rebuild it from %s)" % (dst.name, name))
            continue
        v2 = html
        v2 = re.sub(r"<html([^>]*)>", lambda m: "<html%s data-rp-version=\"v2\">" % re.sub(r'\s*data-rp-version="[^"]*"', "", m.group(1)), v2, count=1)
        if "theme-v2.css" not in v2:
            v2, n = re.subn(r'(<link[^>]+href="rp-icons\.css"[^>]*>)', r'\1\n  <link rel="stylesheet" href="theme-v2.css" />', v2, count=1)
            if not n:
                v2 = re.sub(r"(\s*)</head>", r'\1  <link rel="stylesheet" href="theme-v2.css" />\1</head>', v2, count=1)
        v2 = re.sub(r"<title>(.*?)</title>", lambda m: "<title>%s (V2)</title>" % m.group(1).replace(" (V2)", ""), v2, count=1)
        v2 = re.sub(r'\s*<link rel="alternate" data-rp-version="[^"]*"[^>]*>', "", v2)
        for sib in siblings:  # links between pages stay inside V2
            v2 = re.sub(r'(href=")%s([#"?])' % re.escape(sib), r"\g<1>%s\2" % v2_name(sib), v2)
        v2 = re.sub(r"(\s*)</head>", r'\1  <link rel="alternate" data-rp-version="current" href="%s" title="Current UI">\1</head>' % name, v2, count=1)
        dst.write_text(v2, encoding="utf-8")
        print("%s written" % dst.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
