"""
Make the Modernised (V2) copy of a mockup (reviewpro-ui-modernise skill). The current page is left as it is,
apart from a <link rel="alternate"> that shows the version switch.

  python3 .kiro/scripts/make-v2.py mockups/<slug>               # every page of the mockup: x.html -> x-v2.html
  python3 .kiro/scripts/make-v2.py mockups/<slug> index.html    # one page
  python3 .kiro/scripts/make-v2.py mockups/<slug> --theme-only  # refresh the V2 files only (keeps your V2 edits)
  python3 .kiro/scripts/make-v2.py mockups/<slug> --force       # rebuild the -v2 pages from the current ones (loses V2 edits)
  python3 .kiro/scripts/make-v2.py design-system/examples index.html   # the kit showcase (links ../v2/, copies nothing)

What it does:
  1. copies design-system/v2/theme-v2.css and motion-v2.js into the mockup folder (flat, so Figma Make still works);
  2. writes <page>-v2.html: <html data-rp-version="v2">, theme-v2.css after rp-icons.css, motion-v2.js after
     shared.js, "(V2)" in the title, links to sibling pages rewritten to their -v2 copies, and an alternate link back
     to the current page;
  3. adds the V2 accessibility markup (WCAG 2.2 AA): a "Skip to main content" link before the top bar, id="main-content"
     and tabindex="-1" on the main area, and an "Expand navigation" button in the side bar (the edge handle alone is an 8px target);
  4. adds to <page>.html an alternate link to the V2 page (that is all it changes there).
Steps 1 and 3 also run on existing -v2 pages, with --theme-only too: they only add what is missing.
Both pages then show the switch at the bottom (Current UI | Modernised, and Light | Dark on V2; Alt+Shift+V).
Python 3.9+, standard library only.
"""
import argparse
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
V2_DIR = ROOT / "design-system" / "v2"
EXAMPLES = ROOT / "design-system" / "examples"
V2_FILES = ("theme-v2.css", "motion-v2.js")
SKIP_LINK = '<a class="v2-skip-link" href="#main-content">Skip to main content</a>'
EXPAND = ('<button type="button" class="rp-side-bar-item v2-side-bar-expand" data-rp-side-bar-toggle aria-expanded="false" '
          'aria-label="Expand navigation" data-rp-tooltip="Expand navigation" data-rp-tooltip-placement="right">'
          '<span class="rp-icon rp-icon-right-big"></span></button>')


def v2_name(name):
    return name[:-5] + "-v2.html"


def link_motion(html, prefix):
    """Load the V2 chart motion right after shared.js (idempotent)."""
    if "motion-v2.js" in html:
        return html
    tag = '<script src="%smotion-v2.js"></script>' % prefix
    html, n = re.subn(r'(<script[^>]*\bsrc="[^"]*shared\.js"[^>]*>\s*</script>)', lambda m: m.group(1) + "\n  " + tag, html, count=1)
    if not n:
        html = re.sub(r"(\s*)</body>", lambda m: m.group(1) + "  " + tag + m.group(1) + "</body>", html, count=1)
    return html


def a11y_markup(html):
    """Skip link, main id and the rail's Expand navigation button (idempotent; only on pages with the app shell)."""
    if 'class="rp-top-bar' not in html:
        return html
    main = re.search(r'<main\b[^>]*>', html)
    target = "main-content"
    if main:
        tag = main.group(0)
        mid = re.search(r'\bid="([^"]+)"', tag)
        if mid:
            target = mid.group(1)
        else:
            tag = tag.replace("<main", '<main id="main-content"', 1)
        if "tabindex=" not in tag:   # the skip link moves focus here, not only the scroll position
            tag = tag.replace('id="%s"' % target, 'id="%s" tabindex="-1"' % target, 1)
        html = html[:main.start()] + tag + html[main.end():]
    if "v2-skip-link" not in html:
        html = re.sub(r"(<body[^>]*>)", lambda m: m.group(1) + "\n  " + SKIP_LINK.replace("#main-content", "#" + target), html, count=1)
    if "data-rp-side-bar-toggle" not in html:
        rail = re.search(r'<nav\b[^>]*class="rp-side-bar[" ][^>]*>', html)
        if rail:
            end = html.find("</nav>", rail.end())
            if end > 0:
                line_start = html.rfind("\n", 0, end) + 1
                indent = re.match(r"\s*", html[line_start:end]).group(0) if html[line_start:end].strip() == "" else "    "
                html = html[:end].rstrip() + "\n" + indent + "  " + EXPAND + "\n" + indent + html[end:]
    return html


def kit_page(folder):
    return folder.resolve() == EXAMPLES.resolve()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("pages", nargs="*")
    ap.add_argument("--theme-only", action="store_true")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    folder = Path(a.folder).resolve()
    kit = kit_page(folder)
    if kit:
        if a.pages != ["index.html"] and not a.theme_only:
            sys.exit("In design-system/examples only the showcase gets a V2 copy: make-v2.py design-system/examples index.html")
        prefix = "../v2/"
    else:
        if not (folder / "shared.css").exists():
            sys.exit("%s is not a mockup folder (no shared.css)" % folder)
        for f in V2_FILES:
            shutil.copy2(V2_DIR / f, folder / f)
        print("%s copied" % " and ".join(V2_FILES))
        prefix = ""
    for page in sorted(folder.glob("*-v2.html")):
        html = page.read_text(encoding="utf-8")
        fixed = a11y_markup(link_motion(html, prefix))
        if fixed != html:
            page.write_text(fixed, encoding="utf-8")
            print("%s: V2 runtime and accessibility markup brought up to date" % page.name)
    if a.theme_only:
        return 0
    pages = a.pages or sorted(p.name for p in folder.glob("*.html") if not p.name.endswith("-v2.html"))
    siblings = set(pages)
    for name in pages:
        src = folder / name
        dst = folder / v2_name(name)
        html = src.read_text(encoding="utf-8")
        alt_v2 = '<link rel="alternate" data-rp-version="v2" href="%s" title="Modernised">' % dst.name
        if 'data-rp-version="v2"' not in html.split("</head>")[0]:
            html_cur = re.sub(r"(\s*)</head>", r"\1  %s\1</head>" % alt_v2, html, count=1)
            src.write_text(html_cur, encoding="utf-8")
        if dst.exists() and not a.force:
            print("%s exists: kept (use --force to rebuild it from %s)" % (dst.name, name))
            continue
        v2 = html
        v2 = re.sub(r"<html([^>]*)>", lambda m: "<html%s data-rp-version=\"v2\">" % re.sub(r'\s*data-rp-version="[^"]*"', "", m.group(1)), v2, count=1)
        if "theme-v2.css" not in v2:
            v2, n = re.subn(r'(<link[^>]+href="[^"]*rp-icons\.css"[^>]*>)', lambda m: m.group(1) + '\n  <link rel="stylesheet" href="%stheme-v2.css" />' % prefix, v2, count=1)
            if not n:
                v2 = re.sub(r"(\s*)</head>", lambda m: m.group(1) + '  <link rel="stylesheet" href="%stheme-v2.css" />' % prefix + m.group(1) + "</head>", v2, count=1)
        v2 = a11y_markup(link_motion(v2, prefix))
        v2 = re.sub(r"<title>(.*?)</title>", lambda m: "<title>%s (V2)</title>" % m.group(1).replace(" (V2)", ""), v2, count=1)
        v2 = re.sub(r'\s*<link rel="alternate" data-rp-version="[^"]*"[^>]*>', "", v2)
        for sib in siblings:  # links between pages stay inside V2
            v2 = re.sub(r'(href=")%s([#"?])' % re.escape(sib), r"\g<1>%s\2" % v2_name(sib), v2)
        v2 = re.sub(r"(\s*)</head>", r'\1  <link rel="alternate" data-rp-version="current" href="%s" title="Current UI">\1</head>' % name, v2, count=1)
        dst.write_text(v2, encoding="utf-8")
        print("%s written" % dst.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
