---
name: "reviewpro-html-mockup"
description: >
  Builds interactive standalone HTML mockups of the ReviewPro admin app (UI App) grounded in the
  real component library (@reviewpro/ui-components), the production theme, the production icons
  and the new navigation (blue top bar, icon rail, section panel). The output is a self-contained
  folder that looks and behaves like the product: open it in any browser or import it into Figma Make.
  Triggers on: mockup, prototype, screen, preview, build a page, dashboard, settings page, table,
  form, dialog, drawer, wizard, ReviewPro screen.
inclusion: auto
---

# ReviewPro HTML Mockup Generator

You build clickable prototypes of ReviewPro admin screens for designers. They replace quick Figma
prototypes, so they must look like the product, behave like it, and open anywhere: a browser, or
Figma Make (Figma's code prototype import). This file is the protocol. Detailed rules live in the
files it points to: read them when the step says so.

## Ground rules

1. **Every HTML output is a mockup folder in `mockups/`.** Quick ideas, single screens and
   before/after comparisons included. Never return mockup HTML through `create_artifact` or a code
   block: without shared.css, rp-icons.css and shared.js it renders wrong and cannot be imported into
   Figma. A text-only discussion needs no folder.
2. **Compose only from DS components.** Every class must exist in `shared.css` (listed in
   `design-system/rp-map.json`). The only CSS you write is page layout (grid / flex containers, gap,
   widths) with tokens. Invented cards, pills and metric boxes stop looking like ReviewPro: that is
   the failure this rule prevents. See § Composition.
3. **Assets are local siblings.** `shared.css`, `rp-icons.css`, `shared.js`,
   `reviewpro-reputation-logo.svg`, `establishment-logo.png` sit next to the HTML. No `../` paths, no
   CDNs except Google Fonts (Noto Sans), no frameworks (React, Tailwind, Bootstrap, chart libraries).
   Noto Sans is a `<link>` in each page head before `shared.css` (copy the three lines from `00-blank-page.html`).
4. **Keyboard and screen readers work by default.** Icon-only buttons get `aria-label`. Actions are
   `<button>`, navigation is `<a href>`. Selects, menus, tabs, accordions, dialogs and drawers get their
   keyboard support from shared.js: keep their markup, add no key handlers.
5. **No state switchers.** Mockups show the happy path. Empty or loading states appear only through a
   real interaction (a search with no results, a short loader after a click).
6. **Class names are the handoff.** `rp-main-button rp-main-button-size-small` is
   `<MainButton size="small">`. Keep using the documented modifier classes (never inline styles that
   imitate a variant): developers read the mockup through `design-system/HANDOFF.md`, and Tweak mode
   switches props by these classes.

## Build loop

### 1. Match the pattern
Use `design-system/foundation/decision-tree.md` to map the request to a starter (00–09). Nothing
fits → Pattern 0 (blank page) + § Composition. For a multi-screen flow, pick one pattern per screen.

### 2. Scaffold the folder
```bash
# macOS / Linux
sh .kiro/scripts/new-mockup.sh <mockup-name> <pattern> [<pattern>:<file.html> ...]
# Windows
python .kiro/scripts/new-mockup.py <mockup-name> <pattern> [<pattern>:<file.html> ...]

# e.g. list → edit form → wizard
sh .kiro/scripts/new-mockup.sh survey-settings 01 06:edit.html 09:create.html
```
The script copies `templates/` (assets + `.figma/make/` for Figma Make), copies each starter (the
first one becomes `index.html`) and rewrites `../foundation/` and `../brand/` paths to siblings. It
refuses to overwrite an existing folder. To add a screen to an existing mockup, copy the starter by
hand and remove `../foundation/` and `../brand/` from its paths.

### 3. Read what the change needs
| Always | Why |
|--------|-----|
| `design-system/foundation/rules.md` | 14 absolute rules, sample data, writing rules |
| Your pattern's section in `design-system/pattern-blueprints.md` | Pattern rules |

| Only when needed | Why |
|------------------|-----|
| `design-system/components/_index.md` → `components/rp-*.md` | A component that is not in the starter, or a different variant |
| `design-system/foundation/icons-full-reference.md` | Any icon not already in the starter: use a class from the **Class** column |
| `design-system/HANDOFF.md` | Class → React prop table |

The starter already has the shell, the right structure and the wiring. Typical changes need 2–4
component docs, not all of them.

### 4. Modify the starter
- Shell: set the active rail item (`rp-side-bar-item-active` + `data-rp-current`), the section panel
  items and the active page, the breadcrumbs and the page title. Keep everything else in the top bar.
  The section panel stays closed on load (a rail click opens it).
- From a screenshot: follow `rules.md` § Copying a screenshot. A **green top bar means QA**: build the
  blue production bar, never `rp-top-bar-qa`. Keep exactly the rail icons the screenshot shows.
- Replace entities, columns, fields and data for the use case. Keep the skeleton (tiles, toolbar,
  table, pagination, overlays at the end of `<body>`).
- Realistic data: 8–12 rows with the standard names in `rules.md`. Never "Item 1".
- Every interactive element responds (§ Interaction density).

### 5. Check
```bash
sh .kiro/scripts/check-mockup.sh mockups/<mockup-name>       # Windows: python .kiro/scripts/check-mockup.py …
```
Fix every **ERROR** (missing asset, `../` path, unknown icon or kit class, emoji, native `<select>`,
a `data-rp-open` / `data-rp-menu` that points nowhere, a link to a missing page, a forbidden library).
Read every **WARN** (invented class, raw hex color, large `<style>`, off-ladder z-index, icon-only
button without a name, copy that breaks the writing rules) and fix it unless it is deliberate layout.
Re-run until there are no errors.

### 6. Look at it
If you have a browser tool (e.g. Playwright MCP), open `index.html` at 1440×900 and verify: zero
console errors, icons render, then click through the QA checklist below and take a screenshot.
Without a browser tool, say that you did not verify visually and ask the user to open `index.html`.

### 7. Report
Tell the user the folder, the screens and how they link, what is interactive, and anything you could
not express with DS components. Mention that `#edit` at the end of the URL opens Tweak mode for
visual fine-tuning that saves into the file (§ Tweak mode).

## Composition — when no pattern fits

Decompose the page into DS primitives instead of inventing:

| Need | Component doc (`design-system/components/`) |
|------|-----------|
| A widget, a form section, a card | `rp-tile.md` (Tile + TileTitle + TileContent / TileTable + TileActions) |
| Lists, results, rankings | `rp-table.md` (table, toolbar, bulk bar, pagination, volume bar) |
| Status, tags, "New" | `rp-chip.md` (always with text) |
| Label / value pairs, KPIs | `kit-label-value`, `kit-kpi` inside a tile (`rp-typography.md`) |
| View switching | `rp-tabs.md`, toggle buttons in `rp-buttons.md` |
| Filtering | toolbar search + selects (`rp-fields.md`), more filters in a drawer (`rp-dialog-drawer.md`) |
| Feedback | `rp-snackbar-tooltip.md` (`rpSnackbar`), `rp-alert.md`, `rp-placeholder.md` |
| Choices | `rp-selection-controls.md` and the selection table in `decision-tree.md` |

A kanban board is tiles in a `kit-grid`. A roadmap is a table with chips. Before writing a class in
`<style>`, ask "which file defines this?": if the answer is "none", use the real component instead.

## What shared.js already does

Do not re-implement these per page:

| Behavior | How to use |
|----------|-----------|
| Select open, pick, close, multiple, search inside | `.rp-select` markup from `rp-fields.md` |
| Menus (kebab, actions, top bar selectors) | one menu per kind of action + `data-rp-menu="id"` on each trigger |
| Dialogs and drawers | `data-rp-open="id"`, `data-rp-close`; backdrop and Escape close; focus stays inside. JS: `rpOpen(id)` / `rpClose(id)` |
| Snackbars | `data-rp-snackbar="User deleted"` (+ `data-rp-snackbar-variant`), JS: `rpSnackbar('Failed to save changes', 'error')` |
| Required-field validation | `rp-field-label-required` on labels + `data-rp-validate="Profile updated"` on the save button (closes its dialog / drawer when valid). JS: `rpValidate(scopeElement)` |
| Tabs and tab panels | `.rp-tab` + `aria-controls="panelId"` |
| Accordion, tile expand | `.rp-accordion-summary`, `.rp-tile-expand` (+ `.rp-tile-expand-content`) |
| Switch, toggle buttons | `.rp-switch` toggles itself and fires `change`; never toggle it in page JS |
| Table selection + bulk bar | `.rp-checkbox` in rows and header, `.rp-toolbar-bulk` |
| Table sort, filter, pagination, empty state, live count | `.rp-table-sort`, `data-rp-filter`, `.rp-table-pagination[data-rp-table]`, `data-rp-empty-for`, `data-rp-count-for`, `data-rp-clear-filters`; JS: `rpRefreshTable(id)` after adding rows |
| Side bar sections | rail items open their section panel (closed on load); other sections show the production page list |
| Tooltips | `data-rp-tooltip="Text"` (+ `data-rp-tooltip-placement`) |

The page itself still owns: content-specific logic (a switch that updates its row's chip, a View
button that fills a drawer, wizard steps), navigation between screens.

## Page structure

```
Top bar         64px  sticky top:0                 z 1000   brand RPP70: establishment · date range | notifications · help · account
Side bar        48px  sticky, under the top bar    z 1000   icon rail: 48px items, 32px status square (active = blue-20), RPP70 icons
Section panel  198px  sticky, under the top bar    z 1000   closed on load; a rail icon opens its pages; a page, a click outside or Esc closes it
Content               padding 16, background #F8F8F8: breadcrumbs → page title (h4) → kit-toolbar → kit-stack of tiles
```
Breadcrumbs: section link(s) then the current page (`Settings / Organisation / Users`). Overlays and
page menus go at the end of `<body>`, after `</main>`.

## Stacking

One z-index ladder for every page. Do not invent values.

```
table sticky header / cells   2–4        side bar, panel, top bar   1000
sticky page parts             10         drawer                     1200
menu, select, popover         1300       dialog                     1500
snackbar                      1600       tooltip                    1700
```

## Interaction density

Every page: realistic data, no dead controls.

List pages:
- Every row has a kebab with 2–3 actions; each opens a drawer or dialog, shows a snackbar or navigates
- Items that can be turned on and off have a row switch that also updates the status chip (page JS) and shows a snackbar
- Toolbar: search + 1–3 selects (`data-rp-filter`), Filters → drawer, a secondary action (Export)
- A search with no results shows the empty state with "Clear filters"
- Pagination: rows per page, range, first / previous / next / last all work
- Selecting rows shows the bulk bar with the count; bulk actions do something

Form pages:
- Sections are tiles with TileActions; required fields are marked
- Save validates (error on the field + scroll) and shows a snackbar; Cancel does something

## Multi-screen sets

One HTML file per distinct screen, linked with relative sibling paths:

| Flow | Files |
|------|-------|
| List → detail | `index.html` + `detail.html` (+ `edit.html`) |
| Wizard | one page with step panels (09), or `step-1.html`, `step-2.html` ("Next", last step = action verb) |
| Tabs that are separate views | one file per tab, the same tab bar with the right `rp-tab-selected` (tabs as `<a href>`) |
| Sections of the side bar | one file per page, the right rail item and panel item active |

Build the entry screen first, then detail screens, then overlays; finally check that every tab and
navigation action leads to a real file.

## Icons

Production icons only: `<span class="rp-icon rp-icon-{name}"></span>`, name = the React icon file in
kebab case (`QuestionMark` → `rp-icon-question-mark`), plus a few aliases (`rp-icon-plus`). No emoji,
no inline SVG icons, no icon libraries. Sizes `rp-icon-size-12 | 16 | 20 | 32 | 48 | 80`, default 24.
Look names up in `icons-full-reference.md`; the checker reports classes that do not exist. Common:
`add`, `actions` (kebab), `edit`, `delete`, `close`, `check`, `search`, `filter`, `download`,
`calendar`, `info`, `warning`, `error`, `down` (chevron), `sort-by`, `arrow-up`, `arrow-down`.

## Figma Make

Each mockup folder is a ready Figma Make project: `index.html` is the entry point and `.figma/make/`
holds the static-site scripts. Keep everything flat in the folder (the deploy script copies
`*.html *.css *.js *.woff* *.svg *.png` from the root only).

## Tweak mode

Designers fine-tune mockups visually: the **Edit** button (bottom left, on pages opened from their
computer), `#edit` at the end of the URL or Alt+Shift+E opens a Figma-like editor (`tweak/`). They
switch React props (modifier classes such as `rp-main-button-secondary`), swap icons, change auto
layout, spacing, type, fill and radius along DS tokens, set sizes in px, edit text, drag, reorder,
duplicate, delete, and insert DS components from the + panel. Style edits apply to all similar
elements by default, so one tweak can add the same inline style to many tags: if the user asks, fold
repeated inline styles into the page's layout class. In Chrome/Edge every change is written into the
HTML file as a small patch of the touched tag (a class swap, `style="padding-top: var(--spacing-1-5)"`,
new text, moved elements); formatting, scripts and comments stay. A typed number that is a token is
written as the token; any other number stays as px: the designer chose it, keep it.

What this means for you:
- **Re-read the file before editing a mockup** the designer has tweaked. Treat inline `var(--…)`
  styles from Tweak mode as design decisions: keep them, unless the user asks you to fold them into classes.
- If the designer pastes a "Tweak changes" list (Safari/Firefox, Figma Make preview), apply each line
  to the source with the token shown.
- Tweak mode notices when the file changed on disk and asks to reload, so it never overwrites your edits.
- **Version history:** before each save Tweak keeps the previous page in
  `.tweak-history/<page-name>/<date>_<time>__<kind>.html` (kinds: `before`, `auto`, `manual`, `restore`,
  `kiro`). The `keep-version` hook keeps a `kiro` version before your file tools write a page; before
  changing a page with a shell command (sed, a script), run `sh .kiro/scripts/keep-version.sh <page>`
  (Windows: `python .kiro/scripts/keep-version.py <page>`). When the designer asks to go back to a
  version, copy that file over the page, then tell them to reload.
- **Name your version** when you finish changing a page: in `.tweak-history/<page-name>/names.json`
  give the newest `…__kiro.html` file a short name of what you did ("Filters in a drawer"), at most ~40
  characters, in the designer's language: `{ "2026-11-17_14-22-05__kiro.html": { "name": "Filters in a drawer", "by": "kiro" } }`.
  Keep the other entries; create the file as `{}` when it is missing; skip it when the page has no
  `.tweak-history` folder.

### Tweak changes (`tweak-changes.md`)
Every save in Tweak mode also writes `tweak-changes.md` next to the edited page: the net changes of
each editing session. **Saved changes are already in the page.** The file only tells you what is
left, line by line. When the designer says they tweaked, fixed or changed something (or "apply my tweaks"):
1. Read `tweak-changes.md`, then **read the page again from disk**. Never edit from an older copy and
   never rewrite the whole file.
2. Act on the tag of each line, nothing else:
   - `[done]`: already in the file. Do nothing.
   - `[fold]`: the same inline style on N elements. Move it into the element's own page class in the
     page `<style>` and remove the inline copies. Elements with only `rp-*` / `kit-*` classes keep it
     inline. Never edit `shared.css`.
   - `[script]`: elements made by a script; change the script or the page class it uses.
   - `[apply]`: not saved (Safari, Figma Make): apply the line to the page.
3. Make the same style and prop changes on the other pages listed in the block, where the same elements appear.
4. **Comments** (`## Comments on <page>` blocks): each `- [comment cID] line N · \`path\` ("text"): request`
   points at one element. Make the requested change on that element, then delete the comment's two
   lines (the bullet and the `<!-- cID {…} -->` line under it). Ask when a comment is unclear and leave it in the file.
5. Delete `tweak-changes.md` when nothing is left in it, run the checker, and answer with one line per
   page you changed (and per comment applied). If the page is open in Tweak mode, tell the designer to
   click **File changed · Reload**.

## QA checklist

| # | Check | Pass |
|---|-------|------|
| 1 | Load | Zero console errors; logos and icons render |
| 2 | Shell | Right rail item and panel item active; breadcrumbs match the page |
| 3 | Drawer / dialog | Opens; closes with X, backdrop and Escape; the title matches the trigger |
| 4 | Filter + search | Rows narrow live; the count updates; the no-results state appears |
| 5 | Clear filters | Search and selects reset, all rows return |
| 6 | Kebab | Opens at the button; every action does something; Escape / outside click close it |
| 7 | Switch | Flips, updates the chip, shows a snackbar; flipping back restores |
| 8 | Pagination | Rows per page, range and the four buttons work |
| 9 | Selection | Row checkbox highlights the row; header checkbox selects all; the bulk bar shows the count |
| 10 | Links | Every tab and navigation target exists |
| 11 | Save | Snackbar on valid data; error + scroll on a missing required field |
| 12 | Checker | `check-mockup` reports no errors |

## Do not

- Write large `<style>` blocks or invent component classes (custom cards, pills, metric boxes)
- Use raw hex colors, invented tokens or z-index values outside the ladder
- Use `<table>` without `rp-table`, a native `<select>`, emoji or inline SVG icons
- Put content directly on the grey canvas, or a page without the app shell
- Use medium (48px) buttons or fields inside tiles, toolbars, tables, dialogs or drawers
- Pack a multi-screen flow into one file, or add state switchers and demo toolbars
