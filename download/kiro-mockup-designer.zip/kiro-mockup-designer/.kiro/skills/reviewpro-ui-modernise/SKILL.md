---
name: "reviewpro-ui-modernise"
description: >
  Opt-in second pass on an existing ReviewPro mockup: makes a separate "Modernised (V2)" copy of the pages with an
  ideal UI (Shiji brand colours, opacity variables, softer cards, thicker charts, a dark mode) and a switch to compare
  it with the current UI App version. Never the default: mockups are built first with reviewpro-html-mockup, exactly
  like the library. Triggers on: modernise, modernize, improve the UI, make it modern, V2, version 2, new UI, ideal UI,
  rebrand, branding changes, brand colours, dark mode, thicker charts.
inclusion: manual
---

# ReviewPro UI Modernise (V2)

Two versions of the same screen, side by side:

| | Current UI | Modernised (V2) |
|---|---|---|
| Skill | `reviewpro-html-mockup` (default) | this one (only when asked) |
| Source of truth | Figma UI App library + the product | the Shiji brand kit + the rules below |
| Files | `index.html` (and other pages) | `index-v2.html` next to it, plus `theme-v2.css` |
| Styles | `shared.css` only | `shared.css`, then `theme-v2.css`, then the page's own `<style>` |

The version switch at the bottom of both pages (Current UI | Modernised, and Light | Dark on V2, Alt+Shift+V)
keeps the scroll position, so the two can be compared screen by screen.

## Hard rules

1. **Never modernise the current pages.** The only change this skill makes to `index.html` is the
   `<link rel="alternate" data-rp-version="v2">` that shows the switch. Everything else goes in the `-v2` pages.
2. **Never put V2 styles in `shared.css`.** Kit-wide proposals go in `design-system/v2/theme-v2.css`
   (then refresh the copies with `make-v2.py <folder> --theme-only`); one-screen changes go in the `-v2`
   page's `<style>`, with class names starting `v2-`.
3. **No new hex colours.** Use the V2 tokens: `--v2-*` brand colours, the opacity ramps
   (`--v2-blue-a08`, `--v2-ink-a12`, or `rgba(var(--v2-blue-rgb), .2)`), and the kit tokens V2 remaps.
4. **Same content and behaviour.** Same data, same interactions, same component classes. V2 may restructure
   a layout, change a chart type or rewrite labels (sentence case), and says so in the report.
5. **Both themes work.** Check Light and Dark before reporting.
6. **Laura's review rules (17 Nov 2026), never broken:** no gradients anywhere; buttons get 10px corners, never
   pills; the button hierarchy stays (one primary per area: the page's main action stays a primary ghost button);
   the top bar colour follows the view (establishment = product blue `#014CB7`, account/corporate = Midnight);
   Energetic Green only on the AI call to action (never the avatar or navigation); Shiji Day Sans only for the page
   title and single hero numbers (font analysis DE-2337, option B); a title-only tile gets even padding.
   The full list and the reasons: `design-system/v2/README.md` § Rules from Laura's review.

## Steps

1. The current mockup must exist and pass `python3 .kiro/scripts/check-mockup.py mockups/<slug>`.
   If it does not, build it first with `reviewpro-html-mockup`.
2. Make the V2 copies: `python3 .kiro/scripts/make-v2.py mockups/<slug>` (every page; or name pages).
   An existing `-v2` page is kept; `--force` rebuilds it from the current page.
3. Read `design-system/v2/README.md` (the design rules and tokens), then improve the `-v2` pages:
   - Hierarchy: one display title per page (Shiji Day Sans), card titles 18/26 semibold Noto Sans, hero numbers in the
     display font with tabular figures. Never the display font in tables, fields, navigation, chart labels or guest text.
   - Charts: lines 3px with round joins, donut gauges 12-14px with round caps, bars with 3px radius,
     dashed light grid, brand chart order `--v2-chart-1` … `--v2-chart-8`.
   - Colour: Reviewpro Blue (`--v2-blue`) for actions and the active state, Midnight for text and the account-view
     top bar, Energetic Green only for the AI call to action. Flat colours and opacity tints; no gradients.
   - Status: tinted backgrounds from the opacity ramps instead of solid pastels with borders.
   - Space: 24px card padding and gaps, 16px card corners, soft shadows instead of borders.
   - Dark mode: neutral greys (page `#0F1012`, card `#17181B`, raised `#1E2024`), text `#ECEDEF`, a calm blue accent
     (`#8AA6F2`, buttons `#3D6AD6`), softened status colours, tints by alpha. No blue-tinted surfaces.
4. Check: `python3 .kiro/scripts/check-mockup.py mockups/<slug>` (no errors), then open both pages, use the
   switch both ways, switch Light/Dark, and take screenshots of the current page and V2 in both themes.
5. Report in plain words: what V2 changes and why (point at the brand rule), what is page-only and what is
   kit-wide, and the open questions for branding. Never call V2 "the new library": it is a proposal.

## What V2 is based on

- Shiji Brand Kit, ITB Berlin 2025 rebrand "Day & Night" (`.kiro/skills/Presentation/shiji-presentation.md`
  in the design workspace): Midnight `#172554`, Twilight `#1E3A8A`, Reviewpro Blue `#0030FF`, Meridian
  `#60A5FA`, Daylight blues `#D5ECFF` `#E8F5FF`, Energetic Green `#0AFFAB`, alert red `#DC2626` / `#F87171`,
  sunset accents. Fonts: Shiji Day Sans (Aeonik) for titles and big numbers, Noto Sans for everything else.
- Laura's asks: thicker charts, a less dated look, brand colours, variables with opacities, a dark mode.
- Branding's list of UI changes: not received yet. Add it to `design-system/v2/README.md` § Branding requests
  when it arrives, and mark each V2 rule that answers one.
