---
name: "reviewpro-ui-modernise"
description: >
  Opt-in second pass on an existing ReviewPro mockup, for the Design team: makes a separate "Modernised (V2)" copy of the
  pages with the V2 design concept (Shiji brand colours, opacity variables, softer cards, thicker charts, a dark mode,
  restrained motion, WCAG 2.2 AA accessibility) and a switch to compare it with the current UI App version. Never the
  default: mockups are built first with reviewpro-html-mockup, exactly like the library. Triggers on: modernise,
  modernize, improve the UI, make it modern, V2, version 2, new UI, ideal UI, rebrand, branding changes, brand colours,
  dark mode, thicker charts, animations, motion, interactions, hover effects, accessible version.
inclusion: manual
---

# ReviewPro UI Modernise (V2)

V2 is a **design concept**, owned by the Design team: a proposal to discuss, never the UI App library. This skill turns
a finished, faithful mockup into its V2 copy so the two can be compared with the switch at the bottom of the page. Any
designer who runs it must get the same result: the rules are written down and checked by scripts, so nothing depends on
taste or memory.

| | Current UI | Modernised (V2) |
|---|---|---|
| Skill | `reviewpro-html-mockup` (default) | this one (only when asked) |
| Source of truth | Figma UI App library + the product | `design-system/v2/README.md` (the V2 rules) |
| Files | `index.html` (and other pages) | `index-v2.html` next to it, plus `theme-v2.css` and `motion-v2.js` |
| Styles | `shared.css` only | `shared.css`, then `theme-v2.css`, then the page's own `<style>` |
| Motion | none (static, like the library) | `theme-v2.css` § 6 and `motion-v2.js` |
| Accessibility | as the product (its issues are reported as `library` warnings) | WCAG 2.2 AA in Light and Dark, no errors |

## Before you start

1. **Read `design-system/v2/README.md`**: § The rules (V2-1 … V2-22), § Rejected ideas and § Review log. Quote rule
   numbers in your report. Never propose a rejected idea again.
2. The faithful mockup must exist and pass `python3 .kiro/scripts/check-mockup.py mockups/<slug>`. If it does not,
   build it first with `reviewpro-html-mockup`. V2 never starts from a sketch.
3. V2 is for Design. When the person asking is not in Design (a PM, a developer), make the V2 copy if they insist, but say
   in the report that it is a concept and the build follows the Current UI.

## Hard rules (the short version of README § The rules)

1. **Two versions, never mixed** (V2-1). The only change to a current page is the `<link rel="alternate">` that shows the
   switch. No V2 style in `shared.css`, no V2 script in `shared.js`.
2. **Same content, behaviour and hierarchy** (V2-2). One primary action per area; the page's main action stays a primary
   ghost button. Restructure only to meet an accessibility or small-screen rule, and say so.
3. **No improvised treatments** (V2-3). A component without a V2 rule keeps the library structure with V2 tokens. A new
   idea is a proposal in your report, not a change in the page.
4. **Where changes go**: kit-wide ideas in `design-system/v2/theme-v2.css` or `motion-v2.js` (then
   `make-v2.py <folder> --theme-only` refreshes every copy); one-screen changes in the `-v2` page's `<style>`, with class
   names starting `v2-`. No new hex colours: V2 tokens, the opacity ramps, `rgba(var(--v2-blue-rgb), .2)`.
5. **The review rules of 17 Nov 2026, never broken**: no gradients anywhere (V2-5); buttons 10px corners, never pills
   (V2-11); Energetic Green only on the AI call to action and its chip (V2-7); Shiji Day Sans only for the page title and
   single hero numbers (V2-10); the page stays light, no darker containers (V2-13); the top bar colour follows the view,
   two clearly different blues in both themes (V2-16); the page header keeps its divider (V2-14); fields are outlined
   with no fill (V2-15); dark mode is neutral grey, not blue (V2-21).
6. **Motion with a reason** (V2-19, V2-20). It comes with the page: charts draw once, side bar icons grow on hover,
   buttons dip, menus, dialogs and drawers ease in. Do not add load animations for tiles, tables or text, loops, or
   `transition: all`. Nothing moves with reduced motion or while Tweak is editing; nothing is written into the page.
7. **Accessible by default** (V2-9, V2-22): WCAG 2.2 AA in Light and Dark. Nothing told by colour alone (legends with
   values, status in words), every text 4.5:1, every control and chart mark 3:1, one visible focus ring, everything works
   with the keyboard, works at 320 CSS px. `a11y-check.py` must report **no errors** before the page is shared.

## Steps

1. **Make the copies**: `python3 .kiro/scripts/make-v2.py mockups/<slug>` (every page; or name pages). It writes
   `<page>-v2.html`, copies `theme-v2.css` and `motion-v2.js`, and adds the accessibility markup: a "Skip to main content"
   link, `id="main-content" tabindex="-1"` on the main area and the Expand navigation rail button. An existing `-v2` page
   is kept (`--force` rebuilds it from the current page and loses V2 edits).
2. **Adapt the page only where a rule asks for it.** Go through this list for every screen:

   | On the page | What V2 does | Rule |
   |---|---|---|
   | A chart with two or more colours (donuts, stacked bars, series) | Add a `kit-legend` next to it with each colour's name and value; put the split in the chart's `aria-label` | V2-9 |
   | A status shown by colour (goal icon, dot, coloured number) | Add the status in words ("On track", "Off track") in the matching text colour | V2-9 |
   | Text coloured by data (word clouds, coloured labels) | Use text tokens (`--text-success`, `--text-error`, `--text-secondary`) and add a legend; size can still carry weight | V2-9, V2-22 |
   | The AI call to action and its quota chip | Keep the neon tint (`--neon-20/30/90`) and the accent button | V2-7 |
   | Hero numbers (gauge centres, KPI values) | Display font, 500, tabular figures | V2-10 |
   | Anything else | Nothing: the theme does it | V2-3 |

3. **Check** (both must pass):
   ```bash
   python3 .kiro/scripts/check-mockup.py mockups/<slug>    # kit classes + the V2 rules a script can check
   python3 .kiro/scripts/a11y-check.py mockups/<slug>      # WCAG 2.2 AA, Light and Dark, real keyboard: no errors
   ```
   Fix every ERROR. Read every WARN; `library` warnings belong to the current page and stay (they are product backlog).
4. **Look at it**: open both pages, use the switch both ways, switch Light and Dark, reload V2 to watch the charts draw,
   tab through the page once. For still screenshots emulate reduced motion or call `rpMotionStop()` first.
5. **Review loop**: Laura and the Design team comment in Tweak. Apply each comment. When a comment sets a rule for every
   screen (not just this one), add it to `design-system/v2/README.md` (§ The rules with the next number, § Review log,
   § Rejected ideas when it rejects something) and to `check-mockup.py` when a script can check it, in the same change.
   Then the next designer gets it for free.
6. **Report** in plain words:
   - what V2 changes on these screens and why, quoting the rule numbers; what is page-only and what is kit-wide;
   - the checks: `check-mockup` and `a11y-check` results (errors must be 0), Light and Dark looked at;
   - proposals (ideas without a rule yet) and the open questions in the README;
   - that V2 is a concept: never call it "the new library".

## What V2 is based on

- Shiji Brand Kit, ITB Berlin 2025 rebrand "Day & Night" (Presentation Designer kit, `.kiro/skills/figma-slides-builder/references/shiji-brand-kit.md`): Midnight `#172554`, Twilight `#1E3A8A`, Reviewpro Blue `#0030FF`, Meridian `#60A5FA`, Daylight
  blues `#D5ECFF` `#E8F5FF`, Energetic Green `#0AFFAB`, alert red `#DC2626` / `#F87171`, sunset accents. Fonts: Shiji Day
  Sans (Aeonik) for titles and big numbers, Noto Sans for everything else.
- Laura's reviews of 17 Nov 2026 (README § Review log) and her font analysis (DE-2337).
- WCAG 2.2 AA / EN 301 549 v4.1.1 (README § Accessibility).
- The build plan, in parts with difficulty, for Confluence: `design-system/v2/MODERNISATION-PLAN.md`.
- Branding's list of UI changes: not received yet. Add it to README § Branding requests when it arrives.
